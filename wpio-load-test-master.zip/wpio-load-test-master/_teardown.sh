#!/bin/bash

echo 'Shutting down the load test setup...'
echo 'Info: this will also remove any Docker data volumes that might have been created.'

# -v removes all data volumes
$DCEXECUTABLE -p wpio $DOCKER_COMPOSE_FILES down -v

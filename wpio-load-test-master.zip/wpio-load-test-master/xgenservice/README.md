# XGen Services

In order to execute XGen services these steps are required:

1. specify the XGen Docker image version in docker-compose/dc-wpio-xgen-<xgen_service_name>.yml
2. set xgenservice/environment-<xgen_service_name>.conf to the correct values for that specific service
3. Identify a test request in a test environment and export all messages via AuditBrowser
4. create a backend configuration file `backend/application-<xgenservice>.properties` with the required backend response messages and configure the backend in docker-compose/dc-wpio-xgen-<xgen_service_name>.yml accordingly. create a Gatling Szenario file that injects the required request message to the correct connector queue

Now the test can be started as usual.


## Execution of temporarily modified services

1. Copy original XGen XPK archive out of the Docker container via `docker cp`
2. Modify the extracted XPK archive
3. mount the modified XPK archive into the Docker container via docker-compose.yml

Example:

````
  xgenservice:
    image: "registry.dwp/wpio/xgen-dwp-orderbook:1.1.20-1383214"
    [...]   
    env_file:
      - ./xgenservice/environment.conf
    volumes:
    [...]   
      - ./xgenservice/DWP.ORDERBOOK_20200511-185827-969.xpk:/app/install/internal/DWP.ORDERBOOK/archives/DWP.ORDERBOOK_20200511-185827-969.zip
      - ./xgenservice/SystemSpecification.A.xml.template:/app/install/internal/DWP.ORDERBOOK/archives/SystemSpecification.A.xml.template
````


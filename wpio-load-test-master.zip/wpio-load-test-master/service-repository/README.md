# Service Repository

This component is intended as an external message repository for XGEN services. It is implemented as PostgerSQL DB.

Use this snipped for the compose integration:
> ```
> service-repository:
>   image: postgres:13.10
>   networks:
>     - wpio
>   env_file:
>     - ../service-repository/environment.conf
>   expose:
>     - 5432
>   volumes:
>     - ../service-repository:/docker-entrypoint-initdb.d:z
>   restart: on-failure
> ``` 

Use these credentials for the repository connection:

**Connection URI:** postgresql://xgen:6QUXdP@service-repository:5432/xgen_messages \
**User:** xgen\
**Password:** 6QUXdP \
**Database:** xgen_messages

Do not confuse the superuser postgres with the serviceuser xgen!

In case you need to take a closer look at the database during runtime you can use **psql**.
To start psql, first log in to the postgres container, then run psql with
> ```
> psql xgen_messages -U xgen
> ``` 

## Documentation

PostgreSQL Image: https://github.com/docker-library/docs/blob/master/postgres/README.md \
PostgreSQL: https://www.postgresql.org/docs/13/index.html \
psql: https://www.postgresql.org/docs/current/app-psql.html
#!/usr/bin/env bash

EXIT_CODE=1
if [[ -f /logs/service.log ]];
then
  EXIT_CODE=0
fi

exit $EXIT_CODE

#!/bin/bash
echo "ENV: $(uname -a)";
echo "DISABLE_OOB=ON" >> $ORACLE_HOME/network/admin/sqlnet.ora

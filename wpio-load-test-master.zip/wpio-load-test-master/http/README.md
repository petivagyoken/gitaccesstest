# Webservices (HTTP adapter)

Unmodified jcf-http container instance. Nothing more.
package de.dwpbank.wpio.loadtest.backend;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@RunWith(SpringRunner.class)
public class ApplicationTest {

  @Autowired TestDataProperties testDataProperties;

  @Test
  public void testProperties() {

    assertNotNull(testDataProperties);

    assertEquals(2, testDataProperties.getRequests().size());

    assertEquals(null, testDataProperties.getRequests().get("wp2-bestex").getGlobalPattern());
    assertEquals(".*", testDataProperties.getRequests().get("wp2-deposit").getGlobalPattern());


  }
}

package de.dwpbank.wpio.loadtest.backend.messagestore;

import static org.junit.jupiter.api.Assertions.assertEquals;

import de.dwpbank.wpio.loadtest.backend.RequestProperties;
import de.dwpbank.wpio.loadtest.backend.TestDataProperties;
import de.dwpbank.wpio.loadtest.backend.messagestore.Message;
import de.dwpbank.wpio.loadtest.backend.messagestore.MessageStore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;

public class MessageStoreTest {

  @Test
  public void basicStoreTest() throws Exception {

    List<String> patterns = new ArrayList<>();
    List<String> response = new ArrayList<>();

    response.add("testdata.1.response.1.audit");
    patterns.add(".*");
    response.add("testdata.1.response.2.audit");
    patterns.add(".*");

    RequestProperties requestProperties = new RequestProperties();
    requestProperties.setApplIdentityData("testAppIdentityData");
    requestProperties.setInputQueue("testQueue");
    requestProperties.setResponse(response);
    requestProperties.setPattern(patterns);

    Map<String, RequestProperties> requests = new HashMap<>();
    requests.put("test", requestProperties);

    TestDataProperties testDataProperties = new TestDataProperties();
    testDataProperties.setFolder("src/test/resources/testdata");
    testDataProperties.setDefaultResponse("wp2-error-response.txt");
    testDataProperties.setRequests(requests);

    MessageStore store = new MessageStore(testDataProperties);

    store.init();

    List<Message> results = store
        .getMessageByPatternMatching("testAppIdentityData", "any message");
    assertEquals(2, results.size());

  }

  @Test
  public void patternMatchingTest() throws Exception {

    List<String> patterns = new ArrayList<>();
    List<String> response = new ArrayList<>();

    response.add("testdata.1.response.1.audit");
    patterns.add("any message");
    response.add("testdata.1.response.2.audit");
    patterns.add("not my message");

    RequestProperties requestProperties = new RequestProperties();
    requestProperties.setApplIdentityData("testAppIdentityData");
    requestProperties.setInputQueue("testQueue");
    requestProperties.setResponse(response);
    requestProperties.setPattern(patterns);

    Map<String, RequestProperties> requests = new HashMap<>();
    requests.put("test", requestProperties);

    TestDataProperties testDataProperties = new TestDataProperties();
    testDataProperties.setFolder("src/test/resources/testdata");
    testDataProperties.setDefaultResponse("wp2-error-response.txt");
    testDataProperties.setRequests(requests);

    MessageStore store = new MessageStore(testDataProperties);

    store.init();

    List<Message> results = store
        .getMessageByPatternMatching("testAppIdentityData", "any message");
    assertEquals(1, results.size());

    results = store.getMessageByPatternMatching("testAppIdentityData", "no match");
    assertEquals(0, results.size());

  }

  @Test
  public void patternMatchingExtendedTest() throws Exception {

    List<String> patterns = new ArrayList<>();
    List<String> response = new ArrayList<>();

    response.add("testdata.1.response.1.audit");
    patterns.add("9012021012906111407684199128593879");

    response.add("testdata.1.response.2_1.audit");
    patterns.add("90120210204122652308108012354072");
    response.add("testdata.1.response.2_2.audit");
    patterns.add("90120210204122652308108012354072");

    RequestProperties requestProperties = new RequestProperties();
    requestProperties.setApplIdentityData("testAppIdentityData");
    requestProperties.setInputQueue("testQueue");
    requestProperties.setResponse(response);
    requestProperties.setPattern(patterns);

    Map<String, RequestProperties> requests = new HashMap<>();
    requests.put("test", requestProperties);

    TestDataProperties testDataProperties = new TestDataProperties();
    testDataProperties.setFolder("src/test/resources/testdata");
    testDataProperties.setDefaultResponse("wp2-error-response.txt");
    testDataProperties.setRequests(requests);

    MessageStore store = new MessageStore(testDataProperties);

    store.init();

    List<Message> results = store
        .getMessageByPatternMatching("testAppIdentityData", "incoming.9012021012906111407684199128593879.message");
    assertEquals(1, results.size());

    results = store.getMessageByPatternMatching("testAppIdentityData", "no match");
    assertEquals(0, results.size());

    results = store.getMessageByPatternMatching("testAppIdentityData", "incoming.90120210204122652308108012354072.message");
    assertEquals(2, results.size());

  }

  @Test
  public void globalPatternMatchingExtendedTest() throws Exception {

    List<String> patterns = new ArrayList<>();
    List<String> response = new ArrayList<>();

    response.add("testdata.1.response.1.audit");
    patterns.add("Invalid pattern - globalPattern must be stringer");

    response.add("testdata.1.response.2_1.audit");
    response.add("testdata.1.response.2_2.audit");

    RequestProperties requestProperties = new RequestProperties();
    requestProperties.setApplIdentityData("testAppIdentityData");
    requestProperties.setInputQueue("testQueue");
    requestProperties.setResponse(response);
    requestProperties.setPattern(patterns);
    requestProperties.setGlobalPattern(".*");

    Map<String, RequestProperties> requests = new HashMap<>();
    requests.put("test", requestProperties);

    TestDataProperties testDataProperties = new TestDataProperties();
    testDataProperties.setFolder("src/test/resources/testdata");
    testDataProperties.setDefaultResponse("wp2-error-response.txt");
    testDataProperties.setRequests(requests);

    MessageStore store = new MessageStore(testDataProperties);

    store.init();

    List<Message> results = store
            .getMessageByPatternMatching("testAppIdentityData", "Any payload");
    assertEquals(3, results.size());

  }

}

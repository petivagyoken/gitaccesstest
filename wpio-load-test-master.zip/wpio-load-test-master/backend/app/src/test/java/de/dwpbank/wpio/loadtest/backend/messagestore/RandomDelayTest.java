package de.dwpbank.wpio.loadtest.backend.messagestore;

import de.dwpbank.wpio.loadtest.backend.RandomDelay;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.lessThan;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class RandomDelayTest {

  @Test
  public void testDelayGenerator() {

    int avg = 100;
    int deviationPercent = 40;

    for (int i=0; i< 10000; i++) {
      int random = RandomDelay.getRandomDelay(avg, deviationPercent);
      System.out.println(random);
      assertThat(random, allOf(greaterThan(59), lessThan(141)));
    }

    avg = 50;
    deviationPercent = 20;

    for (int i=0; i< 10000; i++) {
      int random = RandomDelay.getRandomDelay(avg, deviationPercent);
      System.out.println(random);
      assertThat(random, allOf(greaterThan(39), lessThan(61)));
    }
  }

  @Test
  public void testDelayGeneratorWithZeroDeviation() {
    int avg = 100;
    int deviationPercent = 0;

    for (int i=0; i< 10000; i++) {
      int random = RandomDelay.getRandomDelay(avg, deviationPercent);
      assertEquals(100, random);
    }
  }

}

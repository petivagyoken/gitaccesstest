package de.dwpbank.wpio.loadtest.backend;

import com.ibm.mq.constants.MQConstants;
import com.ibm.msg.client.jms.JmsConstants;
import com.ibm.msg.client.wmq.WMQConstants;
import de.dwpbank.wpio.loadtest.backend.messagestore.MessageStore;
import de.dwpbank.wpio.loadtest.common.MetricsConfiguration;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.core.JmsTemplate;

@Slf4j
public class Listener implements MessageListener {

  private static final SimpleDateFormat wmqDateFormat = new SimpleDateFormat("yyyyMMdd");
  private static final SimpleDateFormat wmqTimeFormat = new SimpleDateFormat("HHmmssSS");

  private final TestDataProperties testDataProperties;
  private final MessageStore messageStore;
  private final JmsTemplate jmsTemplate;
  private final String inputQueue;

  private Counter incomingRequestsCounter;
  private Counter outgoingResponsesCounter;
  private Counter invalidRequestsCounter;
  private Counter unknownRequestTypeCounter;

  private Timer responseTimeTimer;

  Listener(MeterRegistry meterRegistry, String inputQueue,
      TestDataProperties testDataProperties,
      MessageStore messageStore, JmsTemplate jmsTemplate) {
    this.inputQueue = inputQueue;
    this.testDataProperties = testDataProperties;
    this.messageStore = messageStore;
    this.jmsTemplate = jmsTemplate;
    initializeMetrics(meterRegistry);
  }

  private void initializeMetrics(MeterRegistry meterRegistry) {
    this.incomingRequestsCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_QUEUE, this.inputQueue)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_REQUEST)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY,
            MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY_IN)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_NONE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION)
        .register(meterRegistry);

    this.outgoingResponsesCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_QUEUE, this.inputQueue)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_REQUEST)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY,
            MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY_OUT)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_RESPONSE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION)
        .register(meterRegistry);

    this.invalidRequestsCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_QUEUE, this.inputQueue)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_REQUEST)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_INVALID_MESSAGE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_DESCRIPTION)
        .register(meterRegistry);

    this.unknownRequestTypeCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_QUEUE, this.inputQueue)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_REQUEST)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_UNKNOWN_REQUEST)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_DESCRIPTION)
        .register(meterRegistry);

    this.responseTimeTimer = Timer
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_RESPONSETIME_NAME)
        .publishPercentileHistogram(true)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_RESPONSETIME_DESCRIPTION)
        .register(meterRegistry);
  }

  @Override
  public void onMessage(Message message) {
    this.responseTimeTimer.record(() -> {
      try {
        processIncomingMessage(message);
      } catch (JMSException e) {
        e.printStackTrace();
      }
    });
  }

  private void processIncomingMessage(final Message receivedMessage) throws JMSException {
    incomingRequestsCounter.increment();

    String content = receivedMessage.getBody(String.class);

    if (log.isDebugEnabled()) {
      log.debug("==== Got message from {} ====", this.inputQueue);

      log.trace("Header field messageId={}", receivedMessage.getJMSMessageID());
      log.trace("Header field correlId={}", receivedMessage.getJMSCorrelationID());
      log.trace("Header field msgType={}",
          receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE));
      log.trace("Header field putDate={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTDATE));
      log.trace("Header field putTime={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTTIME));
      log.trace("Header field replyToQ={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ));
      log.trace("Header field persistence={}",
          receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_PERSISTENCE));
      log.trace("Header field applIdentityData={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_APPLIDENTITYDATA));
      log.trace("Header field applOriginData={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_APPLORIGINDATA));
      log.trace("Header field backoutCount={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_BACKOUTCOUNT));
      log.trace("Content (first 200 bytes): {}",
          content.substring(0, Math.min(content.length(), 200)));
    }

    String messageId = receivedMessage.getJMSMessageID();
    String corrId = receivedMessage.getJMSCorrelationID();
    String replyToQ = receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ);
    String applIdentityData = receivedMessage
        .getStringProperty(WMQConstants.JMS_IBM_MQMD_APPLIDENTITYDATA);

    if (replyToQ == null || replyToQ.trim().isEmpty()) {
      log.error("Unable to send response, ReplyToQueue not specified!");
      invalidRequestsCounter.increment();
      return;
    }

    applIdentityData = applIdentityData != null ? applIdentityData.replaceAll("\\d{10}$", "")
        : applIdentityData;

    if (applIdentityData != null && messageStore.isApplIdentityDataKnown(applIdentityData.trim())) {
      // send regular response
      List<de.dwpbank.wpio.loadtest.backend.messagestore.Message> responsemessages = messageStore.getMessageByPatternMatching(applIdentityData.trim(), content);
      if (responsemessages.isEmpty()) {
        log.warn("Did not find a matching response in message store. Check for regex misconfiguration.");
      }

      // Delay, if configured
      if(responsemessages.size() > 0 && responsemessages.get(0).getAvgDelay() != 0 ) {
        int avgDelay = responsemessages.get(0).getAvgDelay();
        int maxDeviationPercent = responsemessages.get(0).getMaxDeviationPercent();

        try {
          int delay = RandomDelay.getRandomDelay(avgDelay, maxDeviationPercent);
          Thread.sleep(delay);
          log.debug("Delayed sending output messages for {} ms (delay settings are: avg {}, maxDevPercent {})",
              delay, avgDelay, maxDeviationPercent);
        } catch (InterruptedException e) {
          log.error(e.getLocalizedMessage());
        }
      }

      // Send output messages at whole
      for (de.dwpbank.wpio.loadtest.backend.messagestore.Message responseContent : responsemessages) {
        sendResponseMessage(replyToQ, messageId, corrId, responseContent.getMessage());
        outgoingResponsesCounter.increment();
      }
      log.debug("Sent {} response messages.", responsemessages.size());

    } else {
      log.warn("ApplidentityData does not match, sending default response...! (got '{}')",
          applIdentityData);
      unknownRequestTypeCounter.increment();
      sendResponseMessage(replyToQ, messageId, corrId, messageStore.getDefaultResponse());
      outgoingResponsesCounter.increment();
    }

  }

  private void sendResponseMessage(String queue, String messageId, String corrId, String content) {

    jmsTemplate.send(queue, messageCreator -> {

      TextMessage message = messageCreator.createTextMessage(content);

      // TODO: Strange usage mix of Constants (JmsConstants, WMQConstants,
      // MQConstants)! Check if this can be harmonized.

      message.setIntProperty(WMQConstants.WMQ_MQMD_MESSAGE_CONTEXT,
          WMQConstants.WMQ_MDCTX_SET_ALL_CONTEXT);
      message.setIntProperty(JmsConstants.JMS_IBM_MSGTYPE, MQConstants.MQMT_REPLY);

      if (testDataProperties.getCorrelationidMessageidResponseMode().equals("straight")) {
        message.setJMSCorrelationID(corrId);
        message.setJMSMessageID(messageId);
      } else {
        message.setJMSCorrelationID(messageId);
        message.setJMSMessageID(corrId);
      }

      message
          .setIntProperty(WMQConstants.JMS_IBM_MQMD_PERSISTENCE, MQConstants.MQPER_NOT_PERSISTENT);

      Timestamp timestamp = new Timestamp(System.currentTimeMillis());

      message.setStringProperty(WMQConstants.JMS_IBM_MQMD_PUTDATE, wmqDateFormat.format(timestamp));
      message.setStringProperty(WMQConstants.JMS_IBM_MQMD_PUTTIME, wmqTimeFormat.format(timestamp));

      if (log.isDebugEnabled()) {
        log.debug("Sending response message to {}", queue);

        log.trace("Header field messageId={}", message.getJMSMessageID());
        log.trace("Header field correlId={}", message.getJMSCorrelationID());
        log.trace("Header field putDate={}",
            message.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTDATE));
        log.trace("Header field putTime={}",
            message.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTTIME));

        log.trace("Content (first 200 bytes): {}",
            content.substring(0, Math.min(content.length(), 200)));
      }

      return message;
    });
  }

}

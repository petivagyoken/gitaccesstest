package de.dwpbank.wpio.loadtest.backend.messagestore;

import de.dwpbank.wpio.loadtest.backend.RequestProperties;
import de.dwpbank.wpio.loadtest.backend.TestDataProperties;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Repository
public class MessageStore {

  private static final Charset UTF8 = StandardCharsets.UTF_8;
  private static final Charset ISO8859_1 = StandardCharsets.ISO_8859_1;
  private final TestDataProperties testDataProperties;
  private final Map<String, ResponseData> responses = new ConcurrentHashMap<>();
  @Getter private String defaultResponse = "Request rejected (No or unknown APPL_IDENTITY_DATA)";

  public MessageStore(TestDataProperties testDataProperties) {
    this.testDataProperties = testDataProperties;
  }

  @PostConstruct
  public void init() throws Exception {
    try {
      buildMessageStore();
    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    }
  }

  public boolean isApplIdentityDataKnown(String applIdentityData) {
    return applIdentityData != null && responsesContainsKeyStartingWithKey(applIdentityData);
  }

  private boolean responsesContainsKeyStartingWithKey(String key) {
    boolean found = false;
    for (Map.Entry<String, ResponseData> e : responses.entrySet()) {
      if (key.startsWith(e.getKey())) {
        found = true;
      }
    }
    return found;
  }

  private String getKeyStartingWith(String key) {
    for (Map.Entry<String, ResponseData> e : responses.entrySet()) {
      if (key.startsWith(e.getKey())) {
        return e.getKey();
      }
    }
    return "";
  }

  public List<Message> getMessageByPatternMatching(String applIdentityData, String payload) {
    List<Message> results = new ArrayList<>();
    ResponseData responseData = responses.get(getKeyStartingWith(applIdentityData));
    log.debug("Checking patterns of appId {}.", applIdentityData);

    for (Message message : responseData.getMessages()) {
      log.trace("Checking pattern {}...", message.getPattern().toString());
      if (message.getPattern().matcher(payload).find()) {
        log.debug(
            "Message {} pattern {} added", message.getMessage(), message.getPattern().toString());
        results.add(message);
      }
    }

    log.debug(
        "Found {} messages by comparing {} patterns.",
        results.size(),
        responseData.getMessages().size());
    if (results.size() == 0) {
      log.warn("No message found for {}, payload {}", applIdentityData, payload);
    }
    return results;
  }

  private void buildMessageStore() throws Exception {

    if (StringUtils.isEmpty(testDataProperties.getFolder())) {
      throw new Exception(
          "Please specify correct testdata location in application.properties file!");
    }

    Path testdataPath = Paths.get(testDataProperties.getFolder());

    if (Files.notExists(testdataPath)) {
      throw new Exception(String.format("testdata folder '%s' does not exist!", testdataPath));
    }

    int counter = 0;
    try {
      log.info("Configured requests: {}", testDataProperties.getRequests().size());

      for (String requestName : testDataProperties.getRequests().keySet()) {
        log.info("Adding messages for '{}' to message store....", requestName);

        RequestProperties requestProperties = testDataProperties.getRequests().get(requestName);
        String appId = requestProperties.getApplIdentityData();

        ResponseData responseData = new ResponseData(appId);
        if (responses.get(appId) != null) {
          // Load existing entries to AppId instead, if existing
          responseData = responses.get(appId);
        }

        for (int i = 0; i < requestProperties.getResponse().size(); i++) {
          String message =
              loadMessageFromFile(testdataPath, requestProperties.getResponse().get(i));

          // calculate pattern
          String pattern;
          if (!StringUtils.isEmpty(requestProperties.getGlobalPattern())) {
            pattern = requestProperties.getGlobalPattern();
          } else {
            pattern = requestProperties.getPattern().get(i);
          }

          responseData
              .getMessages()
              .add(
                  new Message(
                      message,
                      pattern,
                      requestProperties.getAvgDelay(),
                      requestProperties.getMaxDeviationPercent()));

          counter++;
          log.trace(
              "Added response message for AppId {}, pattern {}, with message delay: {}, {}",
              requestProperties.getApplIdentityData(),
              pattern,
              requestProperties.getAvgDelay(),
              requestProperties.getMaxDeviationPercent());
        }

        responses.put(requestProperties.getApplIdentityData(), responseData);
      }
    } catch (Exception e) {
      throw new Exception("Error creating message store: " + e.getMessage(), e);
    }

    log.info("Created message store with {} response messages.", counter);

    if (!StringUtils.isEmpty(testDataProperties.getDefaultResponse())) {
      try {
        this.defaultResponse =
            loadMessageFromFile(testdataPath, testDataProperties.getDefaultResponse());
        log.info("Loaded default response into message store");
      } catch (Exception e) {
        throw new Exception("Error loading default response into message store: " + e.getMessage());
      }
    }
  }

  private String loadMessageFromFile(Path folder, String filename, Charset encoding)
      throws Exception {
    log.info("loadMessageFromFile folder {}", folder.toString());
    log.info("loadMessageFromFile filename {}", filename);
    Path inputFile = Paths.get(folder.toString(), filename);

    if (Files.notExists(inputFile)) {
      throw new FileNotFoundException("Testdata file does not exist: " + filename);
    }

    String message;
    try {
      message = Files.readString(inputFile, encoding);
      log.debug(
          "loaded testdata message {}. Content (first 200 bytes): {}",
          filename,
          message.substring(0, Math.min(message.length(), 200)));
    } catch (IOException e) {
      throw new IOException("Error reading testdata file " + filename, e);
    }

    return message;
  }

  /**
   * Reading from text file to String. If UTF-8 fails, second try with ISO-8859-1. If that fails as
   * well Exception is thrown.
   */
  private String loadMessageFromFile(Path folder, String filename) throws IOException {
    Path inputFile = Paths.get(folder.toString(), filename);

    if (Files.notExists(inputFile)) {
      throw new FileNotFoundException("Testdata file does not exist: " + filename);
    }

    String message;
    try {
      message = Files.readString(inputFile, UTF8);
      log.debug(
          "loaded testdata message {}. Content (first 200 bytes): {}",
          filename,
          message.substring(0, Math.min(message.length(), 200)));
    } catch (IOException e) {
      log.warn("Reading file with UTF-8 encoding failed, trying ISO");
      try {
        message = Files.readString(inputFile, ISO8859_1);
      } catch (IOException e1) {
        throw new IOException("Error reading testdata file " + filename, e);
      }
    }

    return message;
  }
}

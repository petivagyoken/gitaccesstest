package de.dwpbank.wpio.loadtest.backend;

import de.dwpbank.wpio.loadtest.backend.messagestore.MessageStore;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListenerConfigurer;
import org.springframework.jms.config.JmsListenerEndpointRegistrar;
import org.springframework.jms.config.SimpleJmsListenerEndpoint;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class DynamicListenerConfigurer implements JmsListenerConfigurer {

  @Autowired
  private TestDataProperties testDataProperties;

  @Autowired
  private MessageStore messageStore;

  @Autowired
  private JmsTemplate jmsTemplate;

  @Autowired
  private MeterRegistry meterRegistry;

  @Value("${jms.concurrency:5-30}")
  private String jmsConcurreny;

  @Override
  public void configureJmsListeners(JmsListenerEndpointRegistrar registrar) {
    for (String inputQueue : testDataProperties.getInputQueues()) {
      SimpleJmsListenerEndpoint endpoint = new SimpleJmsListenerEndpoint();
      endpoint.setConcurrency(jmsConcurreny);
      endpoint.setMessageListener(new Listener(meterRegistry, inputQueue, testDataProperties, messageStore, jmsTemplate));
      endpoint.setId(inputQueue);
      endpoint.setDestination(inputQueue);
      registrar.registerEndpoint(endpoint);
      log.info("Starting to consume queue {}...", inputQueue);
    }
  }

}
package de.dwpbank.wpio.loadtest.common;

import com.ibm.mq.jms.MQDestination;
import com.ibm.msg.client.wmq.WMQConstants;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Session;
import org.springframework.jms.support.destination.DynamicDestinationResolver;
import org.springframework.stereotype.Component;

/*
We are activating the native Websphere MQ mode for all Destinations. By doing this you cannot use JMS methods
at the message any more to set values, you have to use the Property setters...
 */
@Component
public class NativeWMQDestinationResolver extends DynamicDestinationResolver {

  @Override
  public Destination resolveDestinationName(Session session, String destinationName,
      boolean pubSubDomain) throws JMSException {
    Destination destination = super.resolveDestinationName(session, destinationName, pubSubDomain);
    if (destination instanceof MQDestination) {
      MQDestination mqDestination = (MQDestination) destination;
      mqDestination.setFailIfQuiesce(WMQConstants.WMQ_FIQ_YES);
      mqDestination.setTargetClient(WMQConstants.WMQ_CLIENT_NONJMS_MQ);
      mqDestination.setBooleanProperty(WMQConstants.WMQ_MQMD_READ_ENABLED, true);
      mqDestination.setBooleanProperty(WMQConstants.WMQ_MQMD_WRITE_ENABLED, true);
      mqDestination.setIntProperty(WMQConstants.WMQ_MQMD_MESSAGE_CONTEXT,
          WMQConstants.WMQ_MDCTX_SET_ALL_CONTEXT);
    }
    return destination;
  }

}

package de.dwpbank.wpio.loadtest.backend.messagestore;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseData {

  private String applIdentityData;
  private List<Message> messages = new ArrayList<>();

  public ResponseData(String applIdentityData) {
    this.applIdentityData = applIdentityData;
  }
}
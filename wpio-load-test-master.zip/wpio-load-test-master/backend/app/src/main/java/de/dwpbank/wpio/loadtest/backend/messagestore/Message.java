package de.dwpbank.wpio.loadtest.backend.messagestore;

import java.util.regex.Pattern;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Message {

  private Pattern pattern;
  private String message;
  private int avgDelay;
  private int maxDeviationPercent;

  Message(String message, String pattern) {
    this.message = message;
    this.pattern = Pattern.compile(pattern);
  }

  Message(String message, String pattern, int avgDelay, int maxDeviationPercent) {
    this(message, pattern);
    this.avgDelay = avgDelay;
    this.maxDeviationPercent = maxDeviationPercent;
  }
}

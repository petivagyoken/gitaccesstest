package de.dwpbank.wpio.loadtest.backend;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Setter
@Getter
@ConfigurationProperties(prefix = "wpio.testdata")
@Configuration
public class TestDataProperties {

  private String folder;
  private Map<String, RequestProperties> requests;
  private String defaultResponse;
  private String correlationidMessageidResponseMode;

  public List<String> getInputQueues() {
    List<String> inputQueues = new ArrayList<String>();
    for (RequestProperties requestProperties : requests.values()) {
      if (!inputQueues.contains(requestProperties.getInputQueue())) {
        inputQueues.add(requestProperties.getInputQueue());
      }
    }
    return inputQueues;
  }

}

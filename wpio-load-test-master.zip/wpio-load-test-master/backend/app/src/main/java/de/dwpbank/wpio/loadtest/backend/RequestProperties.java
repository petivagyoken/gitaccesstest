package de.dwpbank.wpio.loadtest.backend;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RequestProperties {

  private String inputQueue;
  private String applIdentityData;
  private List<String> response;
  private List<String> pattern;
  private int avgDelay;
  private int maxDeviationPercent;
  private String globalPattern;
}

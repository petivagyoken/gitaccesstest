package de.dwpbank.wpio.loadtest.common;

import javax.naming.NamingException;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

//TODO: Check if something has to be changed regarding the CachingConnectionFactory because of https://stackoverflow.com/questions/21984319/why-defaultmessagelistenercontainer-should-not-use-cachingconnectionfactory

@Configuration
public class MQConfiguration {

  @Bean
  public DefaultJmsListenerContainerFactory myFactory(
          CachingConnectionFactory cachingConnectionFactory,
      DefaultJmsListenerContainerFactoryConfigurer configurer) {

    DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();

    // lambda function
    factory.setErrorHandler(t -> System.err.println("An error has occurred in the transaction"));

    configurer.configure(factory, cachingConnectionFactory);
    return factory;
  }

  @Bean
  public JmsTemplate jmsTemplate(CachingConnectionFactory cachingConnectionFactory,
                                 NativeWMQDestinationResolver nativeWMQDestinationResolver) {
    JmsTemplate jmsTemplate = new JmsTemplate(cachingConnectionFactory);

    jmsTemplate.setExplicitQosEnabled(true);
    //For our tests non persistent delivery is ok most of the time. This can be overwritten during sending
    jmsTemplate.setDeliveryPersistent(false);
    jmsTemplate.setDestinationResolver(nativeWMQDestinationResolver);

    return jmsTemplate;
  }
}

package de.dwpbank.wpio.loadtest.common;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.config.MeterFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MetricsConfiguration {

  public final static String WPIOLOADTEST_METRIC_MESSAGES_NAME = "wpioloadtest.messages.total";
  public final static String WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION = "Processed messages";

  public final static String WPIOLOADTEST_METRIC_ERRORS_NAME = "wpioloadtest.errors.total";
  public final static String WPIOLOADTEST_METRIC_ERRORS_DESCRIPTION = "Number of errors";

  public final static String WPIOLOADTEST_LABEL_ROUTE = "route";
  public final static String WPIOLOADTEST_LABEL_ROUTE_REQUEST = "request";
  public final static String WPIOLOADTEST_LABEL_ROUTE_RESPONSE = "response";

  public final static String WPIOLOADTEST_LABEL_BOUNDARY = "boundary";
  public final static String WPIOLOADTEST_LABEL_BOUNDARY_IN = "in";
  public final static String WPIOLOADTEST_LABEL_BOUNDARY_OUT = "out";

  public final static String WPIOLOADTEST_LABEL_SERVICE = "service";

  public final static String WPIOLOADTEST_LABEL_DETAIL = "detail";
  public final static String WPIOLOADTEST_LABEL_DETAIL_NONE = "none";
  public final static String WPIOLOADTEST_LABEL_DETAIL_REQUEST = "request";
  public final static String WPIOLOADTEST_LABEL_DETAIL_RESPONSE = "response";
  public final static String WPIOLOADTEST_LABEL_DETAIL_INVALID_MESSAGE = "invalidMessage";
  public final static String WPIOLOADTEST_LABEL_DETAIL_UNKNOWN_REQUEST = "unknownRequest";
  public final static String WPIOLOADTEST_LABEL_DETAIL_LATE_RESPONSE = "lateResponse";
  public final static String WPIOLOADTEST_LABEL_DETAIL_ESB_ERROR_RESPONSE = "esbErrorResponse";

  public final static String WPIOLOADTEST_METRIC_RESPONSETIME_NAME = "wpioloadtest.responsetime"; // unit is added automatically
  public final static String WPIOLOADTEST_METRIC_RESPONSETIME_DESCRIPTION = "Response time of simulator";

  public final static String WPIOLOADTEST_LABEL_QUEUE = "queue";

  @Bean
  public MeterRegistryCustomizer<MeterRegistry> metricsRegistry(
      @Value("${wpio.servicename}") String serviceName) {
    return registry -> registry.config()
        .commonTags(WPIOLOADTEST_LABEL_SERVICE, serviceName)
        .meterFilter(MeterFilter.deny(id -> {
          // deny metrics on /actuator/prometheus and /**/favicon.ico, they are not needed...
          String uri = id.getTag("uri");
          return uri != null && (uri.startsWith("/actuator/prometheus")
              || uri.startsWith("/**/favicon.ico"));
        }));
  }

}

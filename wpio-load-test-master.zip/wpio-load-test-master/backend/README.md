# MQ Backend Simulator

Simulates a WPIO backend accepting requests via native IBM Websphere MQ and replying via MsgId/CorrelId pattern.

## Local development

```
cd localtest/
docker-compose up -d wmq

cd ../app/
mvn spring-boot:run
```

## Local test

```
cd localtest/
docker-compose up -d
```

## Prometheus metrics

See ../genericservice/README.md for details.

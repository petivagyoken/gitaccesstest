#!/bin/bash

#set -x

rm -rf tmp

mkdir -p \
  tmp/logs \
  tmp/logs/routingdb \
  tmp/logs/routingdata \
  tmp/logs/rp \
  tmp/logs/rp-audit-move \
  tmp/logs/rp-kafka \
  tmp/logs/rr-l1 \
  tmp/logs/rr-l2 \
  tmp/logs/ws \
  tmp/tranlogs \
  tmp/trace \
  tmp/repositories \
  tmp/fragments \
  tmp/file_process \
  tmp/fileprocessing \
  tmp/run \
  tmp/analysis \
  tmp/reports \
  tmp/audit \
  tmp/data \
  tmp/startup

touch \
   tmp/fragments/DWP.XCHG_G32_WP2 \
   tmp/fragments/DWP.XCHG_MIC_WP2 \
   tmp/fragments/DWP.XCHG_WP2_MIC \
   tmp/fragments/DWP.WP3_ORDER \
   tmp/fragments/DWP.WP3_ORDERBOOK_OR \
   tmp/fragments/DWP.WP3_ORDERBOOK \
   tmp/fragments/DWP.WP3_QUOTE

chown -R $SUDO_USER tmp/
chmod -R 0755 tmp/data

export COMPOSE_PARALLEL_LIMIT=30

# Load specific docker-compose setup

podman pull registry.dwp/wpio/ibmmq:9.3.0.20

export HTTP_PROXY=http://dwp-pproxy1:3128
export HTTPS_PROXY=http://dwp-pproxy1:3128
export NO_PROXY="localhost,127.0.0.1,registry.cloud.fits,registry-mirror.cloud.fits"

# OS difference between Docker and Podman: Docker allowed an unlimited number of processes to be started inside
# a container, Podman default is limiting this to 2048 processes/threads...
# The default limit is to low to operate an IBM MQ server under high load, so we have to increase it.
# Current podman-compose implementation v1.0.6 does not handover a service specific pids_limit value defined
# in the docker-compose file to the podman runtime so we have to increase this value for all started containers...
$DCEXECUTABLE --podman-run-args='--http-proxy=false --pids-limit=-1' -p wpio $DOCKER_COMPOSE_FILES up -d --build

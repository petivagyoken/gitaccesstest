package de.dwpbank.wpio.loadtest.mqpurger;

import de.dwpbank.wpio.loadtest.common.MetricsConfiguration;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import javax.jms.Message;
import javax.jms.MessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.core.JmsTemplate;

@Slf4j
public class Listener implements MessageListener {

  private JmsTemplate jmsTemplate;
  private String inputQueue;
  private Counter messageCounter;

  public Listener(MeterRegistry meterRegistry, String inputQueue, JmsTemplate jmsTemplate) {
    this.inputQueue = inputQueue;
    this.jmsTemplate = jmsTemplate;
    initializeMetrics(meterRegistry);
  }

  private void initializeMetrics(MeterRegistry meterRegistry) {
    this.messageCounter = Counter.builder(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_QUEUE, this.inputQueue)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION)
        .register(meterRegistry);
  }

  @Override
  public void onMessage(Message message) {
    //Do nothing, we simply want to consume all messages...
    messageCounter.increment();
    log.debug("Removed message from {}", inputQueue);
  }
}

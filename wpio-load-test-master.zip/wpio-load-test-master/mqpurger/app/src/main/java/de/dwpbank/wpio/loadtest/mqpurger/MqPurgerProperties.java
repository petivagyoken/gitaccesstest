package de.dwpbank.wpio.loadtest.mqpurger;

import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Setter
@Getter
@ConfigurationProperties(prefix = "wpio")
public class MqPurgerProperties {

  private List<String> purgequeue;

}

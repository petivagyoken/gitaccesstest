package de.dwpbank.wpio.loadtest.mqpurger;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListenerConfigurer;
import org.springframework.jms.config.JmsListenerEndpointRegistrar;
import org.springframework.jms.config.SimpleJmsListenerEndpoint;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class DynamicListenerConfigurer implements JmsListenerConfigurer {

  @Autowired
  private MqPurgerProperties mqPurgerProperties;

  @Autowired
  private JmsTemplate jmsTemplate;

  @Autowired
  private MeterRegistry meterRegistry;

  @Value("${jms.concurrency:2-5}")
  private String jmsConcurreny;

  @Override
  public void configureJmsListeners(JmsListenerEndpointRegistrar registrar) {
    for (String purgeQueue : mqPurgerProperties.getPurgequeue()) {
      SimpleJmsListenerEndpoint endpoint = new SimpleJmsListenerEndpoint();
      endpoint.setConcurrency(jmsConcurreny);
      endpoint.setId(purgeQueue);
      endpoint.setDestination(purgeQueue);
      endpoint.setMessageListener(new Listener(meterRegistry, purgeQueue, jmsTemplate));
      registrar.registerEndpoint(endpoint);
      log.info("Starting to purge queue {}...", purgeQueue);
    }
  }

}
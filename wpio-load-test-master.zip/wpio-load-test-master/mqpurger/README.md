# MQ Purger

Listens to a predefined list of IBM MQ queues on a queuemanager and simply consums all messages (delete).

## Local development

```
cd localtest/
docker-compose up -d wmq

cd ../app/
mvn spring-boot:run
```

## Local test

```
cd localtest/
docker-compose up -d
```

package de.dwpbank.wpio.loadtest.genericservice.messagestore;

import static org.junit.jupiter.api.Assertions.assertEquals;

import de.dwpbank.wpio.loadtest.genericservice.RequestProperties;
import de.dwpbank.wpio.loadtest.genericservice.ResponseProperties;
import de.dwpbank.wpio.loadtest.genericservice.TestDataProperties;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;

public class MessageStoreTest {

  @Test
  public void basicStoreTest() throws Exception {

    List<RequestProperties> requestPropertiesList = new ArrayList<>();
    List<RequestProperties> reRequestPropertiesList = new ArrayList<>();
    List<ResponseProperties> responsePropertiesList = new ArrayList<>();

    RequestProperties requestProperties = new RequestProperties();
    requestProperties.setApplIdentityData("testAppIdentityData");
    requestProperties.setFilename("testdata.1.request.1.audit");
    requestProperties.setPattern(".*");

    requestPropertiesList.add(requestProperties);
    reRequestPropertiesList.add(requestProperties);

    ResponseProperties responseProperties = new ResponseProperties();
    responseProperties.setFilename("testdata.1.response.1.audit");
    responseProperties.setPattern(".*");

    responsePropertiesList.add(responseProperties);

    TestDataProperties testDataProperties = new TestDataProperties();
    testDataProperties.setFolder("src/test/resources/testdata");

    testDataProperties.setRequest(requestPropertiesList);
    testDataProperties.setReRequest(reRequestPropertiesList);
    testDataProperties.setResponse(responsePropertiesList);

    MessageStore store = new MessageStore(testDataProperties);

    store.init();

    List<RequestData> results = store.getRequestsByPatternMatching("any message");
    assertEquals(1, results.size());

    results = store.getReRequestsByPatternMatching("any message");
    assertEquals(1, results.size());

    List<ResponseData> results2 = store.getResponsesByPatternMatching("any message");
    assertEquals(1, results2.size());

  }

  @Test
  public void patternMatchingTest() throws Exception {

    List<RequestProperties> requestPropertiesList = new ArrayList<>();
    List<RequestProperties> reRequestPropertiesList = new ArrayList<>();
    List<ResponseProperties> responsePropertiesList = new ArrayList<>();

    RequestProperties requestProperties = new RequestProperties();
    requestProperties.setApplIdentityData("testAppIdentityData");
    requestProperties.setFilename("testdata.1.request.1.audit");
    requestProperties.setPattern("test");

    requestPropertiesList.add(requestProperties);
    reRequestPropertiesList.add(requestProperties);

    ResponseProperties responseProperties = new ResponseProperties();
    responseProperties.setFilename("testdata.1.response.1.audit");
    responseProperties.setPattern("test");

    responsePropertiesList.add(responseProperties);

    TestDataProperties testDataProperties = new TestDataProperties();
    testDataProperties.setFolder("src/test/resources/testdata");

    testDataProperties.setRequest(requestPropertiesList);
    testDataProperties.setReRequest(reRequestPropertiesList);
    testDataProperties.setResponse(responsePropertiesList);

    MessageStore store = new MessageStore(testDataProperties);

    store.init();

    List<RequestData> results = store.getRequestsByPatternMatching("any message");
    assertEquals(0, results.size());

    results = store.getRequestsByPatternMatching("test");
    assertEquals(1, results.size());

    results = store.getReRequestsByPatternMatching("any message");
    assertEquals(0, results.size());

    results = store.getReRequestsByPatternMatching("test");
    assertEquals(1, results.size());

    List<ResponseData> results2 = store.getResponsesByPatternMatching("any message");
    assertEquals(0, results2.size());

    results2 = store.getResponsesByPatternMatching("test");
    assertEquals(1, results2.size());

  }
}

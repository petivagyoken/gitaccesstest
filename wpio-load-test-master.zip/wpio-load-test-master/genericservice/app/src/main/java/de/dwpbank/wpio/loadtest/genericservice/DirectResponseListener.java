package de.dwpbank.wpio.loadtest.genericservice;

import com.ibm.msg.client.wmq.WMQConstants;
import de.dwpbank.wpio.loadtest.common.MetricsConfiguration;
import de.dwpbank.wpio.loadtest.genericservice.messagestore.MessageStore;
import de.dwpbank.wpio.loadtest.genericservice.messagestore.ResponseData;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import javax.jms.JMSException;
import javax.jms.Message;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.core.JmsTemplate;

@Slf4j
public class DirectResponseListener extends WMQListener {

  private Counter incomingRequestsCounter;
  private Counter outgoingResponsesCounter;
  private Counter invalidMessagesCounter;
  private Counter unknownRequestTypeCounter;

  public DirectResponseListener(MeterRegistry meterRegistry, String inputQueue, String outputQueue,
      TestDataProperties testDataProperties, MessageStore messageStore, JmsTemplate jmsTemplate) {
    super(meterRegistry, inputQueue, outputQueue, null, testDataProperties, messageStore, null,
        jmsTemplate);
  }

  @Override
  public void initializeMetrics() {
    this.incomingRequestsCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_REQUEST)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY,
            MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY_IN)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_NONE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION)
        .register(meterRegistry);

    this.outgoingResponsesCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_REQUEST)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY,
            MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY_OUT)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_RESPONSE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION)
        .register(meterRegistry);

    this.invalidMessagesCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_REQUEST)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_INVALID_MESSAGE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_DESCRIPTION)
        .register(meterRegistry);

    this.unknownRequestTypeCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_REQUEST)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_UNKNOWN_REQUEST)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_DESCRIPTION)
        .register(meterRegistry);
  }

  protected void processIncomingMessage(final Message receivedMessage) throws JMSException {
    incomingRequestsCounter.increment();

    String content = receivedMessage.getBody(String.class);

    if (log.isDebugEnabled()) {
      logMessageAttributes(inputQueue, receivedMessage, content);
    }

    String messageId = receivedMessage.getJMSMessageID();

    int limit = 1;
    if (isBackoutCountReached(limit, receivedMessage)) {
      invalidMessagesCounter.increment();
      log.error(
          "Got message with messageId {} more than {} time(s), message will not be processed!",
          messageId, limit);
      return;
    }

    String replyToQ = receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ);
    String applIdentityData = receivedMessage
        .getStringProperty(WMQConstants.JMS_IBM_MQMD_APPLIDENTITYDATA);

    if (replyToQ == null || replyToQ.trim().isEmpty()) {
      log.error("Unable to send output message, ReplyToQueue not specified!");
      invalidMessagesCounter.increment();
      return;
    }

    if (applIdentityData == null || !testDataProperties.getIncomingApplIdentityData()
        .equals(applIdentityData.trim())) {
      unknownRequestTypeCounter.increment();
      log.debug(
          "ApplIdentityData does not match, creating ErrorResponse...! (Expected: '{}', got '{}')",
          testDataProperties.getIncomingApplIdentityData(),
          applIdentityData);
      String errorText = String.format(
          "GenericService is unable to process this request: Unknown Appl_Identity_Data '%s'!",
          applIdentityData);
      forwardAsResponse(outputQueue, messageId, null, replyToQ,
          messageStore.createErrorResponse(errorText));
      outgoingResponsesCounter.increment();
      return;
    }

    //send regular responses
    log.debug("ApplIdentityData matches, sending regular responses...");
    for (ResponseData response : messageStore.getResponsesByPatternMatching(content)) {
      forwardAsResponse(outputQueue, messageId, null, replyToQueue, response.getMessage());
      outgoingResponsesCounter.increment();
    }
  }

}
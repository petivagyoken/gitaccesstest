package de.dwpbank.wpio.loadtest.genericservice;

import com.ibm.mq.constants.MQConstants;
import com.ibm.msg.client.jms.JmsConstants;
import com.ibm.msg.client.wmq.WMQConstants;
import de.dwpbank.wpio.loadtest.common.WPIOConstants;
import de.dwpbank.wpio.loadtest.genericservice.messagestore.MessageStore;
import io.micrometer.core.instrument.MeterRegistry;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.core.JmsTemplate;

@Slf4j
public abstract class WMQListener implements MessageListener {

  protected static final SimpleDateFormat wmqDateFormat = new SimpleDateFormat("yyyyMMdd");
  protected static final SimpleDateFormat wmqTimeFormat = new SimpleDateFormat("HHmmssSS");

  protected TestDataProperties testDataProperties;
  protected MessageStore messageStore;
  protected IdStore idStore;
  protected JmsTemplate jmsTemplate;
  protected MeterRegistry meterRegistry;
  protected String inputQueue;
  protected String outputQueue;
  protected String replyToQueue;

  public WMQListener(MeterRegistry meterRegistry, String inputQueue, String outputQueue,
      String replyToQueue, TestDataProperties testDataProperties, MessageStore messageStore,
      IdStore idStore, JmsTemplate jmsTemplate) {
    this.meterRegistry = meterRegistry;
    this.inputQueue = inputQueue;
    this.outputQueue = outputQueue;
    this.replyToQueue = replyToQueue;
    this.testDataProperties = testDataProperties;
    this.messageStore = messageStore;
    this.idStore = idStore;
    this.jmsTemplate = jmsTemplate;
    initializeMetrics();
  }

  @Override
  public void onMessage(Message message) {
    try {
      processIncomingMessage(message);
    } catch (JMSException e) {
      e.printStackTrace();
    }
  }

  protected abstract void initializeMetrics();

  protected abstract void processIncomingMessage(final Message receivedMessage) throws JMSException;

  protected boolean isErrorResponse(String content) {
    return content.substring(0, Math.min(content.length(), 100)).contains("<ErrorResponse");
  }

  protected boolean isBackoutCountReached(int limit, Message message) throws JMSException {
    String backoutCountInMsg = message.getStringProperty(WMQConstants.JMS_IBM_MQMD_BACKOUTCOUNT);

    Integer backoutCount = Integer.parseInt(backoutCountInMsg);

    return (backoutCount.intValue() > limit);
  }

  protected void logMessageAttributes(final String inputQueue, final Message receivedMessage,
      String content) throws JMSException {
    log.debug("Got message from {}", inputQueue);

    log.debug("Header field format={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_FORMAT));
    log.debug("Header field messageId={}", receivedMessage.getJMSMessageID());
    log.debug("Header field correlId={}", receivedMessage.getJMSCorrelationID());
    log.debug("Header field msgType={}",
        receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE));
    log.debug("Header field putDate={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTDATE));
    log.debug("Header field putTime={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTTIME));
    log.debug("Header field replyToQ={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ));
    log.debug("Header field persistence={}",
        receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_PERSISTENCE));
    log.debug("Header field applName={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTAPPLNAME));
    log.debug("Header field userIdentifier={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_USERIDENTIFIER));
    log.debug("Header field applIdentityData={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_APPLIDENTITYDATA));
    log.debug("Header field applOriginData={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_APPLORIGINDATA));
    log.debug("Header field backoutCount={}",
        receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_BACKOUTCOUNT));
    log.debug("Header field msgSeqNumber={}",
        receivedMessage.getLongProperty(WMQConstants.JMS_IBM_MQMD_MSGSEQNUMBER));
    log.debug("Header field offset={}",
        receivedMessage.getLongProperty(WMQConstants.JMS_IBM_MQMD_OFFSET));
    log.debug("Header field msgFlags={}",
        receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_MSGFLAGS));
    log.debug("Header field encoding={}",
        receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_ENCODING));
    log.debug("Header field codedCharSetId={}",
        receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_CODEDCHARSETID));

    int maxMsgLength = 400;
    log.debug("Content (first {} of {} bytes)={}", maxMsgLength, content.length(),
        content.substring(0, Math.min(content.length(), maxMsgLength)));
  }

  protected void forwardAsResponse(String outQueue, String correlId, String applIdentityData,
      String replyToQueue, String content) {
    sendWMQMessage(WPIOConstants.MSGTYPE_RESPONSE, outQueue, correlId,
        testDataProperties.getApplName(), applIdentityData, null, replyToQueue, content);
  }

  protected void forwardAsRequest(String outQueue, String correlId, String applIdentityData,
      String replyToQueue, String content) {
    sendWMQMessage(WPIOConstants.MSGTYPE_REQUEST, outQueue, correlId,
        testDataProperties.getApplName(), applIdentityData, null, replyToQueue, content);
  }

  private void sendWMQMessage(int mqMsgType, String outQueue, String correlId, String applName,
      String applIdentityData, String applOriginData, String replyToQueue, String content) {

    jmsTemplate.send(outQueue, messageCreator -> {

      TextMessage message =
          messageCreator.createTextMessage(content);

      //TODO: Strange usage mix of Constants (JmsConstants, WMQConstants, MQConstants)! Check if this can be harmonized.

      message.setIntProperty(WMQConstants.WMQ_MQMD_MESSAGE_CONTEXT,
          WMQConstants.WMQ_MDCTX_SET_ALL_CONTEXT);

      message.setIntProperty(JmsConstants.JMS_IBM_MSGTYPE, mqMsgType);
      if (mqMsgType == MQConstants.MQMT_REQUEST) {
        message.setStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ, replyToQueue);
      }

      message.setJMSCorrelationID(correlId);

      if (applIdentityData != null) {
        message.setStringProperty(WMQConstants.JMS_IBM_MQMD_APPLIDENTITYDATA, applIdentityData);
      }

      message
          .setIntProperty(WMQConstants.JMS_IBM_MQMD_PERSISTENCE, MQConstants.MQPER_NOT_PERSISTENT);
      message.setJMSPriority(0);

      if (applName != null) {
        message.setStringProperty(WMQConstants.JMS_IBM_MQMD_PUTAPPLNAME, applName);
      }

      if (applOriginData != null) {
        message.setStringProperty(WMQConstants.JMS_IBM_MQMD_APPLORIGINDATA, applOriginData);
      }

      Timestamp timestamp = new Timestamp(System.currentTimeMillis());
      message.setStringProperty(WMQConstants.JMS_IBM_MQMD_PUTDATE, wmqDateFormat.format(timestamp));
      message.setStringProperty(WMQConstants.JMS_IBM_MQMD_PUTTIME, wmqTimeFormat.format(timestamp));

      message.setIntProperty(WMQConstants.JMS_IBM_MQMD_MSGFLAGS,
          MQConstants.MQMF_SEGMENTATION_ALLOWED);

      return message;
    });
  }
}

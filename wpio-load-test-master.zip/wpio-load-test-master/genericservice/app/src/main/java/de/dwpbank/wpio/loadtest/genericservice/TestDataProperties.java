package de.dwpbank.wpio.loadtest.genericservice;

import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Setter
@Getter
@ConfigurationProperties(prefix = "wpio.testdata")
public class TestDataProperties {

  private String folder;
  private String applName;
  private String incomingApplIdentityData;
  private List<RequestProperties> request;
  private List<RequestProperties> reRequest;
  private List<ResponseProperties> response;
  private String backendError;

}

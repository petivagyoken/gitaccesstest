package de.dwpbank.wpio.loadtest.genericservice;

import de.dwpbank.wpio.loadtest.genericservice.messagestore.MessageStore;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListenerConfigurer;
import org.springframework.jms.config.JmsListenerEndpointRegistrar;
import org.springframework.jms.config.SimpleJmsListenerEndpoint;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class DynamicListenerConfigurer implements JmsListenerConfigurer {

  @Autowired
  private TestDataProperties testDataProperties;

  @Autowired
  private MessageStore messageStore;

  @Autowired
  private IdStore idStore;

  @Autowired
  private JmsTemplate jmsTemplate;

  @Autowired
  private MeterRegistry meterRegistry;

  @Value(value = "${wpio.mq.queue.request.in}")
  private String requestInputQueue;

  @Value(value = "${wpio.mq.queue.request.out}")
  private String requestOutputQueue;

  @Value(value = "${wpio.mq.queue.response.in}")
  private String responseInputQueue;

  @Value(value = "${wpio.mq.queue.response.out}")
  private String responseOutputQueue;

  @Override
  public void configureJmsListeners(JmsListenerEndpointRegistrar registrar) {
    //DirectResponse services like the WP2-MT* Swiftservices only have a request flow, AD services only a response flow.
    //In such a case one of the input flows must not be set.

    boolean requestFlowConfigured = (this.requestInputQueue != null && !this.requestInputQueue
        .trim().isEmpty());
    boolean responseFlowConfigured = (this.responseInputQueue != null && !this.responseInputQueue
        .trim().isEmpty());

    if (!requestFlowConfigured && !responseFlowConfigured) {
      log.error(
          "At a minimum either the request input queue or the response input queue has to be set correctly!");
      return;
    }

    if (requestFlowConfigured && responseFlowConfigured) {
      log.info("Instantiating Request and Response flow...");
      startRequestAndResponseFlow(registrar);
      return;
    }

    if (requestFlowConfigured) {
      log.info("Instantiating DirectResponse flow...");
      startDirectResponseFlow(registrar);
    } else {
      log.info("Instantiating AD flow...");
      startADFlow(registrar);
    }
  }

  private void startDirectResponseFlow(JmsListenerEndpointRegistrar registrar) {
    SimpleJmsListenerEndpoint requestEndpoint = new SimpleJmsListenerEndpoint();
    requestEndpoint.setMessageListener(
        new DirectResponseListener(meterRegistry, requestInputQueue, requestOutputQueue,
            testDataProperties, messageStore, jmsTemplate));
    requestEndpoint.setId(requestInputQueue);
    requestEndpoint.setDestination(requestInputQueue);
    registrar.registerEndpoint(requestEndpoint);
    log.info("Starting to consume request input queue {}...", requestInputQueue);
  }

  private void startADFlow(JmsListenerEndpointRegistrar registrar) {
    SimpleJmsListenerEndpoint responseEndpoint = new SimpleJmsListenerEndpoint();
    responseEndpoint.setMessageListener(
        new ResponseListener(meterRegistry, responseInputQueue, responseOutputQueue,
            responseInputQueue, testDataProperties, messageStore, idStore, jmsTemplate));
    responseEndpoint.setId(responseInputQueue);
    responseEndpoint.setDestination(responseInputQueue);
    registrar.registerEndpoint(responseEndpoint);
    log.info("Starting to consume response input queue {}...", responseInputQueue);
  }

  private void startRequestAndResponseFlow(JmsListenerEndpointRegistrar registrar) {
    SimpleJmsListenerEndpoint requestEndpoint = new SimpleJmsListenerEndpoint();
    requestEndpoint.setMessageListener(
        new RequestListener(meterRegistry, requestInputQueue, requestOutputQueue,
            responseInputQueue, testDataProperties, messageStore, idStore, jmsTemplate));
    requestEndpoint.setId(requestInputQueue);
    requestEndpoint.setDestination(requestInputQueue);
    registrar.registerEndpoint(requestEndpoint);
    log.info("Starting to consume request input queue {}...", requestInputQueue);

    SimpleJmsListenerEndpoint responseEndpoint = new SimpleJmsListenerEndpoint();
    responseEndpoint.setMessageListener(
        new ResponseListener(meterRegistry, responseInputQueue, responseOutputQueue,
            responseInputQueue, testDataProperties, messageStore, idStore, jmsTemplate));
    responseEndpoint.setId(responseInputQueue);
    responseEndpoint.setDestination(responseInputQueue);
    registrar.registerEndpoint(responseEndpoint);
    log.info("Starting to consume response input queue {}...", responseInputQueue);
  }

}
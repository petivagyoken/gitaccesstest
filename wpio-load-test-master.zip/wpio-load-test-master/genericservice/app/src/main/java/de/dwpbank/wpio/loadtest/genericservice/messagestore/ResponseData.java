package de.dwpbank.wpio.loadtest.genericservice.messagestore;

import java.util.regex.Pattern;
import lombok.Getter;

@Getter
public class ResponseData {

  private final Pattern pattern;
  private final String message;

  public ResponseData(String pattern, String message) {

    this.pattern = Pattern.compile(pattern);
    this.message = message;
  }
}

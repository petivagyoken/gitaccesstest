package de.dwpbank.wpio.loadtest.genericservice.messagestore;

import de.dwpbank.wpio.loadtest.genericservice.RequestProperties;
import de.dwpbank.wpio.loadtest.genericservice.ResponseProperties;
import de.dwpbank.wpio.loadtest.genericservice.TestDataProperties;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

@Slf4j
@Repository
public class MessageStore {

  private static final SimpleDateFormat wpioDateFormat = new SimpleDateFormat(
      "yyyyMMdd'T'HHmmss'.'SSS");
  private static final String errorResponseTemplate =
      "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>" +
          "<ErrorResponse xmlns=\"http://www.dwpbank.de/WPI\">" +
          "  <Header>" +
          "    <MsgTS>%s</MsgTS>" +
          "    <MsgVer>1</MsgVer>" +
          "    <MsgVerMinor>0</MsgVerMinor>" +
          "    <ClientNumber>-1</ClientNumber>" +
          "  </Header>" +
          "  <Response>" +
          "    <ErrorCd>WPILOAD</ErrorCd>" +
          "    <ErrorTxt>%s</ErrorTxt>" +
          "  </Response>" +
          "</ErrorResponse>";

  private final List<RequestData> requests = new ArrayList();

  private final List<RequestData> reRequests = new ArrayList();

  private final List<ResponseData> responses = new ArrayList();

  private final TestDataProperties testDataProperties;

  public MessageStore(TestDataProperties testDataProperties) {
    this.testDataProperties = testDataProperties;
  }

  @PostConstruct
  public void init() throws Exception {
    buildMessageStore();
  }

  public String createErrorResponse(String errorTxt) {
    String timestamp = wpioDateFormat.format(new Timestamp(System.currentTimeMillis()));
    return String.format(errorResponseTemplate, timestamp, errorTxt);
  }

  private void buildMessageStore() throws Exception {

    if (StringUtils.isEmpty(testDataProperties.getFolder())) {
      throw new Exception(
          "Please specify correct testdata location in application.properties file!");
    }

    Path testdataPath = Paths.get(testDataProperties.getFolder());

    if (Files.notExists(testdataPath)) {
      throw new Exception("testdata folder does not exist!");
    }

    int counter = 0;
    String message;

    //load requests
    if (testDataProperties.getRequest() != null) {
      try {
        for (RequestProperties requestProperties : testDataProperties.getRequest()) {
          message = loadMessageFromFile(testdataPath, requestProperties.getFilename(),
              StandardCharsets.UTF_8);
          requests.add(new RequestData(requestProperties.getApplIdentityData(),
              requestProperties.getPattern(), message));
          counter += 1;
        }
      } catch (Exception e) {
        throw new Exception("Error loading requests into message store: " + e.getMessage());
      }
    }

    //load reRequests
    if (testDataProperties.getReRequest() != null) {
      try {
        for (RequestProperties requestProperties : testDataProperties.getReRequest()) {
          message = loadMessageFromFile(testdataPath, requestProperties.getFilename(),
              StandardCharsets.UTF_8);
          reRequests.add(new RequestData(requestProperties.getApplIdentityData(),
              requestProperties.getPattern(), message));
          counter += 1;
        }
      } catch (Exception e) {
        throw new Exception("Error loading reRequests into message store: " + e.getMessage());
      }
    }
    //load responses
    if (testDataProperties.getResponse() != null) {
      try {
        for (ResponseProperties responseProperties : testDataProperties.getResponse()) {
          message = loadMessageFromFile(testdataPath, responseProperties.getFilename(),
              StandardCharsets.UTF_8);
          responses.add(new ResponseData(responseProperties.getPattern(), message));
          counter += 1;
        }
      } catch (Exception e) {
        throw new Exception("Error loading responses into message store: " + e.getMessage());
      }
    }

    log.info("Created message store with {} messages.",
        counter);

  }


  private String loadMessageFromFile(Path folder, String filename, Charset encoding)
      throws Exception {
    Path inputFile = Paths.get(folder.toString(), filename);

    if (Files.notExists(inputFile)) {
      throw new FileNotFoundException("Testdata file does not exist: " + filename);
    }

    String message;
    try {
      message = Files.readString(inputFile, encoding);
      log.debug("loaded testdata message {}. Content (first 200 bytes): {}", filename,
          message.substring(0, Math.min(message.length(), 200)));
    } catch (IOException e) {
      throw new IOException("Error reading testdata file " + filename,
          e);
    }

    return message;
  }

  public List<ResponseData> getResponsesByPatternMatching(String payload) {
    List<ResponseData> results = new ArrayList<>();

    for (ResponseData responseData : responses) {
      if (responseData.getPattern().matcher(payload).find()) {
        results.add(responseData);
      }
    }

    return results;
  }

  public List<RequestData> getRequestsByPatternMatching(String payload) {
    List<RequestData> results = new ArrayList<>();

    for (RequestData requestData : requests) {
      if (requestData.getPattern().matcher(payload).find()) {
        results.add(requestData);
      }
    }

    return results;
  }

  public List<RequestData> getReRequestsByPatternMatching(String payload) {
    List<RequestData> results = new ArrayList<>();

    for (RequestData requestData : reRequests) {
      if (requestData.getPattern().matcher(payload).find()) {
        results.add(requestData);
      }
    }

    return results;
  }

  public boolean hasReRequests() {
    return !reRequests.isEmpty();
  }

}

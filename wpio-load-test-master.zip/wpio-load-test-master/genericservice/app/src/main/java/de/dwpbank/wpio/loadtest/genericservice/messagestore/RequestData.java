package de.dwpbank.wpio.loadtest.genericservice.messagestore;

import java.util.regex.Pattern;
import lombok.Getter;

@Getter
public class RequestData {

  private final String applIdentityData;
  private final Pattern pattern;
  private final String message;

  public RequestData(String applIdentityData, String pattern, String message) {

    this.applIdentityData = applIdentityData;
    this.pattern = Pattern.compile(pattern);
    this.message = message;
  }
}
package de.dwpbank.wpio.loadtest.genericservice;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Repository;

class StoreEntry {

  private final Instant creationTime;
  private final String applName;
  private int secondsToLive;

  @Setter
  @Getter
  private boolean answered;

  public StoreEntry(String applName, int secondsToLive) {
    this.creationTime = Instant.now();
    this.secondsToLive = this.secondsToLive;
    this.applName = applName;
    this.answered = false;
  }

  public StoreEntry(StoreEntry storeEntryToClone) {
    this.creationTime = storeEntryToClone.creationTime;
    this.applName = storeEntryToClone.applName;
    this.secondsToLive = storeEntryToClone.secondsToLive;
  }

  public boolean isOutdated() {
    Duration duration = Duration.between(this.creationTime, Instant.now());
    return duration.getSeconds() > secondsToLive;
  }

}

@Slf4j
@Repository
@EnableScheduling
public class IdStore {

  private final Map<String, StoreEntry> idStore = new ConcurrentHashMap<String, StoreEntry>();
  @Autowired
  private TestDataProperties testDataProperties;

  public void addRequest(String messageId, String applName) {
    idStore.put(messageId, new StoreEntry(testDataProperties.getApplName(), 60));
  }

  public void addRequest(String messageId, String applName, int secondsToLive) {
    idStore.put(messageId, new StoreEntry(testDataProperties.getApplName(), secondsToLive));
  }

  public boolean isKnown(String messageId) {
    return (messageId != null && idStore.containsKey(messageId));
  }

  public boolean isAlreadyAnswered(String messageId) {
    StoreEntry storeEntry = idStore.get(messageId);
    return (storeEntry != null && storeEntry.isAnswered());
  }

  public void markAsAnswered(String messageId) {
    //as several threads will try to modify the Entry object we have to prevent concurrent changes.
    //ConcurrentHashMap will only prevent concurrent changes at the Map but not at the StoreEntry object itself.
    //For that we make clone, modify it and put it back to the Map.
    StoreEntry storeEntry = idStore.get(messageId);

    if (storeEntry == null) {
      log.warn(
          "Wanted to mark an entry as answered but it does not exist anymore: thread synchronisation problem?");
      return;
    }

    StoreEntry newStoreEntry = new StoreEntry(storeEntry);
    newStoreEntry.setAnswered(true);
    idStore.put(messageId, newStoreEntry);
  }

  @Scheduled(fixedRateString = "${wpio.idStore.purgeMilliSeconds}", initialDelay = 5000)
  public void purgeOutdatedEntries() {
    long sizeBeforePurge = idStore.size();
    idStore.values().removeIf(value -> value.isOutdated());
    long sizeAfterPurge = idStore.size();
    log.debug("Completed removal of {} outdated messageIds from idStore. Current length: {}",
        sizeBeforePurge - sizeAfterPurge, sizeAfterPurge);
  }
}

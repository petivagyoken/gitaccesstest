package de.dwpbank.wpio.loadtest.genericservice;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RequestProperties {

  private String applIdentityData;
  private String pattern;
  private String filename;
}


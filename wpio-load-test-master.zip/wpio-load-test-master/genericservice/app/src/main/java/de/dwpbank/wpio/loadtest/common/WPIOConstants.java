package de.dwpbank.wpio.loadtest.common;

import com.ibm.mq.constants.MQConstants;

public class WPIOConstants {

  public final static int MSGTYPE_REQUEST = MQConstants.MQMT_REQUEST;
  public final static int MSGTYPE_RESPONSE = MQConstants.MQMT_REPLY;
  public final static int MSGTYPE_CUSTOM_ERROR_RESPONSE = MQConstants.MQMT_APPL_FIRST;
  public final static int MSGTYPE_FILTERED_RESPONSE = MQConstants.MQMT_APPL_LAST;

}

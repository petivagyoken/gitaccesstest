package de.dwpbank.wpio.loadtest.genericservice;

import de.dwpbank.wpio.loadtest.common.MetricsConfiguration;
import de.dwpbank.wpio.loadtest.genericservice.messagestore.MessageStore;
import de.dwpbank.wpio.loadtest.genericservice.messagestore.RequestData;
import de.dwpbank.wpio.loadtest.genericservice.messagestore.ResponseData;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import javax.jms.JMSException;
import javax.jms.Message;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.core.JmsTemplate;

import java.util.List;

@Slf4j
public class ResponseListener extends WMQListener {

  private Counter incomingResponsesCounter;
  private Counter outgoingResponsesCounter;
  private Counter outgoingReRequestsCounter;
  private Counter invalidMessagesCounter;
  private Counter lateResponsesCounter;
  private Counter esbErrorResponsesCounter;

  public ResponseListener(MeterRegistry meterRegistry, String inputQueue, String outputQueue,
      String replyToQueue, TestDataProperties testDataProperties, MessageStore messageStore,
      IdStore idStore, JmsTemplate jmsTemplate) {
    super(meterRegistry, inputQueue, outputQueue, replyToQueue, testDataProperties, messageStore,
        idStore, jmsTemplate);
  }

  @Override
  public void initializeMetrics() {
    this.incomingResponsesCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_RESPONSE)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY,
            MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY_IN)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_NONE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION)
        .register(meterRegistry);

    this.outgoingResponsesCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_RESPONSE)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY,
            MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY_OUT)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_RESPONSE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION)
        .register(meterRegistry);

    this.outgoingReRequestsCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_RESPONSE)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY,
            MetricsConfiguration.WPIOLOADTEST_LABEL_BOUNDARY_OUT)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_REQUEST)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_MESSAGES_DESCRIPTION)
        .register(meterRegistry);

    this.invalidMessagesCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_RESPONSE)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_INVALID_MESSAGE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_DESCRIPTION)
        .register(meterRegistry);

    this.lateResponsesCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_RESPONSE)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_LATE_RESPONSE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_DESCRIPTION)
        .register(meterRegistry);

    this.esbErrorResponsesCounter = Counter
        .builder(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_NAME)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE,
            MetricsConfiguration.WPIOLOADTEST_LABEL_ROUTE_RESPONSE)
        .tag(MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL,
            MetricsConfiguration.WPIOLOADTEST_LABEL_DETAIL_ESB_ERROR_RESPONSE)
        .description(MetricsConfiguration.WPIOLOADTEST_METRIC_ERRORS_DESCRIPTION)
        .register(meterRegistry);
  }

  protected void processIncomingMessage(final Message receivedMessage) throws JMSException {
    incomingResponsesCounter.increment();

    String content = receivedMessage.getBody(String.class);

    if (log.isDebugEnabled()) {
      logMessageAttributes(inputQueue, receivedMessage, content);
    }

    String messageId = receivedMessage.getJMSMessageID();
    String correlId = receivedMessage.getJMSCorrelationID();

    int limit = 1;
    if (isBackoutCountReached(limit, receivedMessage)) {
      invalidMessagesCounter.increment();
      log.error(
          "Got message with messageId {} more than {} time(s), message will not be processed!",
          messageId, limit);
      return;
    }

    if (!idStore.isKnown(correlId)) {
      lateResponsesCounter.increment();
      log.warn(
          "No reference found in idStore for response with correlId {}. Message will be ignored (too old?)",
          correlId);
      return;
    }

    if (isErrorResponse(content)) {
      //No matter how many error responses we get, we count them all as they indicate RP related problems.
      esbErrorResponsesCounter.increment();
      log.info("error message: "+ content);
      //But the service replies only once...
      if (!idStore.isAlreadyAnswered(correlId)) {
        log.debug(
            "Received WPIO ESB ErrorResponse for correlId {}, sending service specific ErrorResponse...",
            correlId);
        String errorText = "Generic Service received a WPIO ESB error!";
        forwardAsResponse(outputQueue, correlId, null, null,
            messageStore.createErrorResponse(errorText));
        outgoingResponsesCounter.increment();
        return;
      }
    }

    //We have a regular response...
    log.debug("Received regular backend response with correlId {} ...", correlId);

    if (idStore.isAlreadyAnswered(correlId)) {
      log.debug(
          "Service response for backend response with correlId {} has already been send, message will be ignored (either the n-th response message of a multiresponse backend answer or several services have been requested)",
          correlId);
      return;
    }

    if (messageStore.hasReRequests()) {
      log.debug("This service is using ReRequests, sending them for correlId {}...", correlId);
      for (RequestData reRequest : messageStore.getReRequestsByPatternMatching(content)) {
        log.debug("Sending request {} ...", reRequest.getApplIdentityData());
        forwardAsRequest(outputQueue, correlId, reRequest.getApplIdentityData(), replyToQueue,
            reRequest.getMessage());
        outgoingReRequestsCounter.increment();
      }
    }

    idStore.markAsAnswered(correlId);
    log.debug("Sending regular response for {}...", correlId);
    List<ResponseData> responses = messageStore.getResponsesByPatternMatching(content);
    if (responses.isEmpty()) {
      log.warn("Did not find a matching response in message store. Check for regex misconfiguration.");
    }

    for (ResponseData response : responses) {
      forwardAsResponse(outputQueue, correlId, null, null, response.getMessage());
      outgoingResponsesCounter.increment();
    }

  }

}
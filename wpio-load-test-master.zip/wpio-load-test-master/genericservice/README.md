# MQ Service Simulator (genericservice)

Simulates a WPIO service accepting requests via native IBM Websphere MQ and forwarding or replying via MsgId/CorrelId pattern.

Messages sent are predefined and taken from a messagestore. If an invalid backend answer or a WPIO Error Response
arrives a WPIO Error Response is send back.

NOTE: Detecting backend errors only works in combination with the backend-simulator (we expect a certain text send from the backend).

In case of backend multi responses the full answer gets send back already on the arrival of the first partial message.
All further partial messages gets only consumed without any further processing.

## Local development

```
cd localtest/
docker-compose up -d wmq

cd ../app/
mvn spring-boot:run
```

## Local test

```
cd localtest/
docker-compose up -d
```

## Prometheus metrics

The genericservice implementation provides some metrics. We have defined two metric names, one for processes messages and one for detected errors during the processing. The same metrics are also used by the backend component.

genericservice - Request route:

* incomingRequestsCounter:      // wpioloadtest.messages.total{service="xyz", route="request",  boundary="in",  detail="none"}
* outgoingRequestsCounter:      // wpioloadtest.messages.total{service="xyz", route="request",  boundary="out", detail"request"}
* outgoingResponsesCounter:     // wpioloadtest.messages.total{service="xyz", route="request",  boundary="out", detail="response"}

* invalidMessagesCounter:       // wpioloadtest.errors.total{service="xyz",   route="request",  detail="invalidMessage"}
* unknownRequestTypeCounter:    // wpioloadtest.errors.total{service="xyz",   route="request",  detail="unknownRequest"}

genericservice - Response route:

* incomingResponsesCounter:     // wpioloadtest.messages.total{service="xyz", route="response", boundary="in",  detail="none"}
* outgoingResponsesCounter:     // wpioloadtest.messages.total{service="xyz", route="response", boundary="out", detail="response"}
* outgoingReRequestsCounter:    // wpioloadtest.messages.total{service="xyz", route="response", boundary="out", detail="request"}

* invalidMessagesCounter:       // wpioloadtest.errors.total{service="xyz",   route="response", detail="invalidMessage"}
* lateResponsesCounter:         // wpioloadtest.errors.total{service="xyz",   route="response", detail="lateResponse"}
* esbErrorResponsesCounter:     // wpioloadtest.errors.total{service="xyz",   route="response", detail="esbErrorResponse"}

backend:

* incomingRequestsCounter:      // wpioloadtest.messages.total{service="backend", route="request",  boundary="in",  detail="none"}
* outgoingResponsesCounter:     // wpioloadtest.messages.total{service="backend", route="response", boundary="out", detail="response"}

* invalidRequestsCounter:       // wpioloadtest.errors.total{service="backend",   route="request",  detail="invalidMessage"}
* unknownRequestTypeCounter:    // wpioloadtest.errors.total{service="backend",   route="request",  detail="unknownRequest"}

Queries that can be answered this way are for example:

1. Are there any erroneous processings in a service? (wpioloadtest.errors.total{service="xyz")
2. How many messages does a service consume and produce? (wpioloadtest.messages.total{service="xyz")
3. How many requests get directly answered by services? (wpioloadtest.messages.total{route="request", boundary="out", detail="response")
4. How often do we have a so called ReRequest? (wpioloadtest.messages.total{route="response", boundary="out", detail="request")

CAUTION: All metric instances from within one application that use the same meter name have to use the same labels, otherwise you will get a runtime error: "java.lang.IllegalArgumentException: Prometheus requires that all meters with the same name have the same set of tag keys. There is already an existing meter named 'wpioloadtest_messages_total' containing tag keys [x, y]. The meter you are attempting to register has keys [x, y, z]."

#!/bin/bash

for container in `podman-compose ps | cut -d' ' -f1 | grep 'gs-'`; do
 echo -n "*** $container: "
 docker logs $container | grep -E '(ERROR|WARN)' | tail -1
 echo
done

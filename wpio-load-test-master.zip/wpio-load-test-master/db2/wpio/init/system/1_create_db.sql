CREATE DATABASE WPILADT
   on /var/wpit_audit/database
;
#!/bin/bash

if [[ -f "/init/complete" ]];
then
  touch /startup/db2
  echo "Database exists, nothing to do...";
else
echo "Start Database Setup"
cp /init/system/WPIAUDIT.jar /tmp
su - db2inst1 -c "
db2 -tvf /init/system/1_create_db.sql
db2 -tvf /init/system/2_config_db.sql
"
su - db2inst1 -c "
db2 -v connect to WPILADT
db2 -tvf /init/system/3_config_baseobjects.sql
db2 -td# -vf /init/system/4_create_functions.sql
db2 -tvf /init/system/4_create_procedures.sql
db2 -tvf /init/system/5_create_browser_tables.sql
db2 -tvf /init/system/6_fill_browser_tables.sql
db2 connect reset
db2 -v connect to WPILADT
db2 -tvf /init/env/1_env_create_tables_log.sql
db2 -tvf /init/env/1_env_create_tables_stats.sql
db2 -tvf /init/env/2_env_create_views_AD.sql
db2 -tvf /init/env/2_env_create_views_RR.sql
db2 -td# -vf /init/env/3_env_create_functions_AD.sql
db2 -td# -vf /init/env/3_env_create_functions_RR.sql
db2 -td# -vf /init/env/4_env_create_functions_stats.sql
db2 -td# -vf /init/env/5_env_create_procedures_stats.sql
db2 -tvf /init/env/6_env_fill_tables_stats.sql
db2 -td# -vf /init/env/7_create_functions_maint.sql
db2 connect reset
"

#echo "START DATA IMPORT"
#FILENAME=/var/custom/data-import.sql
#for AUDIT_INDEX in {1..25000}
#do
#  AUDIT_ID=$(printf "1%09d" $AUDIT_INDEX)
#  sed -r "s/[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}/$(date '+%Y-%m-%d %H:%M:%S')/g" /init/env/8_insert_data.sql | sed -r "s/1000001111/${AUDIT_ID}/g" >> $FILENAME
#done
#su - db2inst1 -c "db2 -v connect to WPILADT && db2 -tvf /var/custom/data-import.sql && db2 connect reset"
#echo "STOP DATA IMPORT"

touch /init/complete
echo "End Database Setup"
/var/db2_setup/lib/setup_db2_instance.sh
fi

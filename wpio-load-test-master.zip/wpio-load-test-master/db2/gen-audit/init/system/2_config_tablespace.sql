-- database privileges
REVOKE CONNECT ON DATABASE FROM PUBLIC
;

GRANT CONNECT ON DATABASE TO GROUP wpiadt
;

GRANT DBADM ON DATABASE TO GROUP mqbrkrs
;

-- bufferpool
CREATE BUFFERPOOL AUDIT_DATA_BP
   SIZE 10000
;

CREATE BUFFERPOOL AUDIT_INDEX_BP
   SIZE 10000
;

-- tablespaces
CREATE REGULAR TABLESPACE GEN_AUDIT_DATA
   MANAGED BY DATABASE
   USING (file '/var/gen_audit/database/storage/audit_data.001' 2 G,
          file '/var/gen_audit/database/storage/audit_data.002' 2 G)
   AUTORESIZE YES
   INCREASESIZE 1 G
   MAXSIZE 10 G
   EXTENTSIZE 256
   BUFFERPOOL AUDIT_DATA_BP
   NO FILE SYSTEM CACHING
;

CREATE REGULAR TABLESPACE GEN_AUDIT_INDEX
   MANAGED BY DATABASE
   USING (file '/var/gen_audit/database/storage/audit_index.001' 1 G,
          file '/var/gen_audit/database/storage/audit_index.002' 1 G)
   AUTORESIZE YES
   INCREASESIZE 500 M
   MAXSIZE 5 G
   BUFFERPOOL AUDIT_INDEX_BP
   NO FILE SYSTEM CACHING
;

CREATE LARGE TABLESPACE GEN_AUDIT_LOB
   MANAGED BY DATABASE
   USING (file '/var/gen_audit/database/storage/audit_lob.001' 3 G,
          file '/var/gen_audit/database/storage/audit_lob.002' 3 G)
   AUTORESIZE YES
   INCREASESIZE 1 G
   MAXSIZE 18 G
   EXTENTSIZE 256
   FILE SYSTEM CACHING
;

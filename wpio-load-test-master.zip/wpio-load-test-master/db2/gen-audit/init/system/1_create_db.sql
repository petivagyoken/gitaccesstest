CREATE DATABASE WPITADT
   on /var/gen_audit/database
;

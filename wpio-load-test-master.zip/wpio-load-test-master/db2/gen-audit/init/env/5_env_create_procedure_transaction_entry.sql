SET CURRENT SCHEMA GENADT_LOAD
@

CREATE OR REPLACE  PROCEDURE TRANSACTION_ENTRY_MERGE
LANGUAGE SQL
BEGIN
FOR curs AS cur1 CURSOR FOR
	  SELECT   STRUCTURE_VERSION,  BUSINESS_DOMAIN,  AUDIT_SEND_SYSTEM,  AUDIT_SEND_PROCESS,  SEND_SYS_NODE_ID,  SUBMIT_POINT,
  		BUSINESS_CASE,  SOURCE_TIMESTAMP,  SEND_SYS_UNIQ_ID,  PARENT_TRACK_ID,  GLOBAL_TRACK_ID,  PROC_SESSION_ID,  AUDIT_REASON,
  		AUDIT_COMMENT,  STATUS,  USER_ID,  TEILNEHMER,  ACCOUNTING_INFORMATION,  RETENTION_PERIOD,  PAYLOAD_LENGTH,  RECEIVED_TIMESTAMP,
  		RECORD_STATUS,  PAYLOAD_MIME_TYPE,  PAYLOAD_ENCODING,  PROCESS_FLAG
 	  FROM AUDIT_ENTRY WHERE PROCESS_FLAG IS NULL AND GLOBAL_TRACK_ID IS NOT NULL ORDER BY  GLOBAL_TRACK_ID,SOURCE_TIMESTAMP ASC
DO
	MERGE 
		INTO
			TRANSACTION_ENTRY AS em
		USING (
	    		SELECT
					curs.AUDIT_SEND_SYSTEM     as ORIG_SYSTEM
				     ,  curs.SOURCE_TIMESTAMP      as START_TIMESTAMP
				     ,  curs.SOURCE_TIMESTAMP      as LAST_UPDATE_TIMESTAMP
				     ,  curs.GLOBAL_TRACK_ID       as GLOBAL_TRACK_ID
				     ,  curs.STATUS                as STATUS
				     ,  curs.BUSINESS_DOMAIN       as ORIG_BUSINESS_DOMAIN
				     ,  curs.AUDIT_SEND_PROCESS    as ORIG_SEND_PROCESS
				     ,  curs.SUBMIT_POINT          as ORIG_SUBMIT_POINT
				     ,  curs.BUSINESS_CASE         as ORIG_BUSINESS_CASE
				     ,  curs.TEILNEHMER            as TEILNEHMER
				     , 1                           as NUMBER_OF_ENTRIES
			         FROM sysibm.DUAL
	      )
	      AS e
		  ON
    	 (
        	em.GLOBAL_TRACK_ID = e.GLOBAL_TRACK_ID 
    	)
	WHEN MATCHED
       and e.START_TIMESTAMP < em.START_TIMESTAMP THEN
	UPDATE
			SET
             (
                          ORIG_SYSTEM
                        , START_TIMESTAMP
                        , NUMBER_OF_ENTRIES
                        , ORIG_BUSINESS_DOMAIN
                        , ORIG_SEND_PROCESS
                        , ORIG_SUBMIT_POINT
                        , ORIG_BUSINESS_CASE
                        , TEILNEHMER
                        , STATUS
             )
             =(e.ORIG_SYSTEM, e.START_TIMESTAMP, em.NUMBER_OF_ENTRIES + 1, e.ORIG_BUSINESS_DOMAIN, e.ORIG_SEND_PROCESS, e.ORIG_SUBMIT_POINT, e.ORIG_BUSINESS_CASE, e.TEILNEHMER,
             (
			CASE
				WHEN e.STATUS = em.STATUS
					THEN em.STATUS
				ELSE
					CASE
						WHEN e.STATUS = 'ERROR'	or em.STATUS = 'ERROR'
							THEN 'ERROR'
						ELSE
							CASE
								WHEN e.STATUS = 'EXPIRED' or em.STATUS = 'EXPIRED'
									THEN 'EXPIRED'
								ELSE
									CASE
										WHEN e.STATUS = 'WARNING' or em.STATUS = 'WARNING'
											THEN 'WARNING'
										ELSE NULL
									END
								END
							END
						END
             	)
             )
	WHEN MATCHED
             and e.START_TIMESTAMP >= em.START_TIMESTAMP THEN
	UPDATE
			SET
                 (
                          LAST_UPDATE_TIMESTAMP
                        , NUMBER_OF_ENTRIES
                        , STATUS
                 )
                 =(MAX(e.LAST_UPDATE_TIMESTAMP, em.LAST_UPDATE_TIMESTAMP), em.NUMBER_OF_ENTRIES + 1,
                 (
				CASE
					WHEN e.STATUS = em.STATUS
						THEN em.STATUS
					ELSE
						CASE
							WHEN e.STATUS  = 'ERROR' or em.STATUS = 'ERROR'
								THEN 'ERROR'
							ELSE
								CASE
									WHEN e.STATUS  = 'EXPIRED'	or em.STATUS = 'EXPIRED'
										THEN 'EXPIRED'
									ELSE
										CASE
											WHEN e.STATUS  = 'WARNING' or em.STATUS = 'WARNING'
												THEN 'WARNING'
											ELSE NULL
										END
									END
							END
					END
                 )
                 )
	WHEN NOT MATCHED THEN
	INSERT
       		( ID
            , ORIG_SYSTEM
            , START_TIMESTAMP
            , LAST_UPDATE_TIMESTAMP
            , GLOBAL_TRACK_ID
            , STATUS
            , ORIG_BUSINESS_DOMAIN
            , ORIG_SEND_PROCESS
            , ORIG_SUBMIT_POINT
            , ORIG_BUSINESS_CASE
            , TEILNEHMER
            , NUMBER_OF_ENTRIES
       		)
       VALUES
       		( NEXT VALUE FOR TRANSACTION_SEQ 
            , e.ORIG_SYSTEM
            , e.START_TIMESTAMP
            , e.LAST_UPDATE_TIMESTAMP
            , e.GLOBAL_TRACK_ID
            , e.STATUS
            , e.ORIG_BUSINESS_DOMAIN
            , e.ORIG_SEND_PROCESS
            , e.ORIG_SUBMIT_POINT
            , e.ORIG_BUSINESS_CASE
            , e.TEILNEHMER
            , e.NUMBER_OF_ENTRIES
       		); -- end merge
       
END FOR;

COMMIT;

END
@
#!/bin/bash

if [[ -f "/init/complete" ]]
then
  echo "Database exists, nothing to do...";
else
su - db2inst1 -c "
db2 -tvf /init/system/1_create_db.sql
db2 -tvf /init/system/2_config_tablespace.sql
db2 get connection state
db2 connect reset
db2 get connection state
db2 connect to WPITADT
db2 -tvf /init/env/1_env_create_schema.sql
db2 -tvf /init/env/2_env_create_audit_tables.sql
db2 -tvf /init/env/3_env_create_transaction_tables.sql
db2 -td@ -vf /init/env/4_env_create_or_replace_trigger_transaction.sql
db2 -td@ -vf /init/env/5_env_create_procedure_transaction_entry.sql
db2 -tvf /init/env/6_env_grant_to_store_procedure.sql
"
touch /init/complete
echo "End Database Setup"
/var/db2_setup/lib/setup_db2_instance.sh

fi

#!/bin/bash

# Setup for testing the jcf-audit-idx 

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-audit-idx.yml \
	-f docker-compose/audit-idx/dc-override-audit-idx.yml"

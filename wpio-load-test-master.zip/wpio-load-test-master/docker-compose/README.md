# Docker Compose setups for WPIO load test

## Structure

This folder includes all docker-compose setups for the WPIO load test. As we are testing in quite a few different simulation
setups with each time other components simulated or mocked, there are several docker-compose setups for this.

The structure is as follows:
* The base docker-compose definitions are located in this folder (`docker-compose`) and are named `dc-...-yml`. These are used 
in every setup as needed.
* The specific docker-compose setups for a scenario/simulation (consisting of base definitions and overrides) are located 
in the subfolder (`rp`, `ws_b1`, ...). Each setup is built together by specifying the docker-compose files in the shell 
script,  named `dc-[name].sh`. 

One of these scripts has then do be chosen, if someone executes `loadtest.sh`. For convenience the available setups will
be printed out if the script is started without parameters. 

TIP: Each override file for new setups has to include a Prometheus part including `links` and a specific configuration
file, as docker-compose does not allow overwriting of multiline value fields. They are combined instead. That's why the
`links` key is empty in `dc-wpio-infrastructure.yml` and has to be set in each override.

## Create a new docker-compose setup

To create a new setup, you need to do at least as follows:

* Create a new folder with the name of the docker-compose setup, with at least two files in it:
** `dc-[name].sh` 
** `dc-override-[name].yml`
* Create a new Prometheus configuration in `../prometheus`, if none of the existing ones is fitting
* Built together the compose context in your `dc-[name].sh` shell file
* Adjust necessary changes in your corresponding `dc-override-[name].yml`
** It is ALWAYS necessary to override the `links` key in the service `prometheus`. Also it is necessary to add a 
`prometheus.yml` there with a valid list of the scrape targets.

## Prometheus

To enable the Prometheus console uncomment the following lines in dc-infrastructure.yml

*ports:
* - 9090:9090
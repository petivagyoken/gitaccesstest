#!/bin/bash

# Setup for testing the jcf-ad-dwp-wii

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-ad-infrastructure.yml \
	-f docker-compose/dc-wpio-ad-dwp-order.yml \
	-f docker-compose/ad-dwp-order/dc-override-ad-dwp-order.yml"

#!/bin/bash

# Setup for testing the RP (includes SOAP-WS)

DOCKER_COMPOSE_FILES="-f docker-compose/dc-esb-infrastructure.yml \
	-f docker-compose/dc-esb.yml \
	-f docker-compose/esb/dc-override-esb.yml"

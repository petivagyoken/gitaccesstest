#!/bin/bash

# Setup for isolated testing of SOAP adapter (includes jcf-ws + B1 RP)

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-rp.yml \
	-f docker-compose/dc-wpio-ws.yml  \
	-f docker-compose/ws_b1/dc-override-ws_b1.yml"

#!/bin/bash

# Setup for testing the jcf-ad-dwp-wii

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-ad-infrastructure.yml \
	-f docker-compose/dc-wpio-ad-dwp-wii.yml \
	-f docker-compose/ad-dwp-wii/dc-override-ad-dwp-wii.yml"

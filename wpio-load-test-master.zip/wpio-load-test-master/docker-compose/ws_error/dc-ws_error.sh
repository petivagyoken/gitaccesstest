#!/bin/bash

# Setup for isolated testing of SOAP adapter jcf-ws for ErrorResponse memory leak detection

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-routing-without-rp.yml \
	-f docker-compose/dc-wpio-ws.yml \
	-f docker-compose/ws_error/dc-override-ws_error.yml"

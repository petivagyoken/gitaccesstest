#!/bin/bash

# Setup for testing the jcf-rp-kafka

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-rp-kafka.yml \
	-f docker-compose/rp-kafka/dc-override-rp-kafka.yml"

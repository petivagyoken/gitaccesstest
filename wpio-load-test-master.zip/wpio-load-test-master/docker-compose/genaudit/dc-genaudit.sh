#!/bin/bash

# Setup for testing the RP (includes SOAP-WS)

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-esb-genaudit.yml \
	-f docker-compose/genaudit/dc-override-genaudit.yml"

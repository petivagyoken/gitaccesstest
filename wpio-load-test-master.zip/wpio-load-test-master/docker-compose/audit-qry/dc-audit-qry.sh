#!/bin/bash

# Setup for testing the jcf-audit-qry

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-audit-qry.yml \
	-f docker-compose/audit-qry/dc-override-audit-qry.yml"

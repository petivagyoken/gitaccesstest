#!/bin/bash

# Setup for testing the RP (includes SOAP-WS)

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-rp.yml \
	-f docker-compose/dc-wpio-mockservices.yml  \
	-f docker-compose/dc-wpio-xgen-dwp-acctgbook.yml \
	-f docker-compose/xgen-dwp-acctgbook/dc-override-dwp-acctgbook.yml"

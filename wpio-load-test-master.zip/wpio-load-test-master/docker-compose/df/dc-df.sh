#!/bin/bash

# Setup for running in DF, without any real jcf containers

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-rp.yml \
	-f docker-compose/dc-wpio-mockservices.yml  \
	-f docker-compose/dc-wpio-ws.yml \
	-f docker-compose/df/dc-override-df.yml"

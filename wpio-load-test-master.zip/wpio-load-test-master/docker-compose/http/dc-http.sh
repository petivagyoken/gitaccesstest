#!/bin/bash

# Setup for isolated testing of HTTP adapter

DOCKER_COMPOSE_FILES="-f docker-compose/dc-infrastructure.yml \
	-f docker-compose/dc-wpio-rp.yml \
	-f docker-compose/dc-wpio-http.yml  \
	-f docker-compose/http/dc-override-http.yml"

#!/bin/bash

set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Usage: $(basename $0) <container name> < script inside container> [further script params]"
  exit 255
fi

container=$1
shift

# container name is only the servicename set inside docker-compose.yml
# We are accessing the container via docker API so we have to use the global container name on the Docker host

groupPrefix="${DOCKER_PROJECT_NAME:-wpioloadtest}_"
containerSuffix='_1'

docker exec "${groupPrefix}${container}${containerSuffix}" $@

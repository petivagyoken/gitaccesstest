#!/bin/bash

set -euo pipefail

export DOCKER_PROJECT_NAME=$(/app/determineProjectName.sh)

/bin/script_exporter $@

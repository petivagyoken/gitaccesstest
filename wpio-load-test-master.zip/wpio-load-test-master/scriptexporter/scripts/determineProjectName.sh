#!/bin/bash

# Determine docker-compose project name.
# This is part of every container name started by docker-compose and is needed in order to adress
# a container via the Docker API for executing scripts inside other containers

thisContainerName=$(docker ps -f ID="${HOSTNAME}" --format "{{.Names}}")
thisServiceNameSuffix='script_exporter_1'

echo ${thisContainerName%"_${thisServiceNameSuffix}"}


#!/usr/bin/env bash

echo $(cat <<-END
connect "jdbc:derby:ROUTINGDB;user=APP;$ROUTING_DATABASE_PASSWORD";
SELECT * FROM APP."schema_version" WHERE "version" = '$CHECK_VERSION';
disconnect;
exit;
END
) > check_version.sql

RESULT=$(/opt/derby/bin/ij check_version.sql)

EXIT_CODE=1
if [[ $RESULT == *"$CHECK_VERSION"* ]];
then
  EXIT_CODE=0
fi

echo "$(date): $EXIT_CODE" >> /app/healthcheck.log

rm -f check_version.sql
exit $EXIT_CODE

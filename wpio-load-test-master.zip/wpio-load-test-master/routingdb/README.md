# RoutingDB (Apache Derby)

## How to get more information about the running container

Exec into the Docker container `routingdb`, then:

````
cd /opt/derby

# get usage information 
java -jar lib/derbyrun.jar

# you can execute for example one of these functions: 
java -jar lib/derbyrun.jar sysinfo
java -jar lib/derbyrun.jar server runtimeinfo
java -jar lib/derbyrun.jar PlanExporter
java -jar lib/derbyrun.jar ij <sql statement>
```` 

### Executing SQL statements

In order to execute sql statements with 'ij' you have to connect to the database first.
There is an alternative way to start `ij`, this is described here:

````
/opt/derby/bin/ij
connect 'jdbc:derby://127.0.0.1:1527/NODE1DB';
# no you can execute arbitrary sql statements, for example...
describe route_load.store;
exit;
```` 

## Information regarding 'Compress'

See https://db.apache.org/derby/docs/10.15/adminguide/derbyadmin.pdf, chapter 'Reclaiming unused space'.

We are now executing `SYSCS_UTIL.SYSCS_COMPRESS_TABLE`. There is another function `SYSCS_UTIL.SYSCS_INPLACE_COMPRESS_TABLE` but as both functions require an exclusive access to the table and the first option is not that slow it seems to be the better one.

To get information if a compress might be a useful call:

```
SELECT substr(CONGLOMERATENAME,1,20), NUMALLOCATEDPAGES, NUMFREEPAGES, NUMUNFILLEDPAGES, PAGESIZE, ESTIMSPACESAVING FROM TABLE (SYSCS_DIAG.SPACE_TABLE('ROUTE_LOAD', 'STORE')) AS T2;
```

For details about the commands see https://db.apache.org/derby/docs/10.15/ref/refderby.pdf

## Runtime statistics

```
CALL SYSCS_UTIL.SYSCS_SET_RUNTIMESTATISTICS(1);
CALL SYSCS_UTIL.SYSCS_SET_STATISTICS_TIMING(1);
```

## Statement statistics

```
select ID, substr(SCHEMANAME,1,5) schemaname, SQL_TEXT, UNIC&, VALID, COMPILED_AT FROM SYSCS_DIAG.STATEMENT_CACHE;
-
SELECT * FROM SYSCS_DIAG.STATEMENT_CACHE;
SELECT * FROM TABLE (SYSCS_DIAG.STATEMENT_DURATION()) AS T1;
```

Enable derby.storage.indexStats.log (default: false)? 

This logs info about asynchronous statistics update executions as these might affect the user performance.

## Optimisations

See https://db.apache.org/derby/docs/10.15/tuning/tuningderby.pdf


### Optimizing table queries (Query Plan)

NOTE: a 'compress table' updates these statistics automatically.

TIP: should we execute these updates every time we apply changes via routingdata?

```
CALL SYSCS_UTIL.SYSCS_UPDATE_STATISTICS('SAMP', 'EMPLOYEE', null);
```

### Possible optimisations via properties

1. derby.language.statementCacheSize (default: 100. Is this enough?)
2. derby.storage.pageCacheSize (default: 1000 pages with 4k per page = 4MB)

TIP: With a RoutingDB image >= 3.1 such properties can be tested in a load test environment by simply mounting a properties file under path `/properties/derby.properties` into the container. 


## Further resources

* Latest Derby PDF Guides (search for pdf files in the subfolders): https://db.apache.org/derby/docs/10.15/

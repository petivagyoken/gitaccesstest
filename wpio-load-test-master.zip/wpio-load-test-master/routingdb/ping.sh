#!/bin/bash

/opt/derby/bin/ij /app/ping.sql

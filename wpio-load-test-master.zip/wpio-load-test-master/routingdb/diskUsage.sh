#!/bin/sh

echo "# HELP diskusage_kb Disk usage of a folder in KB"
echo "# TYPE diskusage_kb gauge"
echo "diskusage_kb{folder=\"/app\"} $(du -c /app/ | tail -1 | cut -f1)"
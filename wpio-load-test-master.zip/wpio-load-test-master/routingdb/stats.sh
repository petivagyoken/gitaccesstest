#!/bin/bash

/opt/derby/bin/ij /app/stats.sql \
  | grep -E -v '^(ij|-)' \
  | head -4 \
  | tail -3 \
  | awk -F '|' '
    BEGIN {
      print "# HELP derby_sysscs_diag_space_allocated_pages The number of pages actively linked into the table. The total number of pages in the file is the sum of NUMALLOCATEDPAGES + NUMFREEPAGE.";
      print "# TYPE derby_sysscs_diag_space_allocated_pages gauge";
      print "# HELP derby_sysscs_diag_space_free_pages The number of free pages that belong to the table. When a new page is to be linked into the table the system will move a page from the NUMFREEPAGES list to the NUMALLOCATEDPAGES list";
      print "# TYPE derby_sysscs_diag_space_free_pages gauge";
      print "# HELP derby_sysscs_diag_space_unfilled_pages The number of unfilled pages that belong to the table. Unfilled pages are allocated pages that are not completely full. Note that the number of unfilled pages is an estimate and is not exact. Running the same query twice can give different results on this column";
      print "# TYPE derby_sysscs_diag_space_unfilled_pages gauge";
      print "# HELP derby_sysscs_diag_space_page_size_bytes The size of the page in bytes for that conglomerate";
      print "# TYPE derby_sysscs_diag_space_page_size_bytes gauge";
      print "# HELP derby_sysscs_diag_space_estimated_space_saving_bytes The estimated space which could possibly be saved by compressing the conglomerate";
      print "# TYPE derby_sysscs_diag_space_estimated_space_saving_bytes gauge";
    }
    {
      gsub(/ /,"",$0);
      print "derby_sysscs_diag_space_allocated_pages{table=\"STORE\",conglomerate=\""$1"\"}", $2
      print "derby_sysscs_diag_space_free_pages{table=\"STORE\",conglomerate=\""$1"\"}", $3
      print "derby_sysscs_diag_space_unfilled_pages{table=\"STORE\",conglomerate=\""$1"\"}", $4
      print "derby_sysscs_diag_space_page_size_bytes{table=\"STORE\",conglomerate=\""$1"\"}", $5
      print "derby_sysscs_diag_space_estimated_space_saving_bytes{table=\"STORE\",conglomerate=\""$1"\"}", $6
    }'

# 1                   |NUMALLOCATEDPAGES   |NUMFREEPAGES        |NUMUNFILLEDPAGES    |PAGESIZE   |ESTIMSPACESAVING

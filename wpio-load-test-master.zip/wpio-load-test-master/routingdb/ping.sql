connect 'jdbc:derby://127.0.0.1:1527/NODE1DB';
select current_timestamp from sysibm.sysdummy1;


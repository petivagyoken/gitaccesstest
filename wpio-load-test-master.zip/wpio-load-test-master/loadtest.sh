#!/bin/bash

if [[ $EUID -ne 0 ]]; then
    echo "You need to run this as the root user with sudo"
    exit 1
fi

if [[ $# -eq 0 ]] ; then
    echo "You need to provide a valid setup file from the folder docker-compose (i.e. ./docker-compose/rp/dc-rp.sh)"
    echo "Available setups are:"
    find ./docker-compose -name "*.sh"
    exit 1
fi

# Determine compose files
source "$1"

DCEXECUTABLE="podman-compose"


source _setup.sh

LOADED=1
if [ "$2" = "--skip-wait" ]; then
    echo 'It needs some time (about 3 minutes) to configure the routing database, waiting for this...'
    sleep 15
    while docker ps --filter "name=wpio_routingdata_1" --filter "status=running" | grep 'Up' >/dev/null 2>&1 ; do
      echo -n '.'
      sleep 10
    done
    echo

    if docker ps --filter "name=wpio_routingdata_1" --filter "status=exited" | grep 'Exited (0)' >/dev/null 2>&1 ; then
      LOADED=1
    else    
      echo 'Error configuring routing database, please check container logs!'
      echo 'Press ENTER to exit setup...'
      read
      LOADED=0
    fi
fi

if [ "$2" = "--wait-for-db2" ]; then
while ! docker logs --tail 100 wpio_audit_1 2>&1 | grep -q "Start completed."; do
  echo "DB2 noch nicht bereit. Warte 10 Sekunden..."
  docker restart wpio_audit_1
  sleep 10
done

fi

if [ $LOADED -eq 1 ]; then
  echo 'Now you are entering the Gatling load driver container where you can start the tests...'
  echo 'Leave it by typing "exit".'
  docker exec -it wpio_gatling_1 sh -c "cd /gatling && echo 'simulation ${1} loaded' && /bin/bash"
fi

source _teardown.sh

# Kafka Backend Simulator

Simulates a WP3 backend accepting requests via Apache Kafka and sends back responses based on WPIO Kafka correlation ID.

## Local development

```
cd ../app/
mvn spring-boot:run
```

## Local test
Note: Only valid in DF
```
cd localtest
docker-compose up -d

cd ../app/
mvn spring-boot:run
```
To simulate a request send a single message via jcf-rp-kafka and gatling
```
cd ../../gatling
mvn gatling:test -Dgatling.simulationClass=de.dwpbank.wpio.loadtest.simulation.rp.RpKafkaSingle
```

## Configuration

Response simulations for a topic can be configured via application yaml file. 
Below example listens for request to a topic configured in variable topic-name and checks if a request message payload matches given regex pattern (global-pattern).
A response delay can be configured with variables avg-delay and max-deviation-percent. 

```yaml
app:
  group-name: wpio
  concurrency: 2
  replication-factor: 1
  test-requests:
    -
      topic-name: or.handelpatzanbindung.wpio.quoteanfrage.command.v2.pub
      test-responses:
        -
          global-pattern: .*
          avg-delay: 150
          max-deviation-percent: 20
          filename: test.json
```
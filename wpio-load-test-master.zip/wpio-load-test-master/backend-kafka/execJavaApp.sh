#!/usr/bin/env bash
set -euo pipefail

if [ $# -eq 0 ]; then
  echo "Usage: $(basename $0) <jar file> [further application params]"
  exit 255
fi

JAR=$1

shift

exec java \
       -XX:+ExitOnOutOfMemoryError \
       -Xms${HEAP_SIZE:-128m} \
       -Xmx${HEAP_SIZE:-128m} \
       ${JAVA_OPTS} \
       -jar ${JAR} \
       "--spring.config.location=file:///config/" \
       "$@"
package de.dwpbank.wpio.loadtest.kafkabackend;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaAdmin.NewTopics;

@Configuration
public class KafkaConfiguration {

  private final AppProperties appProperties;

  public KafkaConfiguration(AppProperties appProperties) {
    this.appProperties = appProperties;
  }

  @Bean
  public KafkaAdmin.NewTopics topics() {
    var requests = appProperties.getTestRequests();
    NewTopic[] topics = new NewTopic[requests.length];
    for (var i = 0; i < requests.length; i++) {
      topics[i] = TopicBuilder.name(requests[i].getTopicName())
          .partitions(appProperties.getConcurrency())
          .replicas(appProperties.getReplicationFactor())
          .build();
    }
    return new NewTopics(topics);
  }
}

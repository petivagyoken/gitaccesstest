package de.dwpbank.wpio.loadtest.kafkabackend;

import java.util.Arrays;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class Listener {

  private final KafkaTemplate<String, String> kafkaTemplate;

  private final AppProperties appProperties;

  public Listener(KafkaTemplate<String, String> kafkaTemplate, AppProperties appProperties) {
    this.kafkaTemplate = kafkaTemplate;
    this.appProperties = appProperties;
  }

  @KafkaListener(topics = "#{appProperties.getTopics()}", groupId = "#{appProperties.groupName}", concurrency = "#{appProperties.concurrency}")
  public void listen(ConsumerRecord<String, Object> consumerRecord) {
    var replyTopic = new String(consumerRecord.headers().lastHeader(KafkaHeaders.REPLY_TOPIC).value());
    var correlationId = new String(consumerRecord.headers().lastHeader(KafkaHeaders.CORRELATION_ID).value());
    var payload = consumerRecord.value().toString();

    var testRequestOptional = appProperties.getTestRequestByTopicName(consumerRecord.topic());
    if (testRequestOptional.isEmpty()) {
      log.error("No test request is configured for topic {}", consumerRecord.topic());
      return;
    }

    var testRequest = testRequestOptional.get();

    var testResponseOptional = Arrays.stream(testRequest.getTestResponses()).filter(testResponse -> testResponse.getPattern().matcher(payload).find()).findFirst();
    if (testResponseOptional.isEmpty()) {
      log.error("No test response is configured for topic {}, payload {}", consumerRecord.topic(), payload);
      return;
    }

    var testResponse = testResponseOptional.get();
    var delay = RandomDelay.getRandomDelay(testResponse.getAvgDelay(), testResponse.getMaxDeviationPercent());

    try {
      Thread.sleep(delay);
      log.debug("Delayed output messages for {} ms (delay settings are: avg {}, maxDevPercent {})",
          delay, testResponse.getAvgDelay(), testResponse.getMaxDeviationPercent());
    } catch (InterruptedException e) {
      log.error("Delay error",e);
    }

    var key = UUID.randomUUID().toString();
    log.info("REPLY_TO={}, CORRELATION_ID={}", replyTopic, correlationId);

    var record = new ProducerRecord<>(replyTopic, key, testResponse.getFileContent());
    record.headers().add(KafkaHeaders.CORRELATION_ID, correlationId.getBytes());
    kafkaTemplate.send(record);
  }
}

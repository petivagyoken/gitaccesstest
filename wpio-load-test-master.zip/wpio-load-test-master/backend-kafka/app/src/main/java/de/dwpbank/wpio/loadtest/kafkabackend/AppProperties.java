package de.dwpbank.wpio.loadtest.kafkabackend;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app")
public class AppProperties {

  @Getter
  @Setter
  private String topicName;

  @Getter
  @Setter
  private int concurrency;

  @Getter
  @Setter
  private int replicationFactor;

  @Getter
  @Setter
  private String groupName;

  @Getter
  @Setter
  private TestRequest[] testRequests;

  public String[] getTopics() {
    return Arrays.stream(testRequests).map(TestRequest::getTopicName).collect(Collectors.toList()).toArray(String[]::new);
  }

  public Optional<TestRequest> getTestRequestByTopicName(String topicName) {
    return Arrays.stream(testRequests).filter(testRequest -> testRequest.getTopicName().equals(topicName)).findFirst();
  }

  public AppProperties() { }

  public static class TestRequest {

    @Getter
    @Setter
    private String topicName;

    @Getter
    @Setter
    private TestResponse[] testResponses;
  }

  public static class TestResponse {

    @Getter
    private String globalPattern;

    @Getter
    private Pattern pattern;

    @Getter
    @Setter
    private int avgDelay;

    @Getter
    @Setter
    private int maxDeviationPercent;

    @Getter
    private String filename;

    @Getter
    private String fileContent;

    public void setGlobalPattern(String globalPattern) {
      this.globalPattern = globalPattern;
      this.pattern = Pattern.compile(globalPattern);
    }

    public void setFilename(String filename) throws IOException {
      this.filename = filename;
      this.fileContent = Files.readString(Paths.get(filename));
    }
  }

}

package de.dwpbank.wpio.loadtest.kafkabackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.kafka.annotation.EnableKafka;

@SpringBootApplication
@EnableKafka
@EnableJms
public class KafkaServerApplication {

	public static void main(String[] args) {

		SpringApplication.run(KafkaServerApplication.class, args);

	}

}

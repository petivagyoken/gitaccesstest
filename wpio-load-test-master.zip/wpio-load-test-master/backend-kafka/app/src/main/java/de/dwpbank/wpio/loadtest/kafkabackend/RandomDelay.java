package de.dwpbank.wpio.loadtest.kafkabackend;

import java.util.Random;

/**
 * Generates a random delay based on an average and a percent value relative to the average. All
 * generated values are in the range average -+ deviationPercent% of average.
 *
 * <p>Example: avg 100, deviationPercent 50 = all values between 50 and 150 avg 100,
 * deviationPercent 10 = all values between 90 and 110
 * deviationPercent 0 = all values are exactly 100
 */
public class RandomDelay {

  private static final Random r = new Random();

  public static int getRandomDelay(int average, int deviationPercent) {
    // calculate delay if deviationPercent is greater than 0
    if (deviationPercent > 0) {
      int deviationAbsolute = (int) (((double) average / 100d) * (double) deviationPercent);
      int deviationRandom = r.nextInt((deviationAbsolute * 2)) - deviationAbsolute;
      return average + deviationRandom;
    } else {
      // switch off deviation calculation when deviationPercent is 0 or negative
      return average;
    }
  }
}

#!/bin/bash
#
# Script for generating the testdata properties entries. Generates the output in a file
# named testdata.properties
#
# HowTo:
# - pattern and groupname variables have to be set manual here before execution
# - execute with folder name as first parameter
#
# Example: ./generate-testdata-properties.sh ./DWP.ORDERBOOK/125_Teilnachrichten

# Pattern which activates the response, if present in *-S-B3-1.audit request
PATTERN=901202101061310091948324179100021470

# Name of property group
GROUPNAME=dkb43

echo "===" >> testdata.properties
COUNTER=0
ls $1/*-O-B3-2.audit | while read i
  do
    echo "wpio.testdata.requests.wp2-orderbook-$GROUPNAME.response[$COUNTER]=${i#./}" >> testdata.properties
    echo "wpio.testdata.requests.wp2-orderbook-$GROUPNAME.pattern[$COUNTER]=$PATTERN" >> testdata.properties
    ((COUNTER=COUNTER+1))
done

echo "Wrote $COUNTER testdata entries with request name $GROUPNAME in testdata.properties."

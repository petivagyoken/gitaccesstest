package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
  * Dieser Test sendet Orderbook Anfragen von 13 versch. Client IDs in einer gewissen Verteilung,
  * die einer durchschnittlichen Stunde um 9 Uhr aehneln soll. Pro Client ID wird unterschieden in
  * Szenarien, bei denen die Antwortnachrichten des Backends von 1 bis 125 variieren. Diese Szenarien
  * werden ebenfalls noch einmal prozentual verteilt (wenige grosse Antworten, viele kleine).
  *
  * Der Test startet mit der Durchschnittslast 1,33 rps und erhoeht diese dann kontinuierlich,
  * bis der Multiplizierer erreicht ist.
  *
  * Bspw.: 1,33 rps Ausgang, Test laeuft ueber 30min kontinuierlich bis zu 6,65 rps bei Multiplier 5.
  *
  */
class DwpOrderbookDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)

  // Gesamte Dauer des Tests in Sekunden
  val durationPhase: Int = 1800

  // rps der einzelnen Clients, Gesamt RPS ist 1,33
  val rps1822: Float = 0.0142f
  val rpsDegussa: Float = 0.0071f
  val rpsDkb: Float = 0.03f
  val rpsEbase: Float = 0.0103f
  val rpsFi: Float = 0.1529f
  val rpsFidDzBan: Float = 0.0118f
  val rpsFidDzDet: Float = 0.1260f
  val rpsFidDzPer: Float = 0.6875f
  val rpsFidDzSac: Float = 0.0017f
  val rpsFidMlpDet: Float = 0.0010f
  val rpsFidMlpPer: Float = 0.0043f
  val rpsSan: Float = 0.0223f
  val rpsSyd: Float = 0.001f

  // Multiplier to adjust total load according to set ratios. Set to 1 to keep 1,33 rps
  val rpsMultiplier: Float = 3f

  // Verteilung der Groesse der Orderbook Antwortnachrichten pro Client ID
  val ratio100percent: Float = 1f
  val ratio80percent: Float = 0.8f
  val ratio15percent: Float = 0.15f
  val ratio4percent: Float = 0.04f
  val ratio1percent: Float = 0.01f

  /** 1822 **/
  val achtzehn22Orderbook1 = new WpioScenario("1822 - 1 response", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val achtzehn22Orderbook2 = new WpioScenario("1822 - 2 responses", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val achtzehn22Orderbook6 = new WpioScenario("1822 - 6 responses", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val achtzehn22Orderbook43 = new WpioScenario("1822 - 43 responses", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")

  /** DKB **/
  val dkbOrderbook1 = new WpioScenario("DKB - 1 response", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val dkbOrderbook2 = new WpioScenario("DKB - 2 responses", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val dkbOrderbook6 = new WpioScenario("DKB - 6 responses", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val dkbOrderbook43 = new WpioScenario("DKB - 43 responses", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")

  /** EBASE **/
  val ebaseOrderbook1 = new WpioScenario("EBASE - 1 response", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val ebaseOrderbook2 = new WpioScenario("EBASE - 2 responses", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val ebaseOrderbook6 = new WpioScenario("EBASE - 6 responses", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val ebaseOrderbook43 = new WpioScenario("EBASE - 43 responses", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")

  /** SAN **/
  val sanOrderbook1 = new WpioScenario("SAN - 1 response", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val sanOrderbook2 = new WpioScenario("SAN - 2 responses", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val sanOrderbook6 = new WpioScenario("SAN - 6 responses", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val sanOrderbook43 = new WpioScenario("SAN - 43 responses", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")
  val sanOrderbook125 = new WpioScenario("SAN - 125 responses", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/125_Teilnachrichten/20201103T125622.143-S-C1-100001.audit", "<OrderbookResponse_1")

  setUp(

    //1822
    achtzehn22Orderbook1.get.inject(
      rampUsersPerSec(rps1822 * ratio80percent) to rps1822 * ratio80percent * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    achtzehn22Orderbook2.get.inject(
      rampUsersPerSec(rps1822 * ratio15percent) to rps1822 * ratio15percent * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    achtzehn22Orderbook6.get.inject(
      rampUsersPerSec(rps1822 * ratio4percent) to rps1822 * ratio4percent * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    achtzehn22Orderbook43.get.inject(
      rampUsersPerSec(rps1822 * ratio1percent) to rps1822 * ratio1percent * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),

    //DKB
    dkbOrderbook1.get.inject(
      rampUsersPerSec(rpsDkb * ratio80percent) to rpsDkb * ratio80percent * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    dkbOrderbook2.get.inject(
      rampUsersPerSec(rpsDkb * ratio15percent) to rpsDkb * ratio15percent * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    dkbOrderbook6.get.inject(
      rampUsersPerSec(rpsDkb * ratio4percent) to rpsDkb * ratio4percent * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    dkbOrderbook43.get.inject(
      rampUsersPerSec(rpsDkb * ratio1percent) to rpsDkb * ratio1percent * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),

    //EBASE
    ebaseOrderbook1.get.inject(
      rampUsersPerSec(rpsEbase * 0.65f) to rpsEbase * 0.65f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    ebaseOrderbook2.get.inject(
      rampUsersPerSec(rpsEbase * 0.25f) to rpsEbase * 0.25f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    ebaseOrderbook6.get.inject(
      rampUsersPerSec(rpsEbase * 0.05f) to rpsEbase * 0.05f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    ebaseOrderbook43.get.inject(
      rampUsersPerSec(rpsEbase * 0.05f) to rpsEbase * 0.05f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),

    //SAN
    sanOrderbook1.get.inject(
      rampUsersPerSec(rpsSan * 0.79f) to rpsSan * 0.79f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    sanOrderbook2.get.inject(
      rampUsersPerSec(rpsSan * 0.15f) to rpsSan * 0.15f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    sanOrderbook6.get.inject(
      rampUsersPerSec(rpsSan * 0.04f) to rpsSan * 0.04f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    sanOrderbook43.get.inject(
      rampUsersPerSec(rpsSan * 0.01f) to rpsSan * 0.01f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent),
    sanOrderbook125.get.inject(
      rampUsersPerSec(rpsSan * 0.01f) to rpsSan * 0.01f * rpsMultiplier during (durationPhase seconds),
    ).protocols(jmsConfigNonPersistent)
  )
}



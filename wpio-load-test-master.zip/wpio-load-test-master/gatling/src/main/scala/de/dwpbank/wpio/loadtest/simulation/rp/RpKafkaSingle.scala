package de.dwpbank.wpio.loadtest.simulation.rp

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

class RpKafkaSingle extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  val quote = new WpioScenario("Quote", "WPI.KAFKA.REQUEST.LOAD", "WPI.B3.RESPONSE.LOAD",
    "WP3.QUOTE", filePrefix+"DWP.QUOTE_KAFKA/request-01.json", "depotnummer")

  setUp(
    quote.get.inject(
      atOnceUsers(1)
    )protocols(jmsConfigPersistent),
  )


}

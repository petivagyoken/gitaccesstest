package de.dwpbank.wpio.loadtest.common

import com.ibm.mq.jms.MQDestination
import com.ibm.msg.client.jms.{JmsConnectionFactory, JmsConstants, JmsFactoryFactory}
import com.ibm.msg.client.wmq.common.CommonConstants
import de.dwpbank.wpio.loadtest.common.wmq.ConnectionFactoryDecorator
import io.gatling.core.Predef.configuration
import io.gatling.jms.Predef.jms
import io.gatling.jms.protocol.JmsProtocolBuilder

import scala.concurrent.duration.{FiniteDuration, MILLISECONDS}

object JmsMqConfiguration {


/*
  private val hostName = getStringConfig("MQ_QM_HOSTNAME", "localhost")
  private val hostPort = getIntConfig("MQ_QM_PORT", 1414)
  private val channelName = getStringConfig("MQ_QM_CHANNEL", "DEV.APP.SVRCONN")
  private val queueManagerName = getStringConfig("MQ_QM_NAME", "QM1")
  private val listenerThreadCount = getIntConfig("LISTENER_THREAD_COUNT", 2)
  private val replyTimeoutMsecs = getIntConfig("REPLY_TIMEOUT_MSECS", 1000).toLong
*/
  private val jmsFactoryFactory = JmsFactoryFactory.getInstance(JmsConstants.WMQ_PROVIDER)


  def createjmsConnectionNonPersistent(environment: String = "LOCAL"): JmsProtocolBuilder = {
    val jmsConnectionParameter = JmsMqConnectionParameterFactory.getJmsMqConnectionParameter(environment)
    val connectionFactory = createConnectionFactory(jmsConnectionParameter)
    jms.connectionFactory(connectionFactory)
      .replyTimeout(FiniteDuration(jmsConnectionParameter.get.getReplyTimeoutMsecs, MILLISECONDS))
      .useNonPersistentDeliveryMode
      .listenerThreadCount(jmsConnectionParameter.get.getListenerThreadCount)
  }

  def createjmsConnectionPersistent(environment: String = "LOCAL"): JmsProtocolBuilder = {
    val jmsConnectionParameter = JmsMqConnectionParameterFactory.getJmsMqConnectionParameter(environment)
    val connectionFactory = createConnectionFactory(jmsConnectionParameter)
    jms.connectionFactory(connectionFactory)
      .replyTimeout(FiniteDuration(jmsConnectionParameter.get.getReplyTimeoutMsecs, MILLISECONDS))
      .usePersistentDeliveryMode
      .listenerThreadCount(jmsConnectionParameter.get.getListenerThreadCount)
  }

  private def createConnectionFactory (jmsMqConnectionParameter: Option[JmsMqConnectionParameter]): ConnectionFactoryDecorator[JmsConnectionFactory] = {
    val result = new ConnectionFactoryDecorator(jmsFactoryFactory.createConnectionFactory(),
      delegate => {
        val mqDestination = delegate.asInstanceOf[MQDestination]
        mqDestination.setBooleanProperty(CommonConstants.WMQ_MQMD_WRITE_ENABLED, true)
        mqDestination.setIntProperty(CommonConstants.WMQ_MQMD_MESSAGE_CONTEXT, CommonConstants.WMQ_MDCTX_SET_IDENTITY_CONTEXT)
        mqDestination.setMessageBodyStyle(CommonConstants.WMQ_MESSAGE_BODY_MQ)
      })

    result.getDelegate.setStringProperty(CommonConstants.WMQ_HOST_NAME, jmsMqConnectionParameter.get.getHostName)
    result.getDelegate.setIntProperty(CommonConstants.WMQ_PORT, jmsMqConnectionParameter.get.getHostPort)
    result.getDelegate.setStringProperty(CommonConstants.WMQ_CHANNEL, jmsMqConnectionParameter.get.getChannelName)
    result.getDelegate.setIntProperty(CommonConstants.WMQ_CONNECTION_MODE, CommonConstants.WMQ_CM_CLIENT)
    result.getDelegate.setStringProperty(CommonConstants.WMQ_QUEUE_MANAGER, jmsMqConnectionParameter.get.getQueueManagerName)

    result
  }
}
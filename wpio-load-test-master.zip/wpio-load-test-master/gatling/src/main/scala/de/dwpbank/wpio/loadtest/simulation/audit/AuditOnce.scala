package de.dwpbank.wpio.loadtest.simulation.audit

import de.dwpbank.wpio.loadtest.common.JmsMqConfigurationRfH2._
import de.dwpbank.wpio.loadtest.common.WpioTemplateScenario
import io.gatling.core.Predef.Simulation
import io.gatling.javaapi.core.CoreDsl._
import io.gatling.jms.Predef._

class AuditOnce extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  var header: Array[String] = Array[String](
    "ServiceDetails_SlaEnabled",
    "ServiceDetails_ServiceTp",
    "AuditDetails_DataFormat",
    "AuditDetails_NewPropertyStyle",
    "ParentDetails_AuditId",
    "ParentDetails_AccessId",
    "ParentDetails_ClientId",
    "AuditDetails_AuditTS",
    "AuditDetails_LogData",
    "AuditDetails_AuditTp",
    "AuditDetails_AuditSts",
    "LogPoint_BorderId",
    "LogPoint_Direction",
    "LogPoint_MsgTp",
    "ServiceDetails_ServiceId",
    "ServiceDetails_Input",
    "ServiceDetails_Output",
    "MsgIds_ParentId",
    "MsgIds_ChildId",
    "JMS_IBM_Character_Set",
    "JMS_IBM_MsgType",
    "JMS_IBM_Encoding",
    "JMS_IBM_Format",
    "Usr_JMS_IBM_MQMD_ApplIdentityData",
    "Usr_JMS_IBM_MQMD_ApplOriginData",
    "Usr_JMS_IBM_MQMD_CodedCharSetId",
    "Usr_JMS_IBM_MQMD_Encoding",
    "Usr_JMS_IBM_MQMD_Expiry",
    "Usr_JMS_IBM_MQMD_Format",
    "Usr_JMS_IBM_MQMD_MsgFlags",
    "Usr_JMS_IBM_MQMD_MsgType",
    "Usr_JMS_IBM_MQMD_Persistence",
    "Usr_JMS_IBM_MQMD_Priority",
    "Usr_JMS_IBM_MQMD_PutApplName",
    "Usr_JMS_IBM_MQMD_PutApplType",
    "Usr_JMS_IBM_MQMD_ReplyToQ",
    "Usr_JMS_IBM_MQMD_ReplyToQMgr",
    "Usr_JMS_IBM_MQMD_UserIdentifier",
    "Usr_JMS_IBM_MQMD_PutDate",
    "Usr_JMS_IBM_MQMD_PutTime",
    "Usr_MQRFH2_Version",
    "Usr_MQRFH2_Format",
    "Usr_MQRFH2_CodedCharSetId",
    "Usr_MQRFH2_Encoding",
    "Usr_MQRFH2_NameValueCCSID",
    "Usr_Indexing_FIELDLIST",
    "Usr_Indexing_FIELDLIST_MD5"
  )

  val deposit = new WpioTemplateScenario("DEPOSIT - TEST", filePrefix+"audit/orderbook.json", header)

  setUp(
    deposit.get().injectOpen(atOnceUsers(1)).asScala().protocols(jmsConfigPersistent)
  )
}

package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
  * Dieser Test sendet Orderbook Anfragen von 13 versch. Client IDs in einer gewissen Verteilung,
  * die einer durchschnittlichen Stunde um 9 Uhr aehneln soll. Pro Client ID wird unterschieden in
  * Szenarien, bei denen die Antwortnachrichten des Backends von 1 bis 125 variieren. Diese Szenarien
  * werden ebenfalls noch einmal prozentual verteilt (wenige grosse Antworten, viele kleine).
  *
  * Der Test arbeitet mit der konstanten Durchschnittslast 1,33 rps 
  *
  */
class DwpOrderbookConstantLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)

  // Gesamte Dauer des Tests in Sekunden
  val durationPhase: Int = 1200

  // rps der einzelnen Clients, Gesamt RPS ist 1,33
  val rps1822: Float = 0.0142f
  val rpsDegussa: Float = 0.0071f
  val rpsDkb: Float = 0.03f
  val rpsEbase: Float = 0.3325f
  val rpsFi: Float = 0.1529f
  val rpsFidDzBan: Float = 0.0118f
  val rpsFidDzDet: Float = 0.1260f
  val rpsFidDzPer: Float = 0.6875f
  val rpsFidDzSac: Float = 0.0017f
  val rpsFidMlpDet: Float = 0.0010f
  val rpsFidMlpPer: Float = 0.0043f
  val rpsSan: Float = 0.0223f
  val rpsSyd: Float = 0.001f

  // Verteilung der Groesse der Orderbook Antwortnachrichten pro Client ID
  val ratio100percent: Float = 1f
  val ratio80percent: Float = 0.8f
  val ratio15percent: Float = 0.15f
  val ratio4percent: Float = 0.04f
  val ratio1percent: Float = 0.01f

  /** 1822 **/
  val achtzehn22Orderbook1 = new WpioScenario("1822 - 1 response", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val achtzehn22Orderbook2 = new WpioScenario("1822 - 2 responses", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val achtzehn22Orderbook6 = new WpioScenario("1822 - 6 responses", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val achtzehn22Orderbook43 = new WpioScenario("1822 - 43 responses", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")

  /** DEGUSSA **/
  val degussaOrderbook1 = new WpioScenario("DEGUSSA - 1 response", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val degussaOrderbook2 = new WpioScenario("DEGUSSA - 2 responses", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val degussaOrderbook6 = new WpioScenario("DEGUSSA - 6 responses", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val degussaOrderbook43 = new WpioScenario("DEGUSSA - 43 responses", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")


  /** DKB **/
  val dkbOrderbook1 = new WpioScenario("DKB - 1 response", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val dkbOrderbook2 = new WpioScenario("DKB - 2 responses", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val dkbOrderbook6 = new WpioScenario("DKB - 6 responses", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val dkbOrderbook43 = new WpioScenario("DKB - 43 responses", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")

  /** EBASE **/
  val ebaseOrderbook1 = new WpioScenario("EBASE - 1 response", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val ebaseOrderbook2 = new WpioScenario("EBASE - 2 responses", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val ebaseOrderbook6 = new WpioScenario("EBASE - 6 responses", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val ebaseOrderbook43 = new WpioScenario("EBASE - 43 responses", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")

  /** FI **/
  // Uses SYDBANK_BV.REQUEST.DWP.LOAD connector, because we do not want to use SOAP API
  val fiOrderbook1 = new WpioScenario("FI - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val fiOrderbook2 = new WpioScenario("FI - 2 responses", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val fiOrderbook6 = new WpioScenario("FI - 6 responses", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val fiOrderbook43 = new WpioScenario("FI - 43 responses", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")
  val fiOrderbook125 = new WpioScenario("FI - 125 responses", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/125_Teilnachrichten/20201103T125622.143-S-C1-100001.audit", "<OrderbookResponse_1")

  /** FID_DZ BAN **/
  // Uses SYDBANK_BV.REQUEST.DWP.LOAD connector, because DWP.ORDERBOOK is not allowed
  val fidDzBanOrderlist1 = new WpioScenario("FID_DZ BAN - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.06.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK_List_PWL/20210204T133146.680-S-C1-1.audit", "<OrderListResponse_1")
  /** FID_DZ DET **/
  // Uses SYDBANK_BV.REQUEST.DWP.LOAD connector, because DWP.ORDERBOOK is not allowed
  val fidDzDetOrderDetail1 = new WpioScenario("FID_DZ DET - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.07.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK_Detail/20210204T100803.729-S-C1-1.audit", "<OrderDetailResponse_1")
  /** FID_DZ PER **/
  // Uses SYDBANK_BV.REQUEST.DWP.LOAD connector, because DWP.ORDERBOOK is not allowed
  val fidDzPerOrderlist1 = new WpioScenario("FID_DZ PER - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.08.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK_List_PWL/20210204T133146.680-S-C1-1.audit", "<OrderListResponse_1")
  /** FID_DZ SAC **/
  // Uses SYDBANK_BV.REQUEST.DWP.LOAD connector, because DWP.ORDERBOOK is not allowed
  val fidDzSacOrderlist1 = new WpioScenario("FID_DZ SAC - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.09.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK_List_PWL/20210204T133146.680-S-C1-1.audit", "<OrderListResponse_1")
  /** FID_MLP DET **/
  // Uses SYDBANK_BV.REQUEST.DWP.LOAD connector, because DWP.ORDERBOOK is not allowed
  val fidMlpDetOrderDetail1 = new WpioScenario("FID_MLP DET - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.10.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK_Detail/20210204T100803.729-S-C1-1.audit", "<OrderDetailResponse_1")
  /** FID_MLP PER **/
  // Uses SYDBANK_BV.REQUEST.DWP.LOAD connector, because DWP.ORDERBOOK is not allowed
  val fidMlpPerOrderlist1 = new WpioScenario("FID_MLP PER - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.11.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK_List_PWL/20210204T133146.680-S-C1-1.audit", "<OrderListResponse_1")

  /** SAN **/
  val sanOrderbook1 = new WpioScenario("SAN - 1 response", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val sanOrderbook2 = new WpioScenario("SAN - 2 responses", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val sanOrderbook6 = new WpioScenario("SAN - 6 responses", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val sanOrderbook43 = new WpioScenario("SAN - 43 responses", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")
  val sanOrderbook125 = new WpioScenario("SAN - 125 responses", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/125_Teilnachrichten/20201103T125622.143-S-C1-100001.audit", "<OrderbookResponse_1")

  /** SYD **/
  val sydOrderbook1 = new WpioScenario("SYD - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.13.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/1_Teilnachricht/20210129T061114.182-S-C1-100001.audit", "<OrderbookResponse_1")
  val sydOrderbook2 = new WpioScenario("SYD - 2 responses", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.13.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/2_Teilnachrichten/20210204T122652.722-S-C1-1.audit", "<OrderbookResponse_1")
  val sydOrderbook6 = new WpioScenario("SYD - 6 responses", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.13.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/6_Teilnachrichten/20210204T090116.881-S-C1-1.audit", "<OrderbookResponse_1")
  val sydOrderbook43 = new WpioScenario("SYD - 43 responses", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.13.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DWP.ORDERBOOK/43_Teilnachrichten/20210106T131009.634-S-C1-100001.audit", "<OrderbookResponse_1")



  setUp(

    //EBASE
    ebaseOrderbook1.get.inject(
      constantUsersPerSec(rpsEbase * 0.65f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    ebaseOrderbook2.get.inject(
      constantUsersPerSec(rpsEbase * 0.25f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    ebaseOrderbook6.get.inject(
      constantUsersPerSec(rpsEbase * 0.05f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    ebaseOrderbook43.get.inject(
      constantUsersPerSec(rpsEbase * 0.05f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),

    //FI
    fiOrderbook1.get.inject(
      constantUsersPerSec(rpsFi * 0.70f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    fiOrderbook2.get.inject(
      constantUsersPerSec(rpsFi * 0.15f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    fiOrderbook6.get.inject(
      constantUsersPerSec(rpsFi * 0.13f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    fiOrderbook43.get.inject(
      constantUsersPerSec(rpsFi * 0.01f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    fiOrderbook125.get.inject(
      constantUsersPerSec(rpsFi * 0.01f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),

    //SAN
    sanOrderbook1.get.inject(
      constantUsersPerSec(rpsSan * 0.79f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    sanOrderbook2.get.inject(
      constantUsersPerSec(rpsSan * 0.15f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    sanOrderbook6.get.inject(
      constantUsersPerSec(rpsSan * 0.04f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    sanOrderbook43.get.inject(
      constantUsersPerSec(rpsSan * 0.01f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    sanOrderbook125.get.inject(
      constantUsersPerSec(rpsSan * 0.01f) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),

    //SYD
    sydOrderbook1.get.inject(
      constantUsersPerSec(rpsSyd * ratio80percent) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    sydOrderbook2.get.inject(
      constantUsersPerSec(rpsSyd * ratio15percent) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    sydOrderbook6.get.inject(
      constantUsersPerSec(rpsSyd * ratio4percent) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    sydOrderbook43.get.inject(
      constantUsersPerSec(rpsSyd * ratio1percent) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),

    //FID_DZ_BAN
    fidDzBanOrderlist1.get.inject(
      constantUsersPerSec(rpsFidDzBan) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    //FID_DZ_DET
    fidDzDetOrderDetail1.get.inject(
      constantUsersPerSec(rpsFidDzDet) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    //FID_DZ_PER
    fidDzPerOrderlist1.get.inject(
      constantUsersPerSec(rpsFidDzPer) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    //FID_DZ_SAC
    fidDzSacOrderlist1.get.inject(
      constantUsersPerSec(rpsFidDzSac) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    //FID_MLP_DET
    fidMlpDetOrderDetail1.get.inject(
      constantUsersPerSec(rpsFidMlpDet) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    //FID_MLP_PER
    fidMlpPerOrderlist1.get.inject(
      constantUsersPerSec(rpsFidMlpPer) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent)

  )
}



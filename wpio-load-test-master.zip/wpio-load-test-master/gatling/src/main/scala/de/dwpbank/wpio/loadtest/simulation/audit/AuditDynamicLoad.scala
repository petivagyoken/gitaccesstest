package de.dwpbank.wpio.loadtest.simulation.audit

import de.dwpbank.wpio.loadtest.common.JmsMqConfigurationRfH2._
import io.gatling.core.Predef.Simulation
import io.gatling.javaapi.core.CoreDsl._
import de.dwpbank.wpio.loadtest.common.WpioTemplateScenario
import io.gatling.jms.Predef._

import java.time.Duration

class AuditDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  var header: Array[String] = Array[String](
    "Usr_JMS_IBM_MQMD_ReplyToQMgr",
    "Usr_JMS_IBM_MQMD_CodedCharSetId",
    "JMS_IBM_MQMD_CodedCharSetId",
    "Usr_Indexing_FIELDLIST",
    "Usr_Indexing_FIELDLIST_MD5",
    "ErrorDetails_Code",
    "Conversion_InputCp",
    "Conversion_OutputCp",
    "MsgIds_ParentId",
    "MsgIds_RequestId",
    "MsgIds_ChildId",
    "LogPoint_BorderId",
    "LogPoint_Direction",
    "LogPoint_MsgTp",
    "ParentDetails_AuditId",
    "ParentDetails_AccessId",
    "ParentDetails_ClientId",
    "AuditDetails_AuditTp",
    "AuditDetails_AuditSts",
    "AuditDetails_AuditTS",
    "AuditDetails_LogData",
    "AuditDetails_DataFormat",
    "AuditDetails_Start",
    "AuditDetails_NewPropertyStyle",
    "ServiceDetails_ServiceId",
    "ServiceDetails_ServiceTp",
    "ServiceDetails_Input",
    "ServiceDetails_Output",
    "ServiceDetails_SlaEnabled",
    "ServiceDetails_ClientId",
    "ServiceDetails_InputServiceId",
    "ServiceDetails_SeqNo",
    "JMSMessageID"
  )

  val depositRR = new WpioTemplateScenario("Deposit RR", filePrefix+"audit/deposit.json", header)
  val depositAD = new WpioTemplateScenario("Deposit AD", filePrefix+"audit/deposit-ad.json", header)

  val orderbookRR = new WpioTemplateScenario("Orderbook RR", filePrefix+"audit/orderbook.json", header)
  val orderbookAD = new WpioTemplateScenario("Orderbook AD", filePrefix+"audit/orderbook-ad.json", header)

  val orderRR = new WpioTemplateScenario("Order RR", filePrefix+"audit/order.json", header)
  val orderAD = new WpioTemplateScenario("Order AD", filePrefix+"audit/order-ad.json", header)

  private val incUsers = 10

  private val times = 5

  private val levelLast = Duration.ofMinutes(2)

  private val ramps = Duration.ofMinutes(3)

  private val startFrom = 15

  private val startFromRR = startFrom * 0.7
  private val startFromAD = startFrom * 0.3

  private val depositRate = 0.4;
  private val orderRate = 0.3;
  private val orderBookRate = 0.3;

  private val depositStartFromRR = startFromRR * depositRate;
  private val orderStartFromRR = startFromRR * orderRate;
  private val orderBookStartFromRR = startFromRR * orderBookRate;

  private val depositIncUsersRR = incUsers * depositRate;
  private val orderIncUsersRR = incUsers * orderRate;
  private  val orderBookIncUsersRR = incUsers * orderBookRate;

  private val orderBookStartFromAD = startFromAD;
  private  val orderBookIncUsersAD = incUsers;


  setUp(
    // 40%
    depositRR.get().injectOpen( incrementUsersPerSec(depositIncUsersRR).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(depositStartFromRR) ).asScala().protocols(jmsConfigPersistent),
    // 30%
    orderbookRR.get().injectOpen( incrementUsersPerSec(orderBookIncUsersRR).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(orderBookStartFromRR) ).asScala().protocols(jmsConfigPersistent),
    // 30%
    orderRR.get().injectOpen( incrementUsersPerSec(orderIncUsersRR).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(orderStartFromRR) ).asScala().protocols(jmsConfigPersistent),
    // 30%
    orderbookAD.get().injectOpen( incrementUsersPerSec(orderBookIncUsersAD).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(orderBookStartFromAD) ).asScala().protocols(jmsConfigPersistent),
  )
}

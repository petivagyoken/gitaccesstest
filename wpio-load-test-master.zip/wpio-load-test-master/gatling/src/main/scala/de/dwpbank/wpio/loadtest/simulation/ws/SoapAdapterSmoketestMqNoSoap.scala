package de.dwpbank.wpio.loadtest.simulation.ws

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * Sendet Sparplan REQs in gleichem Intervall wie Smoketest, nur OHNE SOAP, als Vergleich.
 *
 */
class SoapAdapterSmoketestMqNoSoap extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)

  val fiSparplan = new WpioScenario("FI Sparplan", "FI.REQUEST_INTERNAL.WPI.LOAD", "DWP.RESPONSE_LOCAL.10.LOAD",
    "FI.SPARPLAN0000000000", filePrefix+"FI_WS.SPARPLAN/20200512T111032.006-S-C1-1.audit", "<anzeigenListeResponseElement>")

  setUp(
    fiSparplan.get.inject(
      rampUsersPerSec(1) to (10) during (30 seconds),
      constantUsersPerSec(10) during (60 seconds),
      rampUsersPerSec(10) to (20) during (30 seconds),
      constantUsersPerSec(20) during (120 seconds),
    ).protocols(jmsConfigNonPersistent)
  )

}


package de.dwpbank.wpio.loadtest.common

import java.util.{Map => JMap}
import com.ibm.msg.client.jms.JmsConstants
import io.gatling.commons.validation.{Validation, _}
import io.gatling.core.check.{Check, CheckResult}
import io.gatling.core.session.{Expression, Session}
import io.gatling.jms.JmsCheck

import javax.jms._
import org.slf4j.LoggerFactory

object MqResponsePatternCheck extends MqPayloadCheck((body, session) => {
  val patternMaxLength = 200
  val expectedPattern = session("responsePattern").as[String]
  def logger = LoggerFactory.getLogger("de.dwpbank.wpio.loadtest.common.MqResponsePatternCheck")

  val notExpectedMessage = "Response message does not contain expected pattern"

  //System.out.println("Response payload: "+ body.toString)

  if (body.substring(0, Math.min(patternMaxLength, body.length)).contains(expectedPattern)) {
    CheckResult.NoopCheckResultSuccess
  } else {
    val requestdata = session("requestdata").as[String]
    System.out.println("Bugy response payload: "+ body.toString)
    logger.debug("The response to request {} does not contain the pattern '{}'. Response body was: {}", requestdata, expectedPattern, body.toString)
    notExpectedMessage.failure
  }
})

case class MqPayloadCheck(func: (String, Session) => Validation[CheckResult]) extends JmsCheck  {
  override def check(response: Message, session: Session, preparedCache: JMap[Any, Any]): Validation[CheckResult] = {
    val responseText: Option[String] = response match {
      case bm: BytesMessage => Option(messageBodyAsString(bm))
      case tm: TextMessage => Option(tm.getText)
      case _ => Option.empty
    }
    responseText.map(func(_, session)).getOrElse(s"Unexpected message type: ${response.getClass}".failure)
  }

  private def messageBodyAsString(message: BytesMessage) = {
    val bodyLength = message.getBodyLength.toInt
    val bodyBytes = new Array[Byte](bodyLength)
    message.readBytes(bodyBytes, bodyLength)
    val codePage = message.getStringProperty(JmsConstants.JMS_IBM_CHARACTER_SET)
    new String(bodyBytes, codePage)
  }

  override def checkIf(condition: Expression[Boolean]): Check[Message] = ???

  override def checkIf(condition: (Message, Session) => Validation[Boolean]): Check[Message] = ???
}

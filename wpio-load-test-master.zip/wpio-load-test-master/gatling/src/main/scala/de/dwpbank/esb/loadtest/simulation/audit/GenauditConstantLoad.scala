package de.dwpbank.esb.loadtest.simulation.audit

import de.dwpbank.wpio.loadtest.common.JmsMqConfigurationRfH2._
import de.dwpbank.wpio.loadtest.common.WpioTemplateScenario
import io.gatling.core.Predef.Simulation
import io.gatling.javaapi.core.CoreDsl._
import io.gatling.jms.Predef._

import java.time.Duration

class GenauditConstantLoad extends Simulation {
  val environment = System.getProperty("environment") // local or testlab
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  var header: Array[String] = Array[String](
    "JMS_IBM_Character_Set"
  )

  val auditXml = new WpioTemplateScenario("AUDIT.XML", "../testdata/gen-audit/genaudit-audit-xml.json", header)

  private val testDuration = 30 // minutes

  private val constantUsers = 55

  setUp(
    auditXml.get().injectOpen(constantUsersPerSec(constantUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent)
  )
}

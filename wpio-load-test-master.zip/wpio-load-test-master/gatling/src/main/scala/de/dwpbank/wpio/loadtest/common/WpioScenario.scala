package de.dwpbank.wpio.loadtest.common

import com.ibm.msg.client.jms.JmsConstants
import io.gatling.core.Predef.{ElFileBody, scenario, _}
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.jms.Predef._

class WpioScenario(scenarioName:String, queue:String, replyQueue:String, application:String, testdataFilename:String,
                   responsePattern:String) {

  val get: ScenarioBuilder = scenario(scenarioName)
    .exec(_.set("responsePattern", responsePattern))
    .exec(_.set("applicationIdentity", application))
    .exec(_.set("queue", queue))
    .exec(_.set("requestdata", s"$testdataFilename"))
    .exec(
      jms(scenarioName)
        .requestReply
        .queue(queue)
        .replyQueue(replyQueue)
        .textMessage(ElFileBody(s"$testdataFilename"))
        .property(JmsConstants.JMS_IBM_MQMD_APPLIDENTITYDATA, application)
        .check(MqResponsePatternCheck)
    )

}

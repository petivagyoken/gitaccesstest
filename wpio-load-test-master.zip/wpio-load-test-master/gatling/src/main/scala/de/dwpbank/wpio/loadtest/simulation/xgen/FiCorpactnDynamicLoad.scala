package de.dwpbank.wpio.loadtest.simulation.xgen

import io.gatling.http.Predef.{http, status}
import de.dwpbank.wpio.loadtest.common.SoapConfiguration
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * This load test simulation is made for testing the FI.CORPACTN XGEN service.
 * It is based on production load deviation at 9am.
 */
class FiCorpactnDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  // Gesamte Dauer des Tests in Minuten
  val durationPhase: Int = 60 // min. 20

  // on prod sum 20462 requests on a busy hour
  var rps: Int = 20462 / 60 / 60

  // rps per client
  val fi_corpactnRps: Float = rps * 1f

  // Multiplizierer verändert die Last entsprechend des Verhältnises. 1 = Standard rps
  val rpsMultiplier: Float = 4.5f // Standard: 1 , Baseline: 1.5, Fakto 3 Baseline: 4.5


  val fi_corpactn: HttpRequestBuilder = http("CORPACTN")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"FI.CORPACTN/20211008T132638.685-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      regex("<kmZuGattungLesenResponseElement>")
    )

  setUp(
    scenario("FI.CORPACTN")
      .exec(fi_corpactn)
      .inject(
        rampUsersPerSec(fi_corpactnRps) to fi_corpactnRps * rpsMultiplier during (durationPhase minutes)
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

  )
}



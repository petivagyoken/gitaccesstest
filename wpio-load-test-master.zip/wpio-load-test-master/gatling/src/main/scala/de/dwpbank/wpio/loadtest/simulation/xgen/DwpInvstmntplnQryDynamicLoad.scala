package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.{SoapConfiguration, WpioScenario}
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder
import scala.language.postfixOps
import scala.concurrent.duration._
import io.gatling.jms.Predef._

/**
 * This load test simulation is made for testing the DWP.INVSTMNTPLN_QRY XGEN service.
 * It is based on production load deviation at 9am.
 */
class DwpInvstmntplnQryDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  // Gesamte Dauer des Tests in Minuten
  val durationPhase: Int = 60 // min. 20

  // on prod sum 13525 requests on a busy hour on 15 nodes
  var rps = 13525f / 15f / 60f / 60f

  // rps per client
  val fi_invstmntpln_qryRps: Float = rps * 0.91f
  val sonstigeRps: Float = rps * 0.09f

  // Multiplizierer verändert die Last entsprechend des Verhältnises. 1 = Standard rps
  // Standard: 1 , Baseline: 1.5, Fakto 3 Baseline: 4.5
  val rpsMultiplier: Float = 4.5f


  val fiInvstmntplnQry = new WpioScenario("FI Sparplan", "FI.REQUEST_INTERNAL.WPI.LOAD", "WPI.RESPONSE_INTERNAL.FI.LOAD",
    "FI.SPARPLAN.A1000000000", filePrefix+"DWP.INVSTMNTPLN_QRY/20211008T173118.964-S-C2-100001.audit", "<ns:anzeigenListeResponseElement")

  val sonstige = new WpioScenario("Sonstige", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DWP.INVSTMNTPLN_QRY", filePrefix+"DWP.INVSTMNTPLN_QRY/20211008T173119.020-S-B2-1.audit", "<InvestmentPlanListResponse_2")

  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  setUp(
    fiInvstmntplnQry.get.inject(
      rampUsersPerSec(fi_invstmntpln_qryRps) to fi_invstmntpln_qryRps * rpsMultiplier during (durationPhase minutes)
    ).protocols(jmsConfigPersistent) ,

    sonstige.get.inject(
      rampUsersPerSec(sonstigeRps) to sonstigeRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigPersistent)
  )
}



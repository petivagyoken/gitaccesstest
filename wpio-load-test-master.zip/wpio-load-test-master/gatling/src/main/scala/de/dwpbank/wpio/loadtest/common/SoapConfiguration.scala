package de.dwpbank.wpio.loadtest.common

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

object SoapConfiguration {

  private val soapUrlRemote = "http://2.153.29.90:8080"
  private val soapUrlLocal = "http://soapadapter:8080"

  def httpProtocol(env: String): HttpProtocolBuilder = {
    var url = soapUrlLocal
    if (env != "LOCAL") {
      url = soapUrlRemote
    }

    http.baseUrl(url)
      .shareConnections
  }
}

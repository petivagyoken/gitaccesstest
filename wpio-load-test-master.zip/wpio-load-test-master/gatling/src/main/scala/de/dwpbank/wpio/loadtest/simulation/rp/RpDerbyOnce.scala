package de.dwpbank.wpio.loadtest.simulation.rp

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.{Property, WpioScenario}
import io.gatling.core.Predef._

import scala.language.postfixOps
import io.gatling.jms.Predef._

import scala.util.Try

class RpDerbyOnce extends Simulation {
  val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  val simulationProperties = Property.getExtraSystemProperties(getClass.getSimpleName+".json")

  // Properties über Keys auslesen
  val constantUsers = simulationProperties("constantUsers").str.toInt // Constant User Rate

  val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)
  val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  val degussaDeposit = new WpioScenario("Degussa Deposit", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.DEPOSIT", filePrefix+"Degussa_DWP.DEPOSIT_multi_response_2_msgs/20200408T125803.390-S-C1-100001.audit", "<DepositResponse_1")

  val dkbOrder = new WpioScenario("DKB Order", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDER", filePrefix+"DZ_DZ_DZ.ORDER_ERF/20200512T110104.576-S-B2-1.audit", "<OrderResponse_1")

  val dkbOrderbook = new WpioScenario("DKB Orderbook", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"FID_DZ.ORDERBOOK_PER/20200511T151706.955-S-B2-1.audit", "<OrderListResponse_1")

  val dzOrdererfassung = new WpioScenario("DZ Ordererfassung", "DZ_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.07.LOAD",
    "DZ.ORDER_ERF.01_14", filePrefix+"DZ_DZ_DZ.ORDER_ERF/20200512T110104.058-S-C1-100001.audit", "<dz:OrderErfassungResponse")

  val fiduciaOrderbook = new WpioScenario("Fiducia Orderbook", "FIDUCIA_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.08.LOAD",
    filePrefix+"DZ.ORDERBOOK_PER.01_03", "FID_DZ.ORDERBOOK_PER/20200511T151706.918-S-C1-100001.audit", "<dz:OrderanzeigePersoenlichResponse")

  setUp(
    fiduciaOrderbook.get.inject(
      atOnceUsers(1)
    ).protocols(jmsConfigNonPersistent),
  )
}


package de.dwpbank.wpio.loadtest.simulation.ws

import de.dwpbank.wpio.loadtest.common.SoapConfiguration
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * Dynamische Last Simulation, wie definiert in ITZKDSST-319.
  *
  * Lastverlauf im Testszenario:
  *
  * Baseline/Warmup: Start mit 2 req/sec
  * 5 Minuten halten
  * bisherige Maximallast: Anstieg auf 4 req/sec innerhalb 2 Minuten**
  * 5 Minuten halten
  * Erwartete Maximallast nach Umstellung OSPLusNeo Ende Dezember: Anstieg auf 8 req/sec innerhalb 2 Minuten**
  * 5 Minuten halten
  * Puffer: Anstieg auf 10 req/sec innerhalb 2 Minuten**
  * 5 Minuten halten
  *
  * Anstiege in der Produktion am 09.11.2020 waren deutlich langsamer: Verdoppelung innerhalb 10 Minuten
 *
 */
class SoapAdapterDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  val request: HttpRequestBuilder = http("Sparplan")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"FI_WS.SPARPLAN/20200512T111032.006-S-C1-1.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  setUp(
    scenario("SOAP Dynamic Load")
      .exec(request)
      .inject(

        // warmup
        constantUsersPerSec(1) during (1 minute),
        constantUsersPerSec(2) during (4 minutes),

        // known max. production load
        rampUsersPerSec(2) to 4 during (2 minutes),
        constantUsersPerSec(4) during (5 minutes),

        // new max. load after OSPlusNeo 12/2020
        rampUsersPerSec(4) to 8 during (2 minutes),
        constantUsersPerSec(8) during (5 minutes),

        // to the max
        rampUsersPerSec(8) to 10 during (2 minutes),
        constantUsersPerSec(10) during (5 minutes),

      ).protocols(SoapConfiguration.httpProtocol(environment))
  ).assertions(
    global.responseTime.percentile4.lt(300),
    global.successfulRequests.percent.gt(99)
  )

}


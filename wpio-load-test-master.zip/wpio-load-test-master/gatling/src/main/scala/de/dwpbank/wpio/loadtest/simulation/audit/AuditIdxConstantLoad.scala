package de.dwpbank.wpio.loadtest.simulation.audit

import java.time.Duration

import de.dwpbank.wpio.loadtest.common.JmsMqConfigurationRfH2._
import de.dwpbank.wpio.loadtest.common.WpioTemplateScenario
import io.gatling.core.Predef.Simulation
import io.gatling.javaapi.core.CoreDsl._
import io.gatling.jms.Predef._

class AuditIdxConstantLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  private val testDuration = 30 // minutes
  
  private val constantUsers = 10 // 10 * 2 * 7 = 140 rps -> constantUsers * (number of entries in json file) * (number of scenarios) 

  private val constandAdUsers = 36 
  
  var header: Array[String] = Array[String](
    "Usr_Indexing_FIELDLIST",
    "ParentDetails_AuditId",
    "ParentDetails_AccessId",
    "ParentDetails_ClientId",
    "AuditDetails_AuditTp",
    "AuditDetails_AuditSts",
    "AuditDetails_AuditTS",
    "AuditDetails_LogData",
    "AuditDetails_DataFormat",
    "AuditDetails_NewPropertyStyle",
    "ServiceDetails_ServiceId",
    "ServiceDetails_ServiceTp",
    "ServiceDetails_Input",
    "ServiceDetails_Output",
    "LogPoint_MsgTp",
    "LogPoint_Direction",
    "JMS_IBM_Character_Set",
    "JMS_IBM_MQMD_ReplyToQ",
    "Usr_Indexing_FIELDLIST_MD10",
    "Usr_JMS_IBM_MQMD_ReplyToQMgr",
    "Usr_Indexing_FIELDLIST_MD5",
    "USR_JMS_IBM_MQMD_REPLY_TO_QMGR"
  )

  val depositDegussa = new WpioTemplateScenario("Deposit - Degussa", filePrefix+"audit-idx/audit-idx_degussa-deposit.json", header)

  val depositDkb = new WpioTemplateScenario("Deposit - DKB", filePrefix+"audit-idx/audit-idx_dkb-deposit.json", header)

  val orderBookDkb = new WpioTemplateScenario("Orderbook - DKB", filePrefix+"audit-idx/audit-idx_dkb-orderbook.json", header)

  val orderBookDegussa = new WpioTemplateScenario("Orderbook - Degussa", filePrefix+"audit-idx/audit-idx_degussa-orderbook.json", header)

  val orderInsertDkb = new WpioTemplateScenario("Order Insert - DKB", filePrefix+"audit-idx/audit-idx_dkb-order-insert.json", header)

  val orderInsertDegussa = new WpioTemplateScenario("Order Insert - Degussa", filePrefix+"audit-idx/audit-idx_degussa-order-insert.json", header)

  val cstmrmstrQry = new WpioTemplateScenario("Cstmrmstr Qry - DZ", filePrefix+"audit-idx/audit-idx_dz-cstmrmstr-qry.json", header)

  val orderAdDkb = new WpioTemplateScenario("Order AD - DKB", filePrefix+"audit-idx/audit-idx_dkb-order-ad.json", header)
  
  setUp(
    // RR
    depositDegussa.get().injectOpen(constantUsersPerSec(constantUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent),
    depositDkb.get().injectOpen(constantUsersPerSec(constantUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent),
    orderBookDkb.get().injectOpen(constantUsersPerSec(constantUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent),
    orderBookDegussa.get().injectOpen(constantUsersPerSec(constantUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent),
    orderInsertDkb.get().injectOpen(constantUsersPerSec(constantUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent),
    orderInsertDegussa.get().injectOpen(constantUsersPerSec(constantUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent),
    cstmrmstrQry.get().injectOpen(constantUsersPerSec(constantUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent),
    // AD    
    orderAdDkb.get().injectOpen(constantUsersPerSec(constandAdUsers).during(Duration.ofMinutes(testDuration))).asScala().protocols(jmsConfigPersistent),
  )
}

package de.dwpbank.wpio.loadtest.simulation.http

import de.dwpbank.wpio.loadtest.common.HttpConfiguration
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder
import scala.language.postfixOps
import scala.concurrent.duration._
import java.util.Date

class HttpAdapterConstantLoad extends Simulation {

  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  val request: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  val request2: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-2.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  val request3: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-3.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  val request4: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-4.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  val request5: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-5.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  val request6: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-6.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )
  val request7: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-7.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  val request8: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-8.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  val request9: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-9.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  val request10: HttpRequestBuilder = http("INVSTMNTPLN_QRY")
    .post("/api")
    .header("dwpbank-ClientId","DKB")
    .header("dwpbank-AccessId","DWP.INVSTMNTPLN_QRY")
    .header("Date", new Date().toString())
    .header("Cache-Control","no-cache, max-age=0")
    .header("Content-Type","service/vnd.dwpbank.wpio.request+text; version=1")
    .body(
      ElFileBody("../testdata/DKB_HTTP.SPARPLAN/20200512T111032.006-S-C1-1-10.audit")).asXml
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  setUp(
    scenario("HTTP constant Load 1")
      .exec(request)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 2")
      .exec(request2)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 3")
      .exec(request3)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 4")
      .exec(request4)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 5")
      .exec(request5)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 6")
      .exec(request6)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 7")
      .exec(request7)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 8")
      .exec(request8)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 9")
      .exec(request9)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
    scenario("HTTP constant Load 10")
      .exec(request10)
      .inject(
        constantUsersPerSec(20) during (0.5 hours)
      ).protocols(HttpConfiguration.httpProtocol(environment)),
  )

}


package de.dwpbank.wpio.loadtest.simulation.ad

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioPushScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

class AdFwdispoConstantLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  val test1 = new WpioPushScenario("HSHNORD.DEPOT_AD", "CI.FWDISPO_AD.WPI.LOAD",
    "DWP.FWDISPO_AD", filePrefix+"ad-fwdispo/jcf-ad-dwp-fwdispo_test1.txt")
	
  val test2 = new WpioPushScenario("DEGUSSA.DEPOT.AD", "CI.FWDISPO_AD.WPI.LOAD",
    "DWP.FWDISPO_AD", filePrefix+"ad-fwdispo/jcf-ad-dwp-fwdispo_test2.txt")

  setUp(
    test1.get.inject(
		  constantUsersPerSec(2) during (1800 seconds),
    ).protocols(jmsConfigNonPersistent),
    test2.get.inject(
      constantUsersPerSec(2) during (1800 seconds),
    ).protocols(jmsConfigNonPersistent),
  )
}


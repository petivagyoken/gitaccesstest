package de.dwpbank.esb.loadtest.simulation.derby

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import de.dwpbank.wpio.loadtest.common.Property
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

class EsbDerbyDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  val simulationProperties = Property.getExtraSystemProperties(getClass.getSimpleName+".json")

  // Properties über Keys auslesen
  val testDuration = simulationProperties("testDuration").str.toFloat // minutes

  // Multiplier to adjust total load according to set ratios.
  val rpsMultiplier: Float = simulationProperties("rpsMultiplier").str.toFloat

  
  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  val dwpberechtigung = new WpioScenario("ESB DerbyDB - dwpberechtigung", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWPESB", "../testdata/esb-derby/dwpberechtigung-request.xml", "dwpberechtigung")

  val getCorporateActions = new WpioScenario("ESB DerbyDB - GetCorporateActions", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
      "DWPESB", "../testdata/esb-derby/GetCorporateActions-request.xml", "env:targetService")

  val oSPNeoDetail = new WpioScenario("ESB DerbyDB - OSPNeoDetail", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
        "DWPESB", "../testdata/esb-derby/OSPNeoDetail-request.xml", "OSPNeoDetail")

  val readModelSelect = new WpioScenario("ESB DerbyDB - ReadModelSelect", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
          "DWPESB", "../testdata/esb-derby/ReadModelSelect-request.xml", "ReadModelSelect")

  setUp(
    dwpberechtigung.get.inject(
      rampUsersPerSec(3) to (3 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigPersistent),
    /*
    getCorporateActions.get.inject(
      atOnceUsers(1)
    )protocols(jmsConfigPersistent),
    */
    oSPNeoDetail.get.inject(
      rampUsersPerSec(3) to (3 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigPersistent),
    readModelSelect.get.inject(
      rampUsersPerSec(3) to (3 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigPersistent),
  )

}

package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
  * Dieser Test sendet Deposit Anfragen von 10 versch. Client IDs in einer gewissen Verteilung,
  * die einer durchschnittlichen Stunde um 9 Uhr aehneln soll. Pro Client ID wird unterschieden in
  * Szenarien, bei denen die Antwortnachrichten des Backends variieren. Diese Szenarien
  * werden ebenfalls noch einmal prozentual verteilt (wenige grosse Antworten, viele kleine).
  *
  * Der Test startet mit der Durchschnittslast 5,9 rps und erhoeht diese dann kontinuierlich,
  * bis der Multiplizierer erreicht ist.
  *
  */
class DwpAcctgbookDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)

  val multiplier: Float = 5f  

  val times: Int = 10

  val levelLast: Int = 2

  val ramps: Int = 1

  val startFrom: Float = 0.46f

  val incUsers: Float = ((startFrom * multiplier) - startFrom) / times

  var request10Percentage = 0.9f

  var request100Percentage = 0.09f

  var request2000Percentage = 0.01f

  val request10 = new WpioScenario("DWP.ACCTGBOOK 10", "TEST.REQUEST_LOCAL.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD", "DWP.ACCTGBOOK", filePrefix+"DWP.ACCTGBOOK/abrechnungsbuchRequest_10.xml", "<AccountingBookResponse_1")
  
  val request100 = new WpioScenario("DWP.ACCTGBOOK 100", "TEST.REQUEST_LOCAL.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD", "DWP.ACCTGBOOK", filePrefix+"DWP.ACCTGBOOK/abrechnungsbuchRequest_100.xml", "<AccountingBookResponse_1")
  
  val request2000 = new WpioScenario("DWP.ACCTGBOOK 2000", "TEST.REQUEST_LOCAL.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD", "DWP.ACCTGBOOK", filePrefix+"DWP.ACCTGBOOK/abrechnungsbuchRequest_2000.xml", "<AccountingBookResponse_1")

  setUp(
    request10.get.inject(
      incrementUsersPerSec(incUsers * request10Percentage).times(times).eachLevelLasting(levelLast minutes).separatedByRampsLasting(ramps minutes).startingFrom(startFrom * request10Percentage)
    ).protocols(jmsConfigNonPersistent),

    request100.get.inject(
      incrementUsersPerSec(incUsers * request100Percentage).times(times).eachLevelLasting(levelLast minutes).separatedByRampsLasting(ramps minutes).startingFrom(startFrom * request100Percentage)
    ).protocols(jmsConfigNonPersistent),

    request2000.get.inject(
      incrementUsersPerSec(incUsers * request2000Percentage).times(times).eachLevelLasting(levelLast minutes).separatedByRampsLasting(ramps minutes).startingFrom(startFrom * request2000Percentage)
    ).protocols(jmsConfigNonPersistent),
  )

}



package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * This load test simulation is made for testing the DWP.ORDER XGEN service.
 * It is based on production load deviation at 9am.
 * The majority of the requests comes from 1 large and 2 statistically significant clients.
 * The rest are aggregated to a "remaining" client for testing purposes.
 */
class DwpOrderWP3DynamicLoad extends Simulation {

  // Gesamte Dauer des Tests in Minuten
  val durationPhase: Int = 60 // min. 20

  // on prod sum 18845 order related requests on a busy hour
  var rps = 22190 / 60 / 60

  // rps per client
  val fid_dzRps: Float = rps * 0.53f
  val dz_dzRps: Float = rps * 0.14f
  val dkbRps: Float = rps * 0.19f
  val sonstigeRps: Float = rps * 0.14f

  // Multiplizierer verändert die Last entsprechend des Verhältnises. 1 = Standard rps
  val rpsMultiplier: Float = 4.5f // Standard: 1 , Baseline: 1.5, Fakto 3 Baseline: 4.5
  val order = new WpioScenario("WP3 ORDER", "FIDUCIA_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDER", "DWP.ORDER/WP3/request_in.audit", "")

  private val jmsConfigPersistent = createjmsConnectionPersistent()

  setUp(

    order.get.inject(
      rampUsersPerSec(fid_dzRps) to fid_dzRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigPersistent),

  )
}



package de.dwpbank.wpio.loadtest.simulation.rp

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.{Property, WpioScenario}
import io.gatling.core.Predef._
import io.gatling.jms.Predef._

import scala.language.postfixOps
import scala.concurrent.duration._

class RpKafkaDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  val simulationProperties = Property.getExtraSystemProperties(getClass.getSimpleName+".json")

  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  val times: Int = simulationProperties("times").str.toInt

  val levelLast: Int =  simulationProperties("levelLast").str.toInt

  val ramps: Int =  simulationProperties("ramps").str.toInt

  val startFrom: Float = simulationProperties("startFrom").str.toFloat

  val incUsers: Float = simulationProperties("incUsers").str.toFloat

  val quote = new WpioScenario("Quote", "WPI.KAFKA.REQUEST.LOAD", "WPI.B3.RESPONSE.LOAD",
    "WP3.QUOTE", filePrefix+"DWP.QUOTE_KAFKA/request-01.json", "depotnummer")

  setUp(
    quote.get.inject(
      incrementUsersPerSec(incUsers)
        .times(times)
        .eachLevelLasting(levelLast minutes)
        .separatedByRampsLasting(ramps minutes)
        .startingFrom(startFrom)
    ).protocols(jmsConfigPersistent),
  )
}

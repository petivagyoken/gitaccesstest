package de.dwpbank.wpio.loadtest.simulation.ad

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioPushScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

class AdDwpWiiDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val testDuration = 2
  private val constantUsers =2

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  val hshnordDepotAd = new WpioPushScenario("HSHNORD.DEPOT_AD", "QSNT.QPUB_DATA.WPIT.LOAD.01",
    "HSHNORD.DEPOT_AD", filePrefix+"ad-dwp-wii/stt002_301_insertRow.xml")
	
  val degussaDepotAd = new WpioPushScenario("DEGUSSA.DEPOT.AD", "QSNT.QPUB_DATA.WPIT.LOAD.01", 
    "DWP.DEPOT_AD.862", filePrefix+"ad-dwp-wii/stt002_862_updateRow.xml")


  setUp(
    hshnordDepotAd.get.inject(
      atOnceUsers(1),	  
	  rampUsersPerSec(5) to 50 during (600 seconds),	  
		//rampUsersPerSec(300) to 1000 during (40 seconds),
		//constantUsersPerSec(10) during (300 seconds),
    ).protocols(jmsConfigNonPersistent),
	degussaDepotAd.get.inject(atOnceUsers(1),
	  rampUsersPerSec(5) to 50 during (600 seconds),
		//rampUsersPerSec(300) to 1000 during (40 seconds),      
		//constantUsersPerSec(10) during (300 seconds),
    ).protocols(jmsConfigNonPersistent),
  )
}


package de.dwpbank.wpio.loadtest.common

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

object HttpConfiguration {

  private val httpUrlRemote = "http://2.153.29.90:8080"
  private val httpUrlLocal = "http://httpadapter:8080"

  def httpProtocol(env: String): HttpProtocolBuilder = {
    var url = httpUrlLocal
    if (env != "LOCAL") {
      url = httpUrlRemote
    }
    http.baseUrl(url)
      .shareConnections
  }

}
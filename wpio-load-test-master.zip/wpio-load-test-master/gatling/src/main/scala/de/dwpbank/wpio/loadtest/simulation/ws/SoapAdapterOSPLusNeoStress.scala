package de.dwpbank.wpio.loadtest.simulation.ws

import de.dwpbank.wpio.loadtest.common.SoapConfiguration
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * Peaklast Simulation.
 *
 * Peaklast der letzten 30 Tage war am 15.10.2020 um 10:56 Uhr mit ~ 1200 Nachrichten/Minute.
 * 1200 / 12 Nodes / 60 Sekunde = 1,666 Nachrichten/Sekunde
 *
 *  Phase 1:
 *  - Baseline/Warmup: Start mit 2 req/sec
 *  - 2 Minute halten
 *
 *  Phase 2:
 *  - bisherige Maximallast: Anstieg auf 4 req/sec innerhalb 2 Minute
 *  - 2 Minute halten
 *
 *  Phase 3:
 *  - Erwartete Maximallast nach Umstellung OSPLusNeo Ende Dezember: Anstieg auf 8 req/sec innerhalb 2 Minute
 *  - 2 Minute halten
 *
 *  Phase 4:
 *  - Puffer: Anstieg auf 10 req/sec innerhalb 2 Minute
 *  - 2 Minute halten
 *
 *  Phase 5:
 *  - Stress Test: Anstieg auf 12 req/sec innerhalb 2 Minute
 *  - 5 Minuten halten
 *
 *  Phase 6:
 *  - Stress Test: Anstieg auf 13 req/sec innerhalb 2 Minute
 *  - 5 Minuten halten
 *
 *  Phase 7:
 *  - Stress Test: Anstieg auf 14 req/sec innerhalb 2 Minute
 *  - 5 Minuten halten
 *
 * Runtime: 35 Minuten
 */
class SoapAdapterOSPLusNeoStress extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  var rpsPhase1 : Int = 2
  var rpsPhase2 : Int = 4
  var rpsPhase3 : Int = 8
  var rpsPhase4 : Int = 10
  var rpsPhase5 : Int = 12
  var rpsPhase6 : Int = 13
  var rpsPhase7 : Int = 14
  
  var durationIncreaseLoad    : Int = 120
  var durationHoldCurrentLoad : Int = 120
  var durationHoldStressLoad  : Int = 300

  var requestCorpactnRatio             : Float = 0.371557638f
  var requestSparplanRatio             : Float = 0.248291598f
  var requestOrderRatio                : Float = 0.142920411f
  var requestWPSucheRatio              : Float = 0.05101332f
  var requestGatStamdatenRatio         : Float = 0.043170086f
  var requestWPHGRatio                 : Float = 0.042076549f
  var requestMifid2WPABRatio           : Float = 0.040510832f
  var requestOrderbuchBRatio           : Float = 0.0389611f
  var requestGattungRatio              : Float = 0.021498466f
  
  // <FinInstrmNm>ISHARES EURO STOXX U.ETF</FinInstrmNm>
  val requestSparplan: HttpRequestBuilder = http("Sparplan")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"FI_WS.SPARPLAN/20200512T111032.006-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  // <EVENT_ID>US36828720782600</EVENT_ID>
  val requestCorpactn : HttpRequestBuilder = http("Corpactn")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"FI_WS.CORPACTN/20200512T104833.811-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("US36828720782600")
    )

  // <TIMESTAMP>2021-01-11-10.39.18.783774</TIMESTAMP>
  val requestOrder : HttpRequestBuilder = http("Order.A")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.ORDER.A/20230123T093041.549-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2023-01-23-09.30.41.286130")
    )

  // <TIMESTAMP>2021-01-11-15.18.59.543109</TIMESTAMP>
  val requestWPSuche : HttpRequestBuilder = http("WPSuche")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.WPSUCHE/20210111T151859.971-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-15.18.59.543109")
    )

  // <TIMESTAMP>2021-01-11-09.48.59.143840</TIMESTAMP>
  val requestGatStamdaten : HttpRequestBuilder = http("GatStamdaten")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.GATSTAMDATEN/20210111T094859.314-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-09.48.59.143840")
    )

  // <TIMESTAMP>2021-01-11-09.36.39.702268</TIMESTAMP>
  val requestWPHG : HttpRequestBuilder = http("WPHG")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.WPHG/20210111T093640.184-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-09.36.39.702268")
    )

  // <ISIN>CA0585861085</ISIN>
  val requestMifid2WPAB : HttpRequestBuilder = http("Mifid2WPAB")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.MIFID2WPAB/20210111T120830.458-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("CA0585861085")
    )

  // <TIMESTAMP>2021-01-11-14.06.05.831</TIMESTAMP>
  val requestOrderbuchB : HttpRequestBuilder = http("Orderbuch.B")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.ORDERBUCH_B/20230206T095252.167-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2023-02-06-09.52.54.035000")
    )

  // <TIMESTAMP>2021-01-11-10.06.22.583000</TIMESTAMP>
  val requestGattung : HttpRequestBuilder = http("Gattung")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.GATTUNG/20210111T100621.381-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-10.06.22.583000")
    )



  setUp(
    scenario("WS.SPARPLAN")
      .exec(requestSparplan)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestSparplanRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestSparplanRatio) to (rpsPhase2 * requestSparplanRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestSparplanRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestSparplanRatio) to (rpsPhase3 * requestSparplanRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestSparplanRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestSparplanRatio) to (rpsPhase4 * requestSparplanRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestSparplanRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestSparplanRatio) to (rpsPhase5 * requestSparplanRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestSparplanRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestSparplanRatio) to (rpsPhase6 * requestSparplanRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestSparplanRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestSparplanRatio) to (rpsPhase7 * requestSparplanRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestSparplanRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.CORPACTN")
      .exec(requestCorpactn)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestCorpactnRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestCorpactnRatio) to (rpsPhase2 * requestCorpactnRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestCorpactnRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestCorpactnRatio) to (rpsPhase3 * requestCorpactnRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestCorpactnRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestCorpactnRatio) to (rpsPhase4 * requestCorpactnRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestCorpactnRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestCorpactnRatio) to (rpsPhase5 * requestCorpactnRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestCorpactnRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestCorpactnRatio) to (rpsPhase6 * requestCorpactnRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestCorpactnRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestCorpactnRatio) to (rpsPhase7 * requestCorpactnRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestCorpactnRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.ORDER.A")
      .exec(requestOrder)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestOrderRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestOrderRatio) to (rpsPhase2 * requestOrderRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestOrderRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestOrderRatio) to (rpsPhase3 * requestOrderRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestOrderRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestOrderRatio) to (rpsPhase4 * requestOrderRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestOrderRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestOrderRatio) to (rpsPhase5 * requestOrderRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestOrderRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestOrderRatio) to (rpsPhase6 * requestOrderRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestOrderRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestOrderRatio) to (rpsPhase7 * requestOrderRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestOrderRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.WPSUCHE")
      .exec(requestWPSuche)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestWPSucheRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestWPSucheRatio) to (rpsPhase2 * requestWPSucheRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestWPSucheRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestWPSucheRatio) to (rpsPhase3 * requestWPSucheRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestWPSucheRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestWPSucheRatio) to (rpsPhase4 * requestWPSucheRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestWPSucheRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestWPSucheRatio) to (rpsPhase5 * requestWPSucheRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestWPSucheRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestWPSucheRatio) to (rpsPhase6 * requestWPSucheRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestWPSucheRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestWPSucheRatio) to (rpsPhase7 * requestWPSucheRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestWPSucheRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.GATSTAMDATEN")
      .exec(requestGatStamdaten)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestGatStamdatenRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestGatStamdatenRatio) to (rpsPhase2 * requestGatStamdatenRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestGatStamdatenRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestGatStamdatenRatio) to (rpsPhase3 * requestGatStamdatenRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestGatStamdatenRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestGatStamdatenRatio) to (rpsPhase4 * requestGatStamdatenRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestGatStamdatenRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestGatStamdatenRatio) to (rpsPhase5 * requestGatStamdatenRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestGatStamdatenRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestGatStamdatenRatio) to (rpsPhase6 * requestGatStamdatenRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestGatStamdatenRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestGatStamdatenRatio) to (rpsPhase7 * requestGatStamdatenRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestGatStamdatenRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.WPHG")
      .exec(requestWPHG)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestWPHGRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestWPHGRatio) to (rpsPhase2 * requestWPHGRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestWPHGRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestWPHGRatio) to (rpsPhase3 * requestWPHGRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestWPHGRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestWPHGRatio) to (rpsPhase4 * requestWPHGRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestWPHGRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestWPHGRatio) to (rpsPhase5 * requestWPHGRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestWPHGRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestWPHGRatio) to (rpsPhase6 * requestWPHGRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestWPHGRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestWPHGRatio) to (rpsPhase7 * requestWPHGRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestWPHGRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.MIFID2WPAB")
      .exec(requestMifid2WPAB)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestMifid2WPABRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestMifid2WPABRatio) to (rpsPhase2 * requestMifid2WPABRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestMifid2WPABRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestMifid2WPABRatio) to (rpsPhase3 * requestMifid2WPABRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestMifid2WPABRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestMifid2WPABRatio) to (rpsPhase4 * requestMifid2WPABRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestMifid2WPABRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestMifid2WPABRatio) to (rpsPhase5 * requestMifid2WPABRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestMifid2WPABRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestMifid2WPABRatio) to (rpsPhase6 * requestMifid2WPABRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestMifid2WPABRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestMifid2WPABRatio) to (rpsPhase7 * requestMifid2WPABRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestMifid2WPABRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.ORDERBUCH_B")
      .exec(requestOrderbuchB)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestOrderbuchBRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestOrderbuchBRatio) to (rpsPhase2 * requestOrderbuchBRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestOrderbuchBRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestOrderbuchBRatio) to (rpsPhase3 * requestOrderbuchBRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestOrderbuchBRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestOrderbuchBRatio) to (rpsPhase4 * requestOrderbuchBRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestOrderbuchBRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestOrderbuchBRatio) to (rpsPhase5 * requestOrderbuchBRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestOrderbuchBRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestOrderbuchBRatio) to (rpsPhase6 * requestOrderbuchBRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestOrderbuchBRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestOrderbuchBRatio) to (rpsPhase7 * requestOrderbuchBRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestOrderbuchBRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.GATTUNG")
      .exec(requestGattung)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestGattungRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestGattungRatio) to (rpsPhase2 * requestGattungRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestGattungRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase2 * requestGattungRatio) to (rpsPhase3 * requestGattungRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestGattungRatio) during (durationHoldCurrentLoad seconds) randomized,
        rampUsersPerSec(rpsPhase3 * requestGattungRatio) to (rpsPhase4 * requestGattungRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestGattungRatio) during (durationHoldCurrentLoad seconds) randomized,

        rampUsersPerSec(rpsPhase4 * requestGattungRatio) to (rpsPhase5 * requestGattungRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase5 * requestGattungRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase5 * requestGattungRatio) to (rpsPhase6 * requestGattungRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase6 * requestGattungRatio) during (durationHoldStressLoad seconds) randomized,
        rampUsersPerSec(rpsPhase6 * requestGattungRatio) to (rpsPhase7 * requestGattungRatio) during (durationIncreaseLoad seconds) randomized,
        constantUsersPerSec(rpsPhase7 * requestGattungRatio) during (durationHoldStressLoad seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,
  )
}

package de.dwpbank.wpio.loadtest.simulation.audit

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._

import scala.concurrent.duration._
import scala.language.postfixOps


class AuditQryConstantLoad extends Simulation {
    private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

    var filePrefix = ""
    if (environment == "LOCAL") {
        filePrefix = "../testdata/"
    }

    private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

    val monitorRequestListRequest = new WpioScenario("Monitor Request - List Request", "WPI.AUDIT_QRY.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD", "SYS.MONITORING", filePrefix+"audit-qry/monitoring-request_list-request_rr.xml", "<MonitoringResponse_1")

    val monitorRequestListRequestFilter = new WpioScenario("Monitor Request - List Request with Filter", "WPI.AUDIT_QRY.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD", "SYS.MONITORING", filePrefix+"audit-qry/monitoring-request_list-request_rr_filter.xml", "<MonitoringResponse_1")

    val testDuration = 10

    setUp(
        monitorRequestListRequest.get.inject {
            constantUsersPerSec(3) during (testDuration minutes)
        }.protocols(jmsConfigPersistent),
        monitorRequestListRequestFilter.get.inject {
            constantUsersPerSec(2) during (testDuration minutes)
        }.protocols(jmsConfigPersistent),
    )

}

package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
  * Dieser Test sendet eine Orderbook Anfragey, die sowohl WP2 als auch WP3 Responses generieren soll
  * Der Test arbeitet mit der konstanten Durchschnittslast 1,33 rps eine halbe Stunde lang
  */
class DwpOrderbookBackendMixConstantLoad extends Simulation {

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent()

  // Gesamte Dauer des Tests in Sekunden, halbe Stunde
  val durationPhase: Int = 1800

  // RPS ist 1,33
  val rps: Float = 1.33f

  /** 1822 **/
  val orderBookRequestBackendMix = new WpioScenario("1822 - 1 response", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.ORDERBOOK", "DWP.ORDERBOOK/3_Teilnachrichten_Backend_Mix/20230914-C1-1.audit", "OrderbookResponse_1")

  setUp(
    orderBookRequestBackendMix.get.inject(
      constantUsersPerSec(rps) during (durationPhase seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
  )
}



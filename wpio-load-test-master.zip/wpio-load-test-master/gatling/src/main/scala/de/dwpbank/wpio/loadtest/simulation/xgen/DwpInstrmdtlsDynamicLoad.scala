package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * This load test simulation is made for testing the DWP.INSTRMDTLS XGEN service.
 * It is based on production load deviation at 9am.
 */
class DwpInstrmdtlsDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  // Gesamte Dauer des Tests in Minuten
  val durationPhase: Int = 60 // min. 20

  // on prod sum 21049 order related requests on a busy hour
  var rps = 21049 / 60 / 60

  // rps per client
  val fid_dzRps: Float = rps * 0.76f
  val dkbRps: Float = rps * 0.18f
  val sonstigeRps: Float = rps * 0.06f

  // Multiplizierer verändert die Last entsprechend des Verhältnises. 1 = Standard rps
  val rpsMultiplier: Float = 4.5f // Standard: 1 , Baseline: 1.5, Fakto 3 Baseline: 4.5


  val fid_dz = new WpioScenario("Fiducia DZ", "FIDUCIA_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DZ.ORDER_ERF.01_14", filePrefix+"DWP.INSTRMDTLS/20211010T224922.649-S-C1-100001.audit", "<dz:OrderErfassungResponse")
  val dkb = new WpioScenario("DKB", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DWP.INSTRMDTLS", filePrefix+"DWP.INSTRMDTLS/20211010T224922.818-S-B2-1.audit", "<InstrumentDetailResponse_1")
  val sonstige = new WpioScenario("Sonstige", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.INSTRMDTLS", filePrefix+"DWP.INSTRMDTLS/20211010T224922.818-S-B2-1.audit", "<InstrumentDetailResponse_1")

  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)
  private val jmsConfigNonPersistent =createjmsConnectionNonPersistent(environment)

  setUp(

    fid_dz.get.inject(
      rampUsersPerSec(fid_dzRps) to fid_dzRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigPersistent),

    dkb.get.inject(
      rampUsersPerSec(dkbRps) to dkbRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

    sonstige.get.inject(
      rampUsersPerSec(sonstigeRps) to sonstigeRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

  )
}



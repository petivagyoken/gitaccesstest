package de.dwpbank.wpio.loadtest.simulation.rp

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.{Property, WpioScenario}
import io.gatling.core.Predef._
import io.gatling.jms.Predef._

import scala.language.postfixOps
import scala.concurrent.duration._

class RpDerbyDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  val simulationProperties = Property.getExtraSystemProperties(getClass.getSimpleName+".json")

  // Properties über Keys auslesen
  val testDuration = simulationProperties("testDuration").str.toFloat // minutes

  // Multiplier to adjust total load according to set ratios.
  val rpsMultiplier: Float = simulationProperties("rpsMultiplier").str.toFloat


  // System.out.println(testDuration)
  // System.out.println(rpsMultiplier)

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  val degussaDeposit = new WpioScenario("Degussa Deposit", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.DEPOSIT", filePrefix+"Degussa_DWP.DEPOSIT_multi_response_2_msgs/20200408T125803.390-S-C1-100001.audit", "<DepositResponse_1")

  val dkbInstrmdtls = new WpioScenario("DKB Instrmdtls", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DWP.INSTRMDTLS", filePrefix+"DKB.INSTRMDTLS/20231205T170205.997-S-C1-100001.audit", "<InstrumentDetailResponse_1")

  val dkbOrder = new WpioScenario("DKB Order", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDER", filePrefix+"DKB.ORDER/20231205T164540.409-S-C1-100001.audit", "<OrderResponse_1")

  val dkbOrderbook = new WpioScenario("DKB Orderbook", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDERBOOK", filePrefix+"DKB.ORDERBOOK/20231206T133721.809-S-C1-100001.audit", "<OrderbookResponse_1")

  val fiduciaCstmrmstr = new WpioScenario("Fiducia CSTMRMSTR", "FIDUCIA_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
    "DZ.CSTMRMSTR_QRY.02_11", filePrefix+"FID_DZ_DZ.CSTMRMSTR_QRY/20200512T111054.749-S-C1-100001.audit", "<dz:DepotdatenAnzeigenResponse")

  val fiduciaDeposit = new WpioScenario("Fiducia Deposit", "FIDUCIA_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.06.LOAD",
    "DZ.DEPOSIT.02_04", filePrefix+"FID_DZ_DZ.DEPOSIT/20200512T105639.361-S-C1-100001.audit", "<dz:DepotuebersichtResponse")

  val dzOrdererfassung = new WpioScenario("DZ Ordererfassung", "DZ_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.07.LOAD",
    "DZ.ORDER_ERF.01_14", filePrefix+"DZ_DZ_DZ.ORDER_ERF/20200512T110104.058-S-C1-100001.audit", "<dz:OrderErfassungResponse")

  val fiduciaOrderbook = new WpioScenario("Fiducia Orderbook", "FIDUCIA_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.08.LOAD",
    "DZ.ORDERBOOK_PER.01_03", filePrefix+"FID_DZ.ORDERBOOK_PER/20200511T151706.918-S-C1-100001.audit", "<dz:OrderanzeigePersoenlichResponse")

  val fiCorpactn = new WpioScenario("FI Corpactn", "FI.REQUEST_INTERNAL.WPI.LOAD", "DWP.RESPONSE_LOCAL.09.LOAD",
    "FI.CORPACTN0000000000", filePrefix+"FI_WS.CORPACTN/20200512T104833.811-S-C1-1.audit", "<kmZuGattungLesenResponseElement>")

  val fiSparplan = new WpioScenario("FI Sparplan", "FI.REQUEST_INTERNAL.WPI.LOAD", "DWP.RESPONSE_LOCAL.10.LOAD",
    "FI.SPARPLAN0000000000", filePrefix+"FI_WS.SPARPLAN/20200512T111032.006-S-C1-1.audit", "<anzeigenListeResponseElement>")

  val ebaseBestex = new WpioScenario("Ebase Bestex", "EBASE.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.11.LOAD",
    "DWP.BESTEX", filePrefix+"EBASE.BESTEX/20231205T153112.744-S-C1-100001.audit", "<BestExecutionResponse_2")

  val wp2bMtgen = new WpioScenario("WP2B Mtgen", "WP2B.REQUEST.WPI.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "WP2.MTGEN_A_ONL", filePrefix+"WP2B_WP2.MTGEN_A_ONL/20200522T082110.441-S-C1-100001.audit", "{1:F01DWPBDEDDXXXX0000000000}")

  val wp2bMtgen2 = new WpioScenario("WP2B Mtgen2", "WP2B.REQUEST.WPI.LOAD", "DWP.RESPONSE_LOCAL.13.LOAD",
    "WP2.MTGEN_E_ONL", filePrefix+"WP2B_WP2.MTGEN_E_ONL/20200522T083132.627-S-C1-100001.audit", "$0075/MST")

  setUp(
    degussaDeposit.get.inject(
      rampUsersPerSec(4) to (4 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    dkbInstrmdtls.get.inject(
      rampUsersPerSec(1) to (1 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    dkbOrder.get.inject(
      rampUsersPerSec(1) to (1 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigPersistent),
    dkbOrderbook.get.inject(
      rampUsersPerSec(1) to (1 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    fiduciaCstmrmstr.get.inject(
      rampUsersPerSec(1) to (1 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    fiduciaDeposit.get.inject(
      rampUsersPerSec(3) to (3 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    dzOrdererfassung.get.inject(
      rampUsersPerSec(2) to (2 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigPersistent),
    fiduciaOrderbook.get.inject(
      rampUsersPerSec(2) to (2 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    fiCorpactn.get.inject(
      rampUsersPerSec(1) to (1 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    fiSparplan.get.inject(
      rampUsersPerSec(1) to (1 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    ebaseBestex.get.inject(
      rampUsersPerSec(3) to (3 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigNonPersistent),
    wp2bMtgen.get.inject(
      rampUsersPerSec(1) to (1 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigPersistent),
    wp2bMtgen2.get.inject(
      rampUsersPerSec(1) to (1 * rpsMultiplier) during (testDuration minutes)
    ).protocols(jmsConfigPersistent),
  )
}


package de.dwpbank.wpio.loadtest.simulation.ws

import de.dwpbank.wpio.loadtest.common.SoapConfiguration
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * Peaklast Simulation.
 *
 * Peaklast der letzten 30 Tage war am 15.10.2020 um 10:56 Uhr mit ~ 1200 Nachrichten/Minute.
 * 1200 / 12 Nodes / 60 Sekunde = 1,666 Nachrichten/Sekunde
 *
 */
class SoapAdapterSmoketestSoapFastRamp extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  val request: HttpRequestBuilder = http("Sparplan")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"FI_WS.SPARPLAN/20200512T111032.006-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  setUp(
    scenario("SOAP Peaklast Produktion")
      .exec(request)
      .inject(
        rampUsersPerSec(1) to 20 during (20 seconds),
        constantUsersPerSec(20) during (120 seconds),
      ).protocols(SoapConfiguration.httpProtocol(environment))
  )

}


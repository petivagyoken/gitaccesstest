package de.dwpbank.wpio.loadtest.simulation.ws

import de.dwpbank.wpio.loadtest.common.SoapConfiguration
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * Peaklast Simulation.
 *
 * Peaklast der letzten 30 Tage war am 15.10.2020 um 10:56 Uhr mit ~ 1200 Nachrichten/Minute.
 * 1200 / 12 Nodes / 60 Sekunde = 1,666 Nachrichten/Sekunde
 *
 *  Phase 1:
 *  - Baseline/Warmup: Start mit 2 req/sec
 *  - 5 Minuten halten
 *  Phase 2:
 *  - bisherige Maximallast: Anstieg auf 4 req/sec innerhalb 2 Minuten**
 *  - 5 Minuten halten
 *  Phase 3:
 *  - Erwartete Maximallast nach Umstellung OSPLusNeo Ende Dezember: Anstieg auf 8 req/sec innerhalb 2 Minuten**
 *  - 5 Minuten halten
 *  Phase 4:
 *  - Puffer: Anstieg auf 10 req/sec innerhalb 2 Minuten**
 *  - 5 Minuten halten
 *
 * Runtime: 26 Minuten
 */
class SoapAdapterOSPLusNeoDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  var rpsPhase1 : Int = 2
  var rpsPhase2 : Int = 4
  var rpsPhase3 : Int = 8
  var rpsPhase4 : Int = 10

  var requestCorpactnRatio             : Float = 0.371557638f
  var requestSparplanRatio             : Float = 0.248291598f
  var requestOrderRatio                : Float = 0.142920411f
  var requestWPSucheRatio              : Float = 0.05101332f
  var requestGatStamdatenRatio         : Float = 0.043170086f
  var requestWPHGRatio                 : Float = 0.042076549f
  var requestMifid2WPABRatio           : Float = 0.040510832f
  var requestDepotusichtOrderbuchRatio : Float = 0.0389611f
  var requestGattungRatio              : Float = 0.021498466f 
  
  // <FinInstrmNm>ISHARES EURO STOXX U.ETF</FinInstrmNm>
  val requestSparplan: HttpRequestBuilder = http("Sparplan")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"FI_WS.SPARPLAN/20200512T111032.006-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("ISHARES EURO STOXX U.ETF")
    )

  // <EVENT_ID>US36828720782600</EVENT_ID>
  val requestCorpactn : HttpRequestBuilder = http("Corpactn")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"FI_WS.CORPACTN/20200512T104833.811-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("US36828720782600")
    )

  // <TIMESTAMP>2021-01-11-10.39.18.783774</TIMESTAMP>
  val requestOrder : HttpRequestBuilder = http("Order")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.ORDER.A/20230123T093041.549-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2023-01-23-09.30.41.286130")
    )

  // <TIMESTAMP>2021-01-11-15.18.59.543109</TIMESTAMP>
  val requestWPSuche : HttpRequestBuilder = http("WPSuche")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.WPSUCHE/20210111T151859.971-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-15.18.59.543109")
    )

  // <TIMESTAMP>2021-01-11-09.48.59.143840</TIMESTAMP>
  val requestGatStamdaten : HttpRequestBuilder = http("GatStamdaten")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.GATSTAMDATEN/20210111T094859.314-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-09.48.59.143840")
    )

  // <TIMESTAMP>2021-01-11-09.36.39.702268</TIMESTAMP>
  val requestWPHG : HttpRequestBuilder = http("WPHG")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.WPHG/20210111T093640.184-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-09.36.39.702268")
    )

  // <ISIN>CA0585861085</ISIN>
  val requestMifid2WPAB : HttpRequestBuilder = http("Mifid2WPAB")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.MIFID2WPAB/20210111T120830.458-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("CA0585861085")
    )

  // <TIMESTAMP>2021-01-11-14.06.05.831</TIMESTAMP>
  val requestDepotusichtOrderbuch : HttpRequestBuilder = http("DepotusichtOrderbuch")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.DEPOTUSICHT_ORDERBUCH/20210111T140604.045-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-14.06.05.831")
    )

  // <TIMESTAMP>2021-01-11-10.06.22.583000</TIMESTAMP>
  val requestGattung : HttpRequestBuilder = http("Gattung")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"WS.GATTUNG/20210111T100621.381-S-C1-1.audit")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(200),
      substring("2021-01-11-10.06.22.583000")
    )



  setUp(
    scenario("WS.SPARPLAN")
      .exec(requestSparplan)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestSparplanRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestSparplanRatio) to (rpsPhase2 * requestSparplanRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestSparplanRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestSparplanRatio) to (rpsPhase3 * requestSparplanRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestSparplanRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestSparplanRatio) to (rpsPhase4 * requestSparplanRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestSparplanRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.CORPACTN")
      .exec(requestCorpactn)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestCorpactnRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestCorpactnRatio) to (rpsPhase2 * requestCorpactnRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestCorpactnRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestCorpactnRatio) to (rpsPhase3 * requestCorpactnRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestCorpactnRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestCorpactnRatio) to (rpsPhase4 * requestCorpactnRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestCorpactnRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.ORDER")
      .exec(requestOrder)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestOrderRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestOrderRatio) to (rpsPhase2 * requestOrderRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestOrderRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestOrderRatio) to (rpsPhase3 * requestOrderRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestOrderRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestOrderRatio) to (rpsPhase4 * requestOrderRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestOrderRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.WPSUCHE")
      .exec(requestWPSuche)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestWPSucheRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestWPSucheRatio) to (rpsPhase2 * requestWPSucheRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestWPSucheRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestWPSucheRatio) to (rpsPhase3 * requestWPSucheRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestWPSucheRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestWPSucheRatio) to (rpsPhase4 * requestWPSucheRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestWPSucheRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.GATSTAMDATEN")
      .exec(requestGatStamdaten)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestGatStamdatenRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestGatStamdatenRatio) to (rpsPhase2 * requestGatStamdatenRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestGatStamdatenRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestGatStamdatenRatio) to (rpsPhase3 * requestGatStamdatenRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestGatStamdatenRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestGatStamdatenRatio) to (rpsPhase4 * requestGatStamdatenRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestGatStamdatenRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.WPHG")
      .exec(requestWPHG)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestWPHGRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestWPHGRatio) to (rpsPhase2 * requestWPHGRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestWPHGRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestWPHGRatio) to (rpsPhase3 * requestWPHGRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestWPHGRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestWPHGRatio) to (rpsPhase4 * requestWPHGRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestWPHGRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,

    scenario("WS.MIFID2WPAB")
      .exec(requestMifid2WPAB)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestMifid2WPABRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestMifid2WPABRatio) to (rpsPhase2 * requestMifid2WPABRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestMifid2WPABRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestMifid2WPABRatio) to (rpsPhase3 * requestMifid2WPABRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestMifid2WPABRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestMifid2WPABRatio) to (rpsPhase4 * requestMifid2WPABRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestMifid2WPABRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,
/*
    scenario("WS.DEPOTUSICHT_ORDERBUCH")
      .exec(requestDepotusichtOrderbuch)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestDepotusichtOrderbuchRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestDepotusichtOrderbuchRatio) to (rpsPhase2 * requestDepotusichtOrderbuchRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestDepotusichtOrderbuchRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestDepotusichtOrderbuchRatio) to (rpsPhase3 * requestDepotusichtOrderbuchRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestDepotusichtOrderbuchRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestDepotusichtOrderbuchRatio) to (rpsPhase4 * requestDepotusichtOrderbuchRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestDepotusichtOrderbuchRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol()) ,
*/
    scenario("WS.GATTUNG")
      .exec(requestGattung)
      .inject(
        constantUsersPerSec(rpsPhase1 * requestGattungRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase1 * requestGattungRatio) to (rpsPhase2 * requestGattungRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase2 * requestGattungRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase2 * requestGattungRatio) to (rpsPhase3 * requestGattungRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase3 * requestGattungRatio) during (300 seconds) randomized,

        rampUsersPerSec(rpsPhase3 * requestGattungRatio) to (rpsPhase4 * requestGattungRatio) during (120 seconds) randomized,
        constantUsersPerSec(rpsPhase4 * requestGattungRatio) during (300 seconds) randomized
      ).protocols(SoapConfiguration.httpProtocol(environment)) ,


  )
}

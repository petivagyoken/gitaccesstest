package de.dwpbank.wpio.loadtest.simulation.ad

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioPushBinaryScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

class AdOrderConstantLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  val test1 = new WpioPushBinaryScenario("DWP.ORDER_AD", "WIIC.ORDER_AD_0.WPI.LOAD",
    "DWP.ORDER_AD", filePrefix+"ad-order/jcf-ad-order-test.bin")

  setUp(
    test1.get.inject(
		  constantUsersPerSec(20) during (1800 seconds),
    ).protocols(jmsConfigNonPersistent)
  )
}


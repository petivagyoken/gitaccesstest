package de.dwpbank.esb.loadtest.simulation.audit

import de.dwpbank.wpio.loadtest.common.JmsMqConfigurationRfH2._
import de.dwpbank.wpio.loadtest.common.WpioTemplateScenario
import io.gatling.core.Predef.Simulation
import io.gatling.javaapi.core.CoreDsl._
import io.gatling.jms.Predef._

import java.time.Duration

class GenauditDynamicLoad extends Simulation {
  val environment = System.getProperty("environment") // local or testlab
  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  var header: Array[String] = Array[String](
    "JMS_IBM_Character_Set"
  )

  val auditXml = new WpioTemplateScenario("AUDIT.XML", "../testdata/gen-audit/genaudit-audit-xml.json", header)

  private val incUsers = 5

  private val times = 7

  private val levelLast = Duration.ofMinutes(2)

  private val ramps = Duration.ofMinutes(3)

  private val startFrom = 25

  setUp(
    auditXml.get().injectOpen( incrementUsersPerSec(incUsers).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(startFrom) ).asScala().protocols(jmsConfigPersistent),
  )
}

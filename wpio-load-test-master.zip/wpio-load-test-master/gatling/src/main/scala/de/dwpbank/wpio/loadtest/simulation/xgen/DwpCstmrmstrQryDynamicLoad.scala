package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
  * Dieser Test sendet CustomerMaster Query Anfragen, aufgeteilt auf 4 Szenarien.
  * Die Szenarien haben verschieden große Anfrage(n)/Antwort(en) ans Backend und ihr prozentualer Anteil entspricht dem einer durchschnittlichen Stunde 9.
  * Der Test startet mit der Durchschnittslast 2 rps und erhoeht diese dann kontinuierlich,
  * bis der Multiplizierer erreicht ist.
  *
  */
class DwpCstmrmstrQryDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)

  // Gesamte Dauer des Tests in Minuten
  val durationPhase: Int = 60 // min. 20

  var rps = 2f

  // Szenario 1 - 1 Anfrage - 1 Antwort - 75% aller Anfragen
  val rpsRequest1Response1: Float = rps * 0.73f

  // Szenario 2 - 11 Anfragen - 11 Antworten - 20% aller Anfragen
  var rpsRequest11Response11: Float = rps * 0.2f

  // Szenario 3 - 20 Anfragen - 20 Antworten - 6% aller Anfragen
  val rpsRequest20Response20: Float = rps * 0.06f

  // Szenario 4 - 2 Anfragen - 2 Antworten - 1% aller Anfragen
  val rpsRequest2Response2: Float = rps * 0.01f

  // Multiplizierer verändert die Last entsprechend des Verhältnises. 1 = Standard rps
  val rpsMultiplier: Float = 4.5f // Standard: 1 , Baseline: 1.5, Fakto 3 Baseline: 4.5

  val request1Response1 = new WpioScenario("Request 1 - Response 1", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.CSTMRMSTR_QRY", filePrefix+"DWP.CSTMRMSTR_QRY/1_1/20210706T085421.556-S-C1-100001.audit", "<CustomerMasterDetailResponse_1")

  val request11Response11 = new WpioScenario("Request 11 - Response 11", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.CSTMRMSTR_QRY", filePrefix+"DWP.CSTMRMSTR_QRY/11_11/20210706T132417.398-S-C1-100001.audit", "<CustomerMasterDetailResponse_1")

  val request20Response20 = new WpioScenario("Request 20 - Response 20", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.CSTMRMSTR_QRY", filePrefix+"DWP.CSTMRMSTR_QRY/20_20/20210707T104451.431-S-C1-100001.audit", "<CustomerMasterDetailResponse_1")

  val request2Response2 = new WpioScenario("Request 2 - Response 2", "SAN.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.12.LOAD",
    "DWP.CSTMRMSTR_QRY", filePrefix+"DWP.CSTMRMSTR_QRY/2_2/20210622T150101.068-S-C1-100001.audit", "<CustomerMasterDetailResponse_1")

  setUp(

    request1Response1.get.inject(
      rampUsersPerSec(rpsRequest1Response1) to rpsRequest1Response1 * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

    request11Response11.get.inject(
      rampUsersPerSec(rpsRequest11Response11) to rpsRequest11Response11 * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

    request20Response20.get.inject(
      rampUsersPerSec(rpsRequest20Response20) to rpsRequest20Response20 * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

    request2Response2.get.inject(
      rampUsersPerSec(rpsRequest2Response2) to rpsRequest2Response2 * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

  )
}



package de.dwpbank.wpio.loadtest.simulation.df

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef.{constantUsersPerSec, _}
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

class BackendStress extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)

  val order = new WpioScenario("Order", "WPI.ORDER.W778.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "WP2.ORDER", filePrefix+"DKB_DWP.BESTEX/20200507T131611.129-S-C1-100001.audit", "OIU2000")

  val deposit = new WpioScenario("Deposit", "WPI.ORDER.W778.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "WP2.DEPOSIT", filePrefix+"DKB_DWP.BESTEX/20200507T131611.129-S-C1-100001.audit", "DPU1021")

  val orderbook = new WpioScenario("Orderbook", "WPI.ORDER_ABFRAGEN.W778.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "WP2.ORDERBOOK", filePrefix+"DKB_DWP.BESTEX/20200507T131611.129-S-C1-100001.audit", "W779000")

  val esb = new WpioScenario("ESB", "WPI.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
   "ESB.OSPN_WPIO", filePrefix+"DKB_DWP.BESTEX/20200507T131611.129-S-C1-100001.audit", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><env:envelope xmlns:env=\"http://wp2d.dwpbank.de/esb/common/v1\" xmlns:ns2=\"http://eap.dwpbank.de/services/KV/GetCorporateActions/v1/m8\">")

  val bestex = new WpioScenario("BestEx", "WPI.SONSTIGES.W778.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
    "WP2.BESTEX", filePrefix+"DKB_DWP.BESTEX/20200507T131611.129-S-C1-100001.audit", "OIU1105")

  val sonstiges2 = new WpioScenario("Instrmdtls", "WPI.ORDER_ABFRAGEN.W778.LOAD", "DWP.RESPONSE_LOCAL.06.LOAD",
    "WP2.INSTRMDTLS", filePrefix+"DKB_DWP.BESTEX/20200507T131611.129-S-C1-100001.audit", "MSZ0021")

  val sonstiges3 = new WpioScenario("OSU0013", "WPI.ORDER_ABFRAGEN.W778.LOAD", "DWP.RESPONSE_LOCAL.07.LOAD",
    "WP2.OSU0013", filePrefix+"DKB_DWP.BESTEX/20200507T131611.129-S-C1-100001.audit", "OSU0013")

  val stammd = new WpioScenario("STU1075", "WPI.STAMMD.W778.LOAD", "DWP.RESPONSE_LOCAL.08.LOAD",
    "WP2.STU1075", filePrefix+"DKB_DWP.BESTEX/20200507T131611.129-S-C1-100001.audit", "STU1075")

  setUp(
    order.get.inject(
      atOnceUsers(10),
      rampUsers(300) during (10 seconds),
      constantUsersPerSec(300) during (10 seconds),
      // NOW: Full steam ahead!
      rampUsersPerSec(300) to 5000 during (40 seconds),
    ).protocols(jmsConfigNonPersistent),
    deposit.get.inject(
      constantUsersPerSec(20) during (60 seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    orderbook.get.inject(
      constantUsersPerSec(20) during (20 seconds) randomized,
      // NOW: Full steam ahead!
      rampUsersPerSec(300) to 2000 during (40 seconds)
    ).protocols(jmsConfigNonPersistent),
    esb.get.inject(
      constantUsersPerSec(5) during (60 seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    bestex.get.inject(
      constantUsersPerSec(8) during (15 seconds),
      // NOW: Full steam ahead!
      rampUsersPerSec(10) to 4000 during (45 seconds),
    ).protocols(jmsConfigNonPersistent),
    sonstiges2.get.inject(
      constantUsersPerSec(10) during (60 seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    sonstiges3.get.inject(
      constantUsersPerSec(10) during (60 seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
    stammd.get.inject(
      constantUsersPerSec(5) during (60 seconds) randomized,
    ).protocols(jmsConfigNonPersistent),
  )
}


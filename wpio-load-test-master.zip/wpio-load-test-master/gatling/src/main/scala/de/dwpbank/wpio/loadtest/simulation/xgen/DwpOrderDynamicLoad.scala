package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * This load test simulation is made for testing the DWP.ORDER XGEN service.
 * It is based on production load deviation at 9am.
 * The majority of the requests comes from 1 large and 2 statistically significant clients.
 * The rest are aggregated to a "remaining" client for testing purposes.
 */
class DwpOrderDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  // Gesamte Dauer des Tests in Minuten
  val durationPhase: Int = 60 // min. 20

  // on prod sum 18845 order related requests on a busy hour
  var rps = 22190 / 60 / 60

  // rps per client
  val fid_dzRps: Float = rps * 0.53f
  val dz_dzRps: Float = rps * 0.14f
  val dkbRps: Float = rps * 0.19f
  val sonstigeRps: Float = rps * 0.14f

  // Multiplizierer verändert die Last entsprechend des Verhältnises. 1 = Standard rps
  val rpsMultiplier: Float = 4.5f // Standard: 1 , Baseline: 1.5, Fakto 3 Baseline: 4.5
  val fid_dz = new WpioScenario("Fiducia DZ", "FIDUCIA_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DZ.ORDER_ERF.01_14", filePrefix+"DWP.ORDER/FID_DZ/20211009T224805.753-S-C1-100001.audit", "<dz:OrderErfassungResponse")
  val dz_dz = new WpioScenario("DZ DZ", "DZ_DZ.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DZ.XPASS_DEALS.02_00", filePrefix+"DWP.ORDER/DZ_DZ/20211008T184516.335-S-C1-100001.audit", "<OrderResponse_1")
  val dkb = new WpioScenario("DKB", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.ORDER", filePrefix+"DWP.ORDER/DKB_Sonstige/20211008T083315.570-S-C1-100001.audit", "<OrderResponse_1")
  val sonstige = new WpioScenario("Sonstige", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.ORDER", filePrefix+"DWP.ORDER/DKB_Sonstige/20211008T083315.570-S-C1-100001.audit", "<OrderResponse_1")

  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  setUp(

    fid_dz.get.inject(
      rampUsersPerSec(fid_dzRps) to fid_dzRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigPersistent),

    dz_dz.get.inject(
      rampUsersPerSec(dz_dzRps) to dz_dzRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigPersistent),

    dkb.get.inject(
      rampUsersPerSec(dkbRps) to dkbRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigPersistent),

    sonstige.get.inject(
      rampUsersPerSec(sonstigeRps) to sonstigeRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigPersistent),

  )
}



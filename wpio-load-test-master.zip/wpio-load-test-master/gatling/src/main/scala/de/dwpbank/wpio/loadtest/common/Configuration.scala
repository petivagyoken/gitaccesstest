package de.dwpbank.wpio.loadtest.common

object Configuration {

  def getStringConfig(name: String, default: String): String = {
    val value = System.getProperty(name, System.getenv(name))
    value match {
      case s: String => s
      case _ => default
    }
  }

  def getIntConfig(name: String, default: Int): Int = {
    val envDefault = System.getenv(name)
    val overlaidDefault = envDefault match {
      case s: String => s.toInt
      case _ => default
    }
    Integer.getInteger(name, overlaidDefault)
  }

}
package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

/**
  * Dieser Test sendet Deposit Anfragen von 10 versch. Client IDs in einer gewissen Verteilung,
  * die einer durchschnittlichen Stunde um 9 Uhr aehneln soll. Pro Client ID wird unterschieden in
  * Szenarien, bei denen die Antwortnachrichten des Backends variieren. Diese Szenarien
  * werden ebenfalls noch einmal prozentual verteilt (wenige grosse Antworten, viele kleine).
  *
  * Der Test startet mit der Durchschnittslast 5,9 rps und erhoeht diese dann kontinuierlich,
  * bis der Multiplizierer erreicht ist.
  *
  */
class DwpDepositDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent(environment)

  // Gesamte Dauer des Tests in Minuten
  val durationPhase: Int = 60

  // on prod sum 254447 requests on a busy hour on 12 nodes
  var rps = 254447 / 12f / 60f / 60f

  // new
  val dkbRps: Float = rps * 0.48f
  val fidDZRps: Float = rps * 0.40f
  val sonstigeRps: Float = rps * 0.12f



  // Multiplier to adjust total load according to set ratios. Set to 1 to keep original rps
  val rpsMultiplier: Float = 5f

  /** Sonstige **/
  val sonstige_1 = new WpioScenario("Sonstige - 1 response", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.DEPOSIT", filePrefix+"DWP.DEPOSIT/1_Teilnachricht/20210319T091457.563-S-C1-100001.audit", "<DepositResponse_1")
  val sonstige_2 = new WpioScenario("Sonstige - 2 response", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
    "DWP.DEPOSIT", filePrefix+"DWP.DEPOSIT/2_Teilnachrichten/20210319T092952.777-S-C1-100001.audit", "<DepositResponse_1")

  /** DKB **/
  val dkb_1 = new WpioScenario("DKB - 1 response", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
    "DWP.DEPOSIT", filePrefix+"DWP.DEPOSIT/1_Teilnachricht/20210319T091457.563-S-C1-100001.audit", "<DepositResponse_1")
  val dkb_2 = new WpioScenario("DKB - 2 response", "DKB.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
    "DWP.DEPOSIT", filePrefix+"DWP.DEPOSIT/2_Teilnachrichten/20210319T092952.777-S-C1-100001.audit", "<DepositResponse_1")



  /** FID_DZ **/
  // Uses SYDBANK_BV.REQUEST.DWP.LOAD connector, because DWP.DEPOSIT is not allowed
  val fi_dz = new WpioScenario("FID_DZ - 1 response", "SYDBANK_BV.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
    "DWP.DEPOSIT", filePrefix+"DWP.DEPOSIT/1_Teilnachricht/20210319T091457.563-S-C1-100001.audit", "<DepositResponse_1")


  setUp(

    sonstige_1.get.inject(
      rampUsersPerSec(sonstigeRps /2f) to (sonstigeRps /2f) * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

    sonstige_2.get.inject(
      rampUsersPerSec(sonstigeRps /2f) to (sonstigeRps /2f) * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

    dkb_1.get.inject(
      rampUsersPerSec(dkbRps /2f) to (dkbRps /2f)* rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

    dkb_2.get.inject(
      rampUsersPerSec(dkbRps /2f) to (dkbRps /2f) * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent),

    fi_dz.get.inject(
      rampUsersPerSec(fidDZRps) to fidDZRps * rpsMultiplier during (durationPhase minutes),
    ).protocols(jmsConfigNonPersistent)


  )
}



package de.dwpbank.esb.loadtest.simulation.derby

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

class DerbyConstantLoad extends Simulation {

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent()
  private val jmsConfigPersistent = createjmsConnectionPersistent()

  val testDuration = 30 // minutes

  val constantUsers = 3

  val dwpberechtigung = new WpioScenario("ESB DerbyDB - dwpberechtigung", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
      "DWPESB", "esb-derby/dwpberechtigung-request.xml", "dwpberechtigung")

  val getCorporateActions = new WpioScenario("ESB DerbyDB - GetCorporateActions", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.02.LOAD",
      "DWPESB", "esb-derby/GetCorporateActions-request.xml", "env:targetService")

  val oSPNeoDetail = new WpioScenario("ESB DerbyDB - OSPNeoDetail", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.03.LOAD",
      "DWPESB", "esb-derby/OSPNeoDetail-request.xml", "OSPNeoDetail")

  val readModelSelect = new WpioScenario("ESB DerbyDB - ReadModelSelect", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.04.LOAD",
      "DWPESB", "esb-derby/ReadModelSelect-request.xml", "ReadModelSelect")

  val exAnteSrv = new WpioScenario("ESB DerbyDB - ExAnteSrv", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.05.LOAD",
      "DWPESB", "esb-derby/OA_ExAnteSrv_L1Req_AuditentryID_16437765.xml", "ExAnteSrv")

  val priipCheck = new WpioScenario("ESB DerbyDB - PriipCheck", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.06.LOAD",
      "DWPESB", "esb-derby/GT_PriipCheck_L1Req__AuditentryID_16437780.xml", "PriipCheck")

  val depBestUebergr = new WpioScenario("ESB DerbyDB - DepBestUebergr", "TESTCL.REQ.ESB.LOAD", "DWP.RESPONSE_LOCAL.07.LOAD",
      "DWPESB", "esb-derby/DP_DepBestUebergr_L1Req_AuditentryID_16438321.xml", "DepotBestand_uebergreifend")

  setUp(
    dwpberechtigung.get.inject(constantUsersPerSec(constantUsers) during (testDuration minutes)),
    oSPNeoDetail.get.inject(constantUsersPerSec(constantUsers) during (testDuration minutes)),
    readModelSelect.get.inject(constantUsersPerSec(constantUsers) during (testDuration minutes)),
    exAnteSrv.get.inject(constantUsersPerSec(constantUsers) during (testDuration minutes)),
    priipCheck.get.inject(constantUsersPerSec(constantUsers) during (testDuration minutes)),
    depBestUebergr.get.inject(constantUsersPerSec(constantUsers) during (testDuration minutes))
  ).protocols(jmsConfigPersistent)

}

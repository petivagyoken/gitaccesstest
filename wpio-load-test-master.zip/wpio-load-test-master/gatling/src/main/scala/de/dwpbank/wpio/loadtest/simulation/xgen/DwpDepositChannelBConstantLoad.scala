package de.dwpbank.wpio.loadtest.simulation.xgen

import de.dwpbank.wpio.loadtest.common.JmsMqConfiguration._
import de.dwpbank.wpio.loadtest.common.WpioScenario
import io.gatling.core.Predef._
import io.gatling.jms.Predef._
import scala.language.postfixOps
import scala.concurrent.duration._

class DwpDepositChannelBConstantLoad extends Simulation {

  val durationPhase: Int = 10
  var rps = 254447 / 17f / 60f / 60f

  private val jmsConfigNonPersistent = createjmsConnectionNonPersistent()
  private val jmsConfigPersistent = createjmsConnectionPersistent()

  val FIDeposit = new WpioScenario("FI Deposit", "1822DIR.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
    "DWP.DEPOSIT", "FI_DWP.DEPOSIT_multi_response_2_msgs_v2/20230719T050817.847-S-B2-1.xml", "<DepositResponse_2")

  setUp(
    FIDeposit.get.inject(
      constantUsersPerSec(rps) during (durationPhase minutes)
    ).protocols(jmsConfigNonPersistent.build)
  )
}


package de.dwpbank.wpio.loadtest.simulation.audit

import java.time.Duration

import de.dwpbank.wpio.loadtest.common.JmsMqConfigurationRfH2._
import de.dwpbank.wpio.loadtest.common.WpioTemplateScenario
import io.gatling.core.Predef.Simulation
import io.gatling.javaapi.core.CoreDsl._
import io.gatling.jms.Predef._

class AuditIdxDynamicLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)


  var header: Array[String] = Array[String](
    "Usr_Indexing_FIELDLIST",
    "ParentDetails_AuditId",
    "ParentDetails_AccessId",
    "ParentDetails_ClientId",
    "AuditDetails_AuditTp",
    "AuditDetails_AuditSts",
    "AuditDetails_AuditTS",
    "AuditDetails_LogData",
    "AuditDetails_DataFormat",
    "AuditDetails_NewPropertyStyle",
    "ServiceDetails_ServiceId",
    "ServiceDetails_ServiceTp",
    "ServiceDetails_Input",
    "ServiceDetails_Output",
    "LogPoint_MsgTp",
    "LogPoint_Direction",
    "JMS_IBM_Character_Set",
    "JMS_IBM_MQMD_ReplyToQ",
    "Usr_Indexing_FIELDLIST_MD10",
    "Usr_JMS_IBM_MQMD_ReplyToQMgr",
    "Usr_Indexing_FIELDLIST_MD5",
    "USR_JMS_IBM_MQMD_REPLY_TO_QMGR"
  )

  val depositDegussa = new WpioTemplateScenario("Deposit - Degussa", filePrefix+"audit-idx/audit-idx_degussa-deposit.json", header)

  val depositDkb = new WpioTemplateScenario("Deposit - DKB", filePrefix+"audit-idx/audit-idx_dkb-deposit.json", header)

  val orderBookDkb = new WpioTemplateScenario("Orderbook - DKB", filePrefix+"audit-idx/audit-idx_dkb-orderbook.json", header)

  val orderBookDegussa = new WpioTemplateScenario("Orderbook - Degussa", filePrefix+"audit-idx/audit-idx_degussa-orderbook.json", header)

  val orderInsertDkb = new WpioTemplateScenario("Order Insert - DKB", filePrefix+"audit-idx/audit-idx_dkb-order-insert.json", header)

  val orderInsertDegussa = new WpioTemplateScenario("Order Insert - Degussa", filePrefix+"audit-idx/audit-idx_degussa-order-insert.json", header)

  val cstmrmstrQry = new WpioTemplateScenario("Cstmrmstr Qry - DZ", filePrefix+"audit-idx/audit-idx_dz-cstmrmstr-qry.json", header)


  private val incUsers = 5

  private val times = 7

  private val levelLast = Duration.ofMinutes(2)

  private val ramps = Duration.ofMinutes(3)

  private val startFrom = 5


  setUp(
    depositDegussa.get().injectOpen( incrementUsersPerSec(incUsers).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(startFrom) ).asScala().protocols(jmsConfigPersistent),
    depositDkb.get().injectOpen( incrementUsersPerSec(incUsers).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(startFrom) ).asScala().protocols(jmsConfigPersistent),
    orderBookDkb.get().injectOpen( incrementUsersPerSec(incUsers).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(startFrom) ).asScala().protocols(jmsConfigPersistent),
    orderBookDegussa.get().injectOpen( incrementUsersPerSec(incUsers).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(startFrom) ).asScala().protocols(jmsConfigPersistent),
    orderInsertDkb.get().injectOpen( incrementUsersPerSec(incUsers).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(startFrom) ).asScala().protocols(jmsConfigPersistent),
    orderInsertDegussa.get().injectOpen( incrementUsersPerSec(incUsers).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(startFrom) ).asScala().protocols(jmsConfigPersistent),
    cstmrmstrQry.get().injectOpen( incrementUsersPerSec(incUsers).times(times).eachLevelLasting(levelLast).separatedByRampsLasting(ramps).startingFrom(startFrom) ).asScala().protocols(jmsConfigPersistent),
  )
}

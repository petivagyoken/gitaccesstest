package de.dwpbank.wpio.loadtest.simulation.ws

import de.dwpbank.wpio.loadtest.common.SoapConfiguration
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder
import io.gatling.http.request.builder.HttpRequestBuilder
import scala.language.postfixOps
import scala.concurrent.duration._

/**
 * ErrorResponse Memory leak simulation.
 *
 */
class SoapAdapterErrorResponse extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  val request: HttpRequestBuilder = http("Sparplan")
    .post("/soap/fi/load")
    .body(
      ElFileBody(filePrefix+"jcf-ws/Soap-envelope-test-message.xml")).asXml
    .header("Accept", "application/xml")
    .check(
      status.is(500)
    )

  setUp(
    scenario("WS.ERROR")
      .exec(request)
      .inject(
        constantUsersPerSec(2) during (3006 seconds)
      ).protocols(SoapConfiguration.httpProtocol(environment))
  ).assertions(
    global.responseTime.percentile4.lt(300),
    global.successfulRequests.percent.gt(99)
  )

}


package de.dwpbank.wpio.loadtest.simulation.audit

import de.dwpbank.wpio.loadtest.common.JmsMqConfigurationRfH2._
import de.dwpbank.wpio.loadtest.common.WpioTemplateScenario
import io.gatling.core.Predef.{Simulation}
import io.gatling.javaapi.core.CoreDsl._
import io.gatling.jms.Predef._

import java.time.Duration

class AuditConstantLoad extends Simulation {
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
    filePrefix = "../testdata/"
  }

  private val jmsConfigPersistent = createjmsConnectionPersistent(environment)

  var header: Array[String] = Array[String](
    "Usr_JMS_IBM_MQMD_ReplyToQMgr",
    "Usr_JMS_IBM_MQMD_CodedCharSetId",
    "JMS_IBM_MQMD_CodedCharSetId",
    "Usr_Indexing_FIELDLIST",
    "Usr_Indexing_FIELDLIST_MD5",
    "ErrorDetails_Code",
    "Conversion_InputCp",
    "Conversion_OutputCp",
    "MsgIds_ParentId",
    "MsgIds_RequestId",
    "MsgIds_ChildId",
    "LogPoint_BorderId",
    "LogPoint_Direction",
    "LogPoint_MsgTp",
    "ParentDetails_AuditId",
    "ParentDetails_AccessId",
    "ParentDetails_ClientId",
    "AuditDetails_AuditTp",
    "AuditDetails_AuditSts",
    "AuditDetails_AuditTS",
    "AuditDetails_LogData",
    "AuditDetails_DataFormat",
    "AuditDetails_Start",
    "AuditDetails_NewPropertyStyle",
    "ServiceDetails_ServiceId",
    "ServiceDetails_ServiceTp",
    "ServiceDetails_Input",
    "ServiceDetails_Output",
    "ServiceDetails_SlaEnabled",
    "ServiceDetails_ClientId",
    "ServiceDetails_InputServiceId",
    "ServiceDetails_SeqNo",
    "JMSMessageID"
  )

  val depositRR = new WpioTemplateScenario("Deposit RR", filePrefix+"audit/deposit.json", header)
  val orderbookRR = new WpioTemplateScenario("Orderbook RR", filePrefix+"audit/orderbook.json", header)
  val orderRR = new WpioTemplateScenario("Order RR", filePrefix+"audit/order.json", header)

  val orderbookAD = new WpioTemplateScenario("Orderbook AD", filePrefix+"audit/orderbook-ad.json", header)

  private val constantUsers = 60

  private val constantUsersRR = constantUsers * 0.7
  private val constantUsersAD = constantUsers * 0.3

  private val testDuration = Duration.ofMinutes(30)

  private val depositRate = 0.4;
  private val orderRate = 0.3;
  private val orderBookRate = 0.3;

  private val depositConstantUsersRR = constantUsersRR * depositRate;
  private val orderBookConstantUsersRR = constantUsersRR * orderBookRate;
  private val orderConstantUsersRR = constantUsersRR * orderRate;

  private val orderBookConstantUsersAD = constantUsersAD;

  setUp(
    depositRR.get().injectOpen( constantUsersPerSec(depositConstantUsersRR).during(testDuration) ).asScala().protocols(jmsConfigPersistent) ,
    orderRR.get().injectOpen( constantUsersPerSec(orderConstantUsersRR).during(testDuration) ).asScala().protocols(jmsConfigPersistent) ,
    orderbookRR.get().injectOpen(constantUsersPerSec(orderBookConstantUsersRR).during(testDuration)).asScala().protocols(jmsConfigPersistent) ,
    orderbookAD.get().injectOpen(constantUsersPerSec(orderBookConstantUsersAD).during(testDuration)).asScala().protocols(jmsConfigPersistent)
  )
}

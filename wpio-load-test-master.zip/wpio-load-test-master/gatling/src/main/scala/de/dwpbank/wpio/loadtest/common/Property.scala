package de.dwpbank.wpio.loadtest.common

import ujson.Value
import scala.io.Source

/**
 * Provides a getter for JSON property data.
 */
object Property {

  /**
   * Gets the JSON object with functional properties in order to specify the workload in simulations.
   * @return LinkedHashMap which is already navigated to the relevant level.
   */
  def getExtraSystemProperties(propertyFile: String): Value.Value  = {
    // Has to be set a system property when starting a simulation
   // val propertyFile = System.getProperty("propertyFile")

    // Read file content and return as a String
    val fileStream = getClass.getResourceAsStream(s"/simulationProperties/$propertyFile")
    val jsonString = Source.fromInputStream(fileStream).mkString

    // Used for debugging
    // System.out.println(jsonString)

    // Using uPickle, a simple, fast, dependency-free JSON library for Scala
    // https://mvnrepository.com/artifact/com.lihaoyi/upickle
    // Read JSON data into a LinkedHashMap
    // Example: https://mungingdata.com/scala/read-write-json/
    val jsonData = ujson.read(jsonString)

    // Read top level structure and navigate to the level with extraSystemProperties
    val extraSystemProperties = jsonData("extraSystemProperties")

    // Create LinkedHashMap pointing to functional properties
    val simulationProperties = ujson.read(extraSystemProperties)

    simulationProperties
  }

}
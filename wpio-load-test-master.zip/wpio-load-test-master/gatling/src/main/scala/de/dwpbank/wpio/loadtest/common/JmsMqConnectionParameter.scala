package de.dwpbank.wpio.loadtest.common

import de.dwpbank.wpio.loadtest.common.Configuration.{getIntConfig, getStringConfig}



/**
 * To store the relevant connection-parameters for a JMS-Connection.
 * Single parameters could also be passed as System-property
 *
 * @param hostNameDef
 * @param hostPortDef
 * @param channelNameDef
 * @param queueManagerNameDef
 * @param listenerThreadCountDef
 * @param replyTimeoutMsecsDef
 */
class JmsMqConnectionParameter(hostNameDef: String,
                               hostPortDef: Int,
                               channelNameDef: String,
                               queueManagerNameDef: String,
                               listenerThreadCountDef: Int,
                               replyTimeoutMsecsDef: Int)
  {
    /**
     * Get Hostname from system.property "MQ_QM_HOSTNAME" or use the passed default hostNameDef
     * @return the hostname
     */
    def getHostName = getStringConfig("MQ_QM_HOSTNAME", hostNameDef)

    /**
     * Get Hostport from system.property "MQ_QM_PORT" or use the passed default hostPortDef
     * @return the hostport
     */
    def getHostPort = getIntConfig("MQ_QM_PORT", hostPortDef)

    /**
     * Get Channelname from system.property "MQ_QM_CHANNEL" or use the passed default channelNameDef
     * @return the channelname
     */
    def getChannelName = getStringConfig("MQ_QM_CHANNEL", channelNameDef)

    /**
     * Get QueueManagerName from system.property "MQ_QM_NAME" or use the passed default queueManagerNameDef
     * @return the queuemanagername
     */
    def getQueueManagerName = getStringConfig("MQ_QM_NAME", queueManagerNameDef)

    /**
     * Get ListenerThreadCount from system.property "LISTENER_THREAD_COUNT" or use the passed default listenerThreadCountDef
     * @return the Listener-thread-count
     */
    def getListenerThreadCount = getIntConfig("LISTENER_THREAD_COUNT", listenerThreadCountDef)

    /**
     * Get ReplyTimeoutMilliseconds from system.property "REPLY_TIMEOUT_MSECS" or use the passed default replyTimeoutMsecsDef
     * @return the hostport
     */
    def getReplyTimeoutMsecs = getIntConfig("REPLY_TIMEOUT_MSECS", replyTimeoutMsecsDef).toLong
}

package de.dwpbank.wpio.loadtest.common

/**
 * Factory that provides a map for (environment => JmsConnectionParamter) for each useable environment
 */

object JmsMqConnectionParameterFactory {
    val connectionParameters = Map(
      "" -> new JmsMqConnectionParameter(
        "localhost",
        1414,
        "DEV.APP.SVRCONN",
        "QM1",
        2,
        1000),
      "LOCAL" -> new JmsMqConnectionParameter(
        "localhost",
        1414,
        "DEV.APP.SVRCONN",
        "QM1",
        2,
        1000),
      "TESTLAB" -> new JmsMqConnectionParameter(
        "2.153.29.90",
        14141,
        "DEV.APP.SVRCONN",
        "QM1",
        2,
        10000),
    )

  /**
   * Fetches the JmsConnectionParameter for the passed environment
   * @param environment the relevant environment
   * @return Option for JmsMqConnectionParameter. None, if not found
   */
  def getJmsMqConnectionParameter(environment: String) : Option[JmsMqConnectionParameter] = {
    connectionParameters.get(environment.toUpperCase)
  }
}

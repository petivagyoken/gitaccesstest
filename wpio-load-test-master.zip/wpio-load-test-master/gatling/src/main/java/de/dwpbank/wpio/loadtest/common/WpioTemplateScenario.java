package de.dwpbank.wpio.loadtest.common;

import static io.gatling.javaapi.core.CoreDsl.exec;

import static io.gatling.javaapi.core.CoreDsl.scenario;
import static io.gatling.javaapi.jms.JmsDsl.jms;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Session;
import io.gatling.javaapi.jms.JmsRequestReplyActionBuilder;
import io.netty.util.internal.StringUtil;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.regex.Pattern;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.xml.bind.DatatypeConverter;


public class WpioTemplateScenario {

  private final String scenarioName;
  private final List<JsonDto> data;
  private final String[] whitelist;
  private final String testDataFileName;
  private List<String> headers;
  private SimpleDateFormat formatter;
  private final Date startDate;
  private Pattern auditIdPattern = Pattern.compile("\\#AUDIT_ID\\((\\d+)\\)?\\#");
  private Pattern messageIdPattern = Pattern.compile("\\#MESSAGE_ID\\(([A-Za-z0-9]+)\\)?\\#");
  private Pattern timstampPattern = Pattern.compile("\\#TIMESTAMP(\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*\\))?\\#");
  private int nodeNumbers[] = {1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19};


  public WpioTemplateScenario(String scenarioName, String testDataFileName, String[] whitelist) throws FileNotFoundException {
    this.scenarioName = scenarioName;
    this.whitelist = whitelist;
    this.testDataFileName = testDataFileName;
    this.data = getData();
    this.startDate = new Date();
    this.formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
    createHeaders();
  }

  private List<JsonDto> getData() throws FileNotFoundException {
    var gson = new Gson();
    var reader = new JsonReader(new FileReader(this.testDataFileName));
    Type listOfMyClassObject = new TypeToken<ArrayList<JsonDto>>() {
    }.getType();
    return gson.fromJson(reader, listOfMyClassObject);
  }

  public ScenarioBuilder get() throws FileNotFoundException {
    return scenario(scenarioName)
        .exec(session -> {
          var list = Arrays.stream(nodeNumbers).boxed().collect(Collectors.toList());
          Collections.shuffle(list);
          var randomNumber = String.valueOf(list.get(0));
          return session.set("random", randomNumber);
        })
        .foreach(getData(), "item", "index").on(
            exec(() -> {
              var j = jms(scenarioName)
                  .send()
                  .queue(session -> {
                    var queueName = ((JsonDto) session.get("item")).metadata.get("from").toString();
                    return template(session, queueName).toString();
                    //return ((JsonDto) session.get("item")).metadata.get("from").toString();
                   })
                  .textMessage(session -> ((JsonDto) session.get("item")).body);

              for (var key : headers) {
                j = j.property(key, session -> {
                  var data = (JsonDto) session.get("item");
                  return template(session, data.headers.get(key));
                });
              }

              return j.asScala();
            })
        );
  }

  public ScenarioBuilder getWithTracker(String trackedQueue) throws FileNotFoundException {
    return scenario(scenarioName)
            .exec(session -> {
              var list = Arrays.stream(nodeNumbers).boxed().collect(Collectors.toList());
              Collections.shuffle(list);
              var randomNumber = String.valueOf(list.get(0));
              return session.set("random", randomNumber);
            })
            .foreach(getData(), "item", "index").on(
                    exec(() -> {
                      JmsRequestReplyActionBuilder.Message messageBuilder = jms(scenarioName)
                              .requestReply()
                              .queue(session -> {
                                var queueName = ((JsonDto) session.get("item")).metadata.get("from").toString();
                                return template(session, queueName).toString();
                              });

                      AtomicBoolean hasReplyQueue = new AtomicBoolean(false);

                      messageBuilder = messageBuilder.replyQueue(session -> {
                        var replyQueueName = ((JsonDto) session.get("item")).headers.get("JMS_IBM_MQMD_ReplyToQ").toString().trim();
                        if (StringUtil.isNullOrEmpty(replyQueueName)) {
                          return "DWP.RESPONSE_LOCAL.LOAD";
                        } else {
                          hasReplyQueue.set(true);
                          return template(session, replyQueueName).toString();
                        }
                      });

                      if (!hasReplyQueue.get()) {
                        messageBuilder = messageBuilder.noJmsReplyTo();
                      }

                      var j = messageBuilder
                              .trackerQueue(trackedQueue)
                              .textMessage(session -> ((JsonDto) session.get("item")).body);
                      for (var key : headers) {
                        j = j.property(key, session -> {
                          var data = (JsonDto) session.get("item");
                          return template(session, data.headers.get(key));
                        });
                      }

                      return j.asScala();
                    })
            );
  }

  private Object template(Session session, Object value) {
    if (value instanceof String) {
      value = ((String) value).replace("#USER_ID#", String.valueOf(session.userId()));
      value = ((String) value).replace("#INDEX#", session.getString("index"));

      var auditIdMatcher = auditIdPattern.matcher((String) value);
      value = auditIdMatcher.replaceAll(matchResult -> getAuditId(matchResult.group(1), session));

      var messageIdMatcher = messageIdPattern.matcher((String) value);
      value = messageIdMatcher.replaceAll(matchResult -> getMessageId(matchResult.group(1), session));

      var timestampMatcher = timstampPattern.matcher((String) value);
      value = timestampMatcher.replaceAll(matchResult -> {
        Long increaseEverySeconds = null;
        Long increaseValue = null;
        if (matchResult.groupCount() == 3) {
          increaseEverySeconds = Long.valueOf(matchResult.group(2));
          increaseValue = Long.valueOf(matchResult.group(3));
        }
        return getTimestamp(increaseEverySeconds, increaseValue);
      });

      value = ((String) value).replace("#RANDOM_SERVER_NUMBER#", session.getString("random"));
      value = ((String) value).replace("#RANDOM_NODE_NAME#", getRandomNodeName(session.getInt("random")));
    } else if (value instanceof Double) {
      value = ((Double) value).intValue();
    }

    return value;
  }

  private String getMessageId(String messageId, Session session){
    var userId = String.valueOf(session.userId());
    var genMessageId = String.format("%s%s", messageId.substring(0, messageId.length() - userId.length()), userId);
    //System.out.println("Message ID: " + genMessageId);
    var getMessageIdWIthUserAndRandom = genMessageId + userId + session.getString("random");
    String hashedMessageId = "";
	try{
    MessageDigest md = MessageDigest.getInstance("MD5");
    md.update(getMessageIdWIthUserAndRandom.getBytes());
    byte[] digest = md.digest();
    hashedMessageId = DatatypeConverter
      .printHexBinary(digest).toUpperCase();
	} catch (NoSuchAlgorithmException e) {
	  System.out.println("NoSuchAlgorithmException "+e);
	  return genMessageId;
	}
    return hashedMessageId;
  }

  private String getAuditId(String prefix, Session session) {
    var counter = String.format("%s", prefix);
    var l = (10 - counter.length() - prefix.length());
    var auditId = String.format("%s", prefix);
    for(var i = 0; i < l; i++) {
      auditId = String.format("%s%d", auditId, 0);
    }
    auditId = String.format("%s%d", auditId, session.userId());
    //System.out.println("Audit ID: " + auditId);
    return auditId;
  }

  private String getTimestamp(Long increaseEverySeconds, Long increaseValueForSeconds) {
    var now = new Date();
    if (increaseEverySeconds != null && increaseValueForSeconds != null) {
      applyTimestampIncrease(now, increaseEverySeconds, increaseValueForSeconds);
    }
    return formatter.format(new Date(now.getTime()));
  }

  private void applyTimestampIncrease(Date now, Long increaseEverySeconds, Long increaseValueForSeconds) {
    var diff = (now.getTime() - startDate.getTime()) / 1000;
    if (diff > 0 && (diff % increaseEverySeconds) == 0) {
      var addMs =  (increaseValueForSeconds * (diff / increaseEverySeconds)) * 1000;
      now.setTime(now.getTime() + addMs);
    }
  }

  private String getRandomNodeName(int randomNode) {
    if (randomNode < 10) {
      return String.format("0%d", randomNode);
    }
    return String.format("%d", randomNode);
  }

  private void createHeaders() {
    headers = data.get(0).headers.keySet().stream().filter(h -> Arrays.asList(whitelist).contains(h)).collect(Collectors.toList());
  }
}

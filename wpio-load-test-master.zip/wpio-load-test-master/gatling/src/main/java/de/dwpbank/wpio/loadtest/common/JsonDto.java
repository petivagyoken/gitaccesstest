package de.dwpbank.wpio.loadtest.common;

import java.util.Map;


public class JsonDto {

    public Map<String, Object> headers;
    public String body;
    public Map<String, Object> metadata;
}

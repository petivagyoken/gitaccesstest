set application=rp
set simulationName=RpDerbyOnce

"F:\Programfiles\ojdkbuild\java-11-openjdk-11.0.10-1\bin\java" -Denvironment=TESTLAB -jar target/gatling-1.0-SNAPSHOT.jar -s de.dwpbank.wpio.loadtest.simulation.%application%.%simulationName% > output/%application%.%simulationName%_%DATE%.txt

pause
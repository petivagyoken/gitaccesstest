#!/bin/bash

trap 'break' SIGTERM
while true; do
  sleep 3;
done

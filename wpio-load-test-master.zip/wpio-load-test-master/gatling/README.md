# Gatling load test

## Local development

You can use the docker-compose setup `df` for development in the Development Factory (see ../docker-compose/README.md).
WMQ port `1414` is already exported in docker-compose setup `df`.

```shell
~ $ cd wpio-load-test
~/wpio-load-test $ sudo ./loadtest.sh ./docker-compose/df/dc-df.sh
...
Now you are entering the Gatling load driver container where you can start the tests...
Leave it by typing "exit".
root@ff2ea0364a70:/gatling# ./startSimulation.sh de.dwpbank.wpio.loadtest.rp.RpDerbyConstantLoad
```

The generated test report will be at `gatling/target/<simulationname>-<timestamp>/index.html`.

## Parameterization

Following Java System Properties or Env Variables can be configured (system properties take precedence over env variables):

| System Property       | Default Value     |
|-----------------------|-------------------|
| `MQ_QM_HOSTNAME`      | `localhost`       |
| `MQ_QM_PORT`          | `1414`            |
| `MQ_QM_CHANNEL`       | `DEV.APP.SVRCONN` |
| `MQ_QM_NAME`          | `QM1`             |
| `REPLY_TIMEOUT_MSECS` | `1000`            |

## Metrics

Metrics are exported to prometheus under the metric prefix `gatling_` by using `graphite-exporter` which is automatically
started in `docker-compose`.

## Naming conventions for load tests

New load tests should follow the naming conventions. All simulation files have to be located in subfolders of `gatling/src/main/scala/de/dwpbank/wpio/loadtest/simulation`

Depending on the type of the test, they are named like this:

* [testname]ConstantLoad
  * Tests which use constant load
* [testname]DynamicLoad
  * Tests which use dynamic load, i.e. simulating an typical load increase on a morning
* [testname]Stress
  * Tests which use massive load to test stress/overload behaviour of applications
* [testname]Soak
  * Tests running very long to check for potential memory leaks or other long running problems
  
## Available base scenarios

### WpioTemplateScenario

Inject MQ messages based on json template files, that may contain certain variables that get replaced during runtime (see template directives below). Initial template files can be created via message-exporter tool (have to be modified by hand before usage).
Below sample parses the content of file audit-idx_degussa-deposit.json. 
Values of the key header will be set as JMS and RFH2 messages headers. Header properties can be filtered by the whitelist class parameter.
Each JSON item will be sent for every injected gatling user. So if the JSON structure consists of two entries and four users are injected, the overall request count will be eight.

#### Extension with a trackerQueue for WpioTemplateScenario

Documentation: https://gatling.io/docs/gatling/reference/current/jms/#destination

Description: Measuring the time consumption the message has been arrived at the passed Queue.
Currently JMS has configured to match message based on CorrelationId (instead of messageId).

ReplyToQ will be read from JSON file (`JMS_IBM_MQMD_ReplyToQ` header value). If no reply Q is defined will use a default one (because if we do not define replyQ then gatling JMS will try to create a temporary one - without required roles...).
If you do not need replyQ then you can leave it empty (no JmsReplyTo header will be send) 

Note: Tracked Q can be same as replyQ, or it can differ for any application-related Q (for a service which is just forwarding messages)

Usage:
```scala
private val jmsConfigPersistent = createjmsConnectionPersistentCorrelationMatcher()

var header: Array[String] = Array[String]("...")

val deposit = new WpioTemplateScenario("DEPOSIT - TEST", "audit/orderbook-single.json", header)

//use getWithTracker with the Q you want to measure

setUp(
  deposit.getWithTracker("WPI.AUDIT_INDEX.LOAD").injectOpen(atOnceUsers(1)).asScala().protocols(jmsConfigPersistent.build)
)
```

### Integration with Gatling Enterprise

When a simulation is executed via Gatling Enterprise, the gatling JAR is copied in its own directory. Therefore, all relative paths to the test message are different compared to our container setup where the root test message directory is mounted as volume.

To deal with this problem, the test messages are also packaged as resource files during the maven build. The messages can be accessed in the simulations with the following snipped:

```java
  private val environment = Option(System.getProperty("environment")).getOrElse("LOCAL") // LOCAL or TESTLAB

  var filePrefix = ""
  if (environment == "LOCAL") {
  filePrefix = "../testdata/"
  }

  val degussaDeposit = new WpioScenario("Degussa Deposit", "DEGUSSA.REQUEST.DWP.LOAD", "DWP.RESPONSE_LOCAL.01.LOAD",
  "DWP.DEPOSIT", filePrefix+"Degussa_DWP.DEPOSIT_multi_response_2_msgs/20200408T125803.390-S-C1-100001.audit", "<DepositResponse_1")
```

#### Sample usage
```scala

var whitelist: Array[String] = Array[String](
  "Usr_Indexing_FIELDLIST",
  "ParentDetails_AuditId"
)

val deposit = new WpioTemplateScenario("Deposit", "audit-idx_degussa-deposit.json", whitelist)

setUp(
  deposit.get().injectOpen(atOnceUsers(4)).asScala().protocols(jmsConfigPersistent.build),
)
```


#### Available template directives

| Template Variable | Description|
|-------------------| ---------------------|
| `#TIMESTAMP#`     | Current imestamp with format yyyy-MM-dd HH:mm:ss.SSSSSS|
| `#TIMESTAMP(long increaseEverySeconds, long increaseValueForSeconds)#`     | Increase Timestamp every defined seconds with a static value, e.g #TIMESTAMP(60, 86400)# - add one day every minute. Format yyyy-MM-dd HH:mm:ss.SSSSSS|
| `#USER_ID#`       | Running number starting with 1 of current gatling user |
| `#INDEX#`         | JSON file record index, starting with 0|
| `#RANDOM_NUMBER#` | Random long|
| `#RANDOM_SERVER_NUMBER#` | Random server number out of range 01-19 (except 06)|
| `#AUDIT_ID(long prefix)#` | create ascending audit with given prefix|
| `#MESSAGE_ID(String messageId)#` | create unique message id from given message id|

#### JSON structure
Note an array structure is required.
```json
[
  {
    "headers": {
      "JMS_IBM_Character_Set": "UTF-8",
      "AuditDetails_AuditTS": "#TIMESTAMP#"
    },
    "body": "BODY for User #USER_ID# at #TIMESTAMP#",
    "metadata": {
      "from": "QUEUE_NAME"
    }
  }
]
```

### How to execute from cli
#### Single simulation
````shell
mvn gatling:test -Dgatling.simulationClass=de.dwpbank.wpio.loadtest.simulation.audit.AuditQryConstantLoad
````

### Start with git bash on Windows (Silberfisch)
- Establish ssh port forwarding from WPIO LuP machine to your local machine for MQ port 14141
- Start LuP on WPIO LuP machine
- Run Gatling simulation with below command(s)
````shell
export JAVA_HOME="C:\Program Files\Java-Dev\openjdk-11"
export MQ_QM_PORT=14141
mvn gatling:test -Dgatling.simulationClass=de.dwpbank.wpio.loadtest.simulation.rp.RpDerbyOnce
````



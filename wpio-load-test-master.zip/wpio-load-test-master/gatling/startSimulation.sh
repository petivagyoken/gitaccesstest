#!/bin/bash

if [ -z "$1" ]; then
  echo "Simulation package path (i.e. de.dwpbank.wpio.loadtest.simulation.SoapAdapterPeakConstantLoad) is missing!"
  echo -e "\nAvailable ESB simulations:"


  for file in $(find src/main/scala/de/dwpbank/esb/loadtest/simulation/ -name "*.scala"); do

      PACKAGECLASS="$(grep package $file).${file##*/}"
      PACKAGECLASS="${PACKAGECLASS/'package '/}"
      PACKAGECLASS="${PACKAGECLASS/'.scala'/}"
      echo "$PACKAGECLASS"

  done

  echo -e "\nAvailable WPIO simulations:"

  for file in $(find src/main/scala/de/dwpbank/wpio/loadtest/simulation/ -name "*.scala"); do

    PACKAGECLASS="$(grep package $file).${file##*/}"
    PACKAGECLASS="${PACKAGECLASS/'package '/}"
    PACKAGECLASS="${PACKAGECLASS/'.scala'/}"
    echo "$PACKAGECLASS"

  done
  exit
fi

SIMULATION=$1
# LOCAL or TESTLAB
ENVIRONMENT=$2

START="$(date +'%Y-%m-%d_%R')"
STARTTIMESTAMP="$(($(date +%s%N)/1000000))"

echo "START Running Gatling on $START"
source /gatling/environment.conf
# for further parameters see https://gatling.io/docs/current/general/configuration#command-line-options

if [ -z "$2" ]; then
  echo "Starting local execution ..."
  java -jar /usr/src/app/target/gatling-1.0-SNAPSHOT.jar --results-folder /reports/ --simulation $SIMULATION
else
  echo "Calling Gatling API in STTMG Testlab ..."
  curl -i -X POST -H "accept: application/json" -H "Authorization: pHSbRpRBau1xKVLGOXQAiXQNZjAz8GiEjJ_Adf1GccILOZu42-5iHXcEOkBdkcH5c" -H "Content-Type: application/json" -k https://gatlingfrontline.test.dwpbank.net/api/public/simulations/start?simulation="251f4633-bb33-46aa-8d40-f4d905f25cd6"
fi
echo "END Running Gatling on $(date)"

ENDTIMESTAMP="$(($(date +%s%N)/1000000))"

# Create and save PDF of Grafana Dashboard for this run
echo "Creating and saving PDF report of Grafana dashboard..."
curl -L --referer ";auto" -o /reports/grafana-dashboard-$START.pdf "http://grafana-reporter:8686/api/v5/report/lJaWhcCZks3?from=$STARTTIMESTAMP&to=$ENDTIMESTAMP&template=landscape"
echo "Report saved in report directory."
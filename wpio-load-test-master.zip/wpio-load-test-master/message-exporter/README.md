# Message exporter

Small test tool for exporting IBM MQ messages, including headers, to json files. 
Exported files can be used to create templates for testing native IBM MQ applications including MQRFH2 headers.

## How to use
- Configure MQ settings, queue(s) + message pattern(s) and export directory in application.properties
- Start source application(s) that injects messages to configured queue
- Run message-exporter to export message 
- Check files in defined export directory

### Run locally

Run locally 
```bash
cd ../app/
mvn spring-boot:run
```

### Start with git bash on Windows (Silberfisch)
- Establish ssh port forwarding from WPIO LuP machine to your local machine for MQ port 14141
- Start LuP on WPIO LuP machine
- Run Gatling simulation with below command(s)
```bash
cd app
export JAVA_HOME="C:\Program Files\Java-Dev\openjdk-11"
export IBM_MQ_CONNNAME="localhost(14141)"
```
```
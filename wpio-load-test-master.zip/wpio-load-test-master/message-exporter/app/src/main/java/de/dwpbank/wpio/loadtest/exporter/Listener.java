package de.dwpbank.wpio.loadtest.exporter;


import com.google.gson.Gson;
import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import lombok.extern.slf4j.Slf4j;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

@Slf4j
public class Listener implements MessageListener {

  private final RequestProperties requestProperties;
  private final TestDataProperties testDataProperties;
  private Pattern pattern;


  Listener(RequestProperties requestProperties, TestDataProperties testDataProperties) {
    this.requestProperties = requestProperties;
    this.testDataProperties = testDataProperties;
    this.pattern = Pattern.compile(requestProperties.getPattern());
  }


  @Override
  public void onMessage(Message message) {
      try {
        processIncomingMessage(message);
      } catch (Exception e) {
        e.printStackTrace();
      }
  }

  private void processIncomingMessage(final Message message) throws JMSException, IOException {

    String body;
    if (message instanceof BytesMessage) {
      BytesMessage byteMessage = (BytesMessage) message;
      byte[] byteData = null;
      byteData = new byte[(int) byteMessage.getBodyLength()];
      byteMessage.readBytes(byteData);
      byteMessage.reset();
      body  =  new String(byteData);
    } else {
      body = message.getBody(String.class);
    }

    // pattern matching
    if (pattern.matcher(body).find()) {

      // create dto from message
      JsonDto dto = new JsonDto();

      Map<String, Object> headers = new HashMap<>();
      Map<String, Object> metadata = new HashMap<>();
      dto.setBody(body);

      Enumeration<String> srcProperties = message.getPropertyNames();

      while (srcProperties.hasMoreElements()) {
        String propertyName = srcProperties.nextElement();
        headers.put(propertyName, message.getObjectProperty(propertyName));
      }

      metadata.put("from", requestProperties.getInputQueue());
      metadata.put("createdAt", System.nanoTime());

      dto.setHeaders(headers);
      dto.setMetadata(metadata);

      // write to file
      Gson gson = new Gson();
      Writer writer =
          new FileWriter(
              testDataProperties.getFolder()
                  + requestProperties.getInputQueue()
                  + "_"
                  + System.nanoTime()
                  + ".json");
      gson.toJson(dto, writer);
      writer.flush();
      writer.close();
    } else {
      log.info("Message not saved. Pattern mismatch.");
    }

  }
}

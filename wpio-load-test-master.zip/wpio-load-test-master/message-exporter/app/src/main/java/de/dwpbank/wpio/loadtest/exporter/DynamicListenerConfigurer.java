package de.dwpbank.wpio.loadtest.exporter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListenerConfigurer;
import org.springframework.jms.config.JmsListenerEndpointRegistrar;
import org.springframework.jms.config.SimpleJmsListenerEndpoint;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class DynamicListenerConfigurer implements JmsListenerConfigurer {

  @Autowired
  private TestDataProperties testDataProperties;

  @Value("${jms.concurrency:5-30}")
  private String jmsConcurreny;

  @Override
  public void configureJmsListeners(JmsListenerEndpointRegistrar registrar) {
    for (RequestProperties requestProperty : testDataProperties.getRequests().values()) {
      SimpleJmsListenerEndpoint endpoint = new SimpleJmsListenerEndpoint();
      endpoint.setConcurrency(jmsConcurreny);
      endpoint.setMessageListener(
          new Listener(requestProperty, testDataProperties));
      endpoint.setId(requestProperty.getInputQueue());
      endpoint.setDestination(requestProperty.getInputQueue());
      registrar.registerEndpoint(endpoint);
      log.info("Starting to consume queue {}...", requestProperty.getInputQueue());
    }
  }

}
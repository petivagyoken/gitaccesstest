package de.dwpbank.wpio.loadtest.exporter;

import lombok.Data;

import java.util.Map;

@Data
public class JsonDto {

    private Map<String, Object> headers;
    private String body;
    private Map<String, Object> metadata;
}

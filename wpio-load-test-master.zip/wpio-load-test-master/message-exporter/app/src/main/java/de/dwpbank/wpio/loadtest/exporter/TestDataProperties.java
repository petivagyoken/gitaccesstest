package de.dwpbank.wpio.loadtest.exporter;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Setter
@Getter
@ConfigurationProperties(prefix = "wpio.testdata")
@Configuration
public class TestDataProperties {

  private String folder;
  private Map<String, RequestProperties> requests;

}

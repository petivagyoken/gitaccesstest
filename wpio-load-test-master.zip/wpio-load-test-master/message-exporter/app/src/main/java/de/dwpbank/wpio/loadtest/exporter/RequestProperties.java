package de.dwpbank.wpio.loadtest.exporter;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class RequestProperties {

  private String inputQueue;
  private String pattern;
}

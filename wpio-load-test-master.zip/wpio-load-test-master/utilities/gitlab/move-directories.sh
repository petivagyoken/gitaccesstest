#!/bin/bash

SOURCE_REPO="https://gitlab.dwp.fits.cloud/wp3/bc/wpio/wpio-monitoring.git"
TARGET_REPO="https://gitlab.dwp.fits.cloud/wp3/bc/wpio-framework/wpio-framework-monitoring.git"
TARGET_PROJECT_ID="5132"
PRIVATE_TOKEN="XXX"
BRANCH_NAME="feature/migrate-alerts-grafana-runbooks"
TARGET_BRANCH="main"
DIRS=("alerts" "grafana-dashboards" "runbooks")
GITLAB_API_URL="https://gitlab.dwp.fits.cloud/api/v4"
WORKDIR="/tmp/migrate-dirs"

rm -rf "$WORKDIR"
mkdir -p "$WORKDIR"
cd "$WORKDIR" || exit 1
echo "Cloning source repo..."
git clone "$SOURCE_REPO" source
cd source || exit 1
git checkout main
mkdir ../selected-dirs
for dir in "${DIRS[@]}"; do
  if [ -d "$dir" ]; then
    cp -r "$dir" ../selected-dirs/
  else
    echo "Verzeichnis nicht gefunden: $dir"
  fi
done
cd ..
echo "Cloning target repo..."
git clone "$TARGET_REPO" target
cd target || exit 1
git checkout -b "$BRANCH_NAME"
cp -r ../selected-dirs/* .
git add .
git commit -m "Migrate directories (alerts, grafana-dashboards, runbooks) from old repo"
git push origin "$BRANCH_NAME"
echo "Erstelle merge request..."
curl --request POST "$GITLAB_API_URL/projects/$TARGET_PROJECT_ID/merge_requests" \
     --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" \
     --form "source_branch=$BRANCH_NAME" \
     --form "target_branch=$TARGET_BRANCH" \
     --form "title=Migrate monitoring-related directories from old repo" \
     --form "description=Automatischer Import von:\n- alerts/\n- grafana-dashboards/\n- runbooks/\naus altes repo."
echo "Merge Request erstellt: Branch '$BRANCH_NAME' in Ziel-Repo"

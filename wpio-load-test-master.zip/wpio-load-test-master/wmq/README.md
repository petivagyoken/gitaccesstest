# IBM Webspere MQ

A Docker container for IBM Websphere MQ provided by IBM for developer purposes.

## Configuration

We are using the standard IBM Docker image from Docker Hub.
Please note that we cannot use exactly the version we use in production right now but a slightly newer one as our version is no longer provided by IBM via Docker Hub.

IMPORTANT: Starting from version 9.1.4 the image supports changes to the qm.ini. We need this feature so we can't go back!

TIP: If we need the exact version we have to build our own image. This is explained [here](https://hub.docker.com/_/ibm-mq-advanced).

The image gets configured via environment variables, see wmq/environment.conf.

Queues and rights are configured via a predefined file that gets mounted into the container, see wmq/20-config.mqsc.

IMPORTANT: WPIO is using native IBM MQ features like certain IBM specific header fields. Rights have to be granted inside the queuemanager to use these features! Additionally you have to use native IBM MQ libraries inside the client programs, working only with JMS is not sufficient!

## Accessing the Queuemanager console

```
sudo docker-compose exec QM1 runmqsc
```

Most useful commands:

* `display qstatus (WPI.ORDER_ABFRAGEN.W778.LOAD);`
* `display lsstatus(*);`
* `display chstatus(DEV.APP.SVRCONN) all;`

Command to display messages in a queue (header and content too) :

```
sudo docker-compose exec QM1 bash
cd /opt/mqm/samp/bin
./amqsbcg DEV.QUEUE.1 QM1
```

## Monitoring IBM MQ

### Prometheus metrics

The MQ container's metrics exposed by https://github.com/Cinimex-Informatica/mq-java-exporter

With the current configuration, it exposes all available metrics without limitation.
* mq.java-exporter/export_config.yaml

For further details see https://github.com/Cinimex-Informatica/mq-java-exporter/blob/master/README.md

### Native MQ statistics

Additional options for monitoring MQ can be found here:

* https://ibm-messaging.github.io/mqperf/mqio_v1.pdf
* https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwil9ruZr8fpAhWCGewKHY4sA6cQFjAMegQIBRAB&url=https%3A%2F%2Fshare.confex.com%2Fshare%2F124%2Fwebprogram%2FHandout%2FSession17068%2FS17068-MQ-Monitoring.pdf&usg=AOvVaw3Q9YdzeZZbO0ZBLyO-Kp8V


## Further references

* https://github.com/ibm-messaging/mq-container
* https://github.com/ibm-messaging/mq-container/blob/master/internal/metrics/exporter.go
* https://github.com/ibm-messaging/mq-container/blob/master/internal/metrics/mapping.go
* https://ibm-messaging.github.io/mqperf/mqio_v1.pdf
* https://www.ibm.com/support/knowledgecenter/SSFKSJ_9.0.0/com.ibm.mq.mon.doc/mo00013_.htm
* valid RUNMQSC commands can be found [here](https://www.ibm.com/support/knowledgecenter/SSFKSJ_9.1.0/com.ibm.mq.ref.adm.doc/q085130_.htm)
* How to [configure MQ under Docker](https://www.ibm.com/support/knowledgecenter/SSFKSJ_9.0.0/com.ibm.mq.con.doc/q114482_.htm)
* for the MQ setup in general this [link](https://developer.ibm.com/messaging/learn-mq/mq-tutorials/mq-connect-to-queue-manager/) might help
* How the [dev_mode has been configured](https://github.com/ibm-messaging/mq-container/blob/master/incubating/mqadvanced-server-dev/10-dev.mqsc.tpl) by IBM in the Docker image
* How to solve problems regarding IBM MQ ([Developer Cheat Sheet](https://developer.ibm.com/messaging/learn-mq/mq-tutorials/dev-cheat-sheet/)) 
* https://www.ibm.com/support/pages/amq9513-maximum-number-channels-reached
* Information about [qm.ini settings](https://www.ibm.com/support/knowledgecenter/SSFKSJ_9.1.0/com.ibm.mq.con.doc/q133470_.htm)


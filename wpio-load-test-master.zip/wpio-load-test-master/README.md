# WPIO Load Test

Load generation and measurement for WPIO service components.

## Before first Execution on a FI-TS LuP-Server

1. Create a Putty/SSH configuration with a port tunnel to port 43000 (Grafana), 40080 (web server for showing results), 14141 (mq server) and 60000 (audit DB)
2. Login to the target machine with the new configuration. If the bash prompt doesn't show the pattern `[dwp1234@dwpwpioappe01:~]$`, check if *.bash_profile* exists. If it doesn't exist, contact f-i-ts ZZG-AppCore.
3. Configure the proxy http://dwp-pproxy1:3128/ for your shell by setting it as an environment variable `export HTTP_PROXY=http://dwp-pproxy1:3128/` or by adding it to your users *.bashrc* file.
4. Configure the proxy http://dwp-pproxy1:3128/ for git by adding it to your configuration `git config --global http.proxy http://dwp-pproxy1:3128/`
5. Checkout the project `git clone -v https://git.f-i-ts.de/dwp/wpio/wpio-load-test.git` (always use https and not ssh). If clone fails due to self signed certificate issue please turn off SSL self signed certificate verification by using git config --global http.sslVerify false
6. Change into the project root folder and create a .env file with the environment variable `HTTP_PROXY=http://dwp-pproxy1:3128/` for Container Image builds in the LuP Project  

## Execution

NOTE: These are the common steps for executing a load test. For further information see the README.md files in the different subfolders for a specific component!

1. Update the "System under Test (SUT)" component version in the according docker-compose.yml
2. Ensure your current working directory is the project root
3. `sudo ./loadtest.sh` shows a list of prepared docker-compose setups, e.g. `sudo ./loadtest.sh ./docker-compose/rp/dc-rp.sh` launches the docker-compose setup for testing jcf-rp
4. wait for the setup to enter the Gatling container... (will take up to 3min)
6. `./startSimulation.sh` displays a list of available Gatling simulations, e.g. `./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.rp.RpDerbyConstantLoad`
7. monitor the run with Grafana (http://localhost:43000/dashboards) and check the reports (http://localhost:40080/reports/) in a browser on your local machine

NOTE: A simulation can only run without errors, if the correct docker-compose setup is started before.

### Execution via Gatling Enterprise

1. Follow step 1 - 4 from the previous chapter
2. Login to https://gatlingfrontline.test.dwpbank.net/
3. Edit WPIO LuP-Server Testsimulation and insert the specific simulation parameters
4. Start WPIO LuP-Server Testsimulation
5. monitor the run with Grafana (http://localhost:43000/dashboards) in a browser on your local machine

Gatling Enterprise may also be triggered from CLI. In this case, follow step 1 - 6 from the previous chapter, but start the simulation with an additional parameter, e.g. `./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.rp.RpDerbyConstantLoad TESTLAB`. Beware, that it is still necessary to edit the WPIO LuP-Server Testsimulation and insert the specific simulation parameters in the Gatling Enterprise UI, because the API call via CLI cannot be parameterized.

Documentation: https://docs.gatling.io/reference/execute/self-hosted/user/simulations/

## Access Prometheus/Grafana

These services provide Prometheus metrics:

* IBM Websphere MQ (QM1)
* Derby DB (routingdb)
* WPIO Routing Point (rp)
* GenericServices
* Backend

The setup exposes Grafana (admin/admin123) under port `43000`.
This random port has been chosen to run the setup even on the dwppackappe01 machine, where several other developers might start monitoring instances.

In order to access this port from your laptop just tunnel the port, for example via putty.

Example:
https://localhost:3000/ (admin/admin123)

## Access Gatling reports

The setup exposes a web server on port `40080`, which is serving the Gatling reports. If you have forwarded the port, you can see them by calling https://localhost:40080/reports (for example)

## Debug containers

1. Start the setup in a shell like described above
2. Open another shell and enter single containers by executing

```
sudo docker-compose exec <container> bash
# or
sudo docker-compose logs <container>
```

### Websphere MQ

TIP: The IBM MQ docker container provides a web based console as well. The setup exposes this via port `49443`. In order to access it you have to tunnel this port and set MQ_ENABLE_EMBEDDED_WEB_SERVER (in the environment.conf file) variable to true.
 
Example:
https://localhost:49443/ibmmq/console/ (admin/passw0rd)

## Test data

Testdata files can be found in subfolder `testdata`. These are UTF-8 encoded files exported from the WPIO Audit system. 

Naming conventions: `<timestamp>-<audit status>-<component>-<some-id>.audit`

Example: `20200408T121321.661-S-C1-100001.audit`

For more details see the separate documentation for the Audit Browser.

### How to use the data

1. The load driver has to inject `*S-C1*` messages (Use the correct Client input queue otherwise the message will be rejected with a generic XML message)
2. The load driver will get the message with the newest timestamp back (message is only similar because message internal timestamps will vary)
3. The backend simulator will (in most cases) get `*S-B3-1*` messages 
4. The backend simulator has to deliver (in most cases) `*-B3-2*` messages back

## Local development

The standard FITS docker-compose setups are not usable for a development in the Development Factory (DF):
the WPIO-specific containers are not available (Docker registry not reachable).

You can use the `df` setup for this purpose.

## Routing data import
While developing new service tests the recurring build process can take lots of time. 
This is caused by the routing data import. It is possible to skip this import by adding the parameter ``--cache-routing-data`` 
to the loadtest.sh command. When the parameter is added for the first time the routingdb volume directory will be persistet, repetitive runs will then skip the database initialisation process.
````bash
sudo ./loadtest.sh ./docker-compose/xgen-cstmrmstr-qry/dc-xgen-cstmrmstr-qry.sh --cache-routing-data
````

## Audit Test
Use load test ./docker-compose/audit/dc-audit.sh to test jcf-audit service.
The test is based on the rp test scenario, therefore you can use all RpDerby* Gatling Simulations to create load for audit.
Please be aware that docker entrypoint for the audit services is amended, it will wait for the DB2 container to be completed.
You can start testing after the audit container has created the service logfile in tmp/audit/service.log. Usually this is way faster than the initial
routingdata setup (loading indicator).

##### Check if audit container is ready
````bash
ls -lah wpio-load-test/tmp/audit/service.log
tail wpio-load-test/tmp/audit/service.log
````

##### For a manual test use included messagetester service. 
````bash
sudo docker exec -it wpio_messagetester_1 bash -C ./send.sh DWP.DEINSTRMDTLS true DZ_DZ_DZ.ORDER_ERF/20200512T110104.575-S-B2-1.audit
````

##### Connect with Audit Browser
To connect the Audit Browser with the LuP DB2 Database you have to setup a port forwarding (port 60000)  with Putty to the LuP Server.
As the Audit Browser is delivered through Citrix you have to use the Citrix Putty.


- Database Alias: WPILADT
- User ID: db2inst1
- Password: passw0rd  
- Hostname: localhost
- Port: 60000

## Further documentation

* https://docs.tools.dwpbank.net/guide/wpintegratoronline/latest/
* file:///V:/WPIOnline/1B%20Dokumentation/1B4%20Betrieb/wpi%20Audit%20Browser/WPIO_AuditBrowser_Kurz%C3%BCbersicht_v1.3.doc

## Notes on starting test scenarios

### Start DWP.ORDER xgen test scenario
```
sudo ./loadtest.sh ./docker-compose/xgen-dwp-order/dc-xgen-dwp-order.sh
# than on the gatling console
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.xgen.DwpOrderDynamicLoad
```

### Start FI.CORPACTN xgen test scenario
```
sudo ./loadtest.sh ./docker-compose/xgen-fi-corpactn/dc-xgen-fi-corpactn.sh
# than on the gatling console
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.xgen.FiCorpactnDynamicLoad
```

### Start DWP.INVSTMNTPLN_QRY xgen test scenario
```
sudo ./loadtest.sh ./docker-compose/xgen-dwp-invstmntpln_qry/dc-xgen-dwp-invstmntpln_qry.sh
# than on the gatling console
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.xgen.DwpInvstmntplnQryDynamicLoad
```

### Start DWP.INSTRMDTLS xgen test scenario
```
sudo ./loadtest.sh ./docker-compose/xgen-dwp-instrmdtls/dc-xgen-dwp-instrmdtls.sh
# than on the gatling console
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.xgen.DwpInstrmdtlsDynamicLoad
```

### Start DWP.DEPOSIT xgen test scenario
```
sudo ./loadtest.sh ./docker-compose/xgen-deposit/dc-xgen-deposit.sh
# than on the gatling console
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.xgen.DwpDepositDynamicLoad
```

### Start dc-audit-idx.sh test scenario
```
sudo ./loadtest.sh ./docker-compose/audit-idx/dc-audit-idx.sh --skip-wait
# than on the gatling console
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.audit.AuditIdxConstantLoad
# or
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.audit.AuditIdxDynamicLoad
```

### Start dc-audit.sh test scenario
Run audit test setup
```shell
sudo ./loadtest.sh ./docker-compose/audit/dc-audit.sh --wait-for-db2
```
jcf-audit uses db2 audit database and via param --wait-for-db2 to start, after the DB2 is ready and the container connected successfully!

When container startup is completed execute load test.
```shell
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.audit.AuditConstantLoad
```

### Start  dc-audit-qry.sh test scenario
Run audit-qry test setup
```shell
sudo ./loadtest.sh ./docker-compose/audit-idx/dc-audit-qry.sh --wait-for-db2
```
jcf-audit-qry uses db2 audit database and via param --wait-for-db2 to start, after the DB2 is ready and the container connected successfully!
When container startup is completed execute load test.
```shell
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.audit.AuditQryConstantLoad
```

### Start ESB dc-genaudit.sh test scenario
Run ESB Genaudit test setup. Genaudit containers waits until DB2 container turns healthy, this can take a while.
```shell
sudo ./loadtest.sh ./docker-compose/genaudit/dc-genaudit.sh --skip-wait
```
### Start dc-rp-kafka.sh test scenario
Run rp-kafka test setup
```shell
sudo ./loadtest.sh ./docker-compose/rp-kafka/dc-rp-kafka.sh
```
jcf-rp-kafka uses routingdb, which needs to be setup during startup. Usually this takes a while.

When container startup is completed execute load test.
```shell
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.rp.RpKafkaConstantLoad
```
or 
```shell
./startSimulation.sh de.dwpbank.wpio.loadtest.simulation.rp.RpKafkaDynamicLoad
```

### Start Generic ESB dc-esb.sh test scenario
```shell
sudo ./loadtest.sh ./docker-compose/esb/dc-esb.sh --skip-wait
```

### Start ad-fwdiso
```shell
sudo ./loadtest.sh ./docker-compose/ad-fwdispo/dc-ad-fwdispo.sh
```

## Notes on enabling X-Gen Trace

1. start the load test setup with the according docker compose file
```shell
sudo ./loadtest.sh <docker-compose.yml>
```
2. check if everything is up & running and identify the container ID from your X-Gen service
```shell
sudo docker ps
```
3. open a bash on your desired container 
```shell
sudo docker exec -it <container-id> bash
```
4. switch the user from root to xgen 
```shell
su xgen
```
5. start the X-Gen service
```shell
./app/install/installAndStart.sh
```
... and exit from the loop with **Strg + C**
6. change the directory for trace files to the mounted temp-volume (do not forget to save and exit!)
```shell
vi /opt/xgen/4.13/X-Gen/config/ini/xgen.ini 
```
Find the entry **TracePath** and set it to **/app/traces**
7. restart X-Gen project <project-name>
```shell
cd /opt/xgen/4.13/X-Gen/  
. xshell.sh  # notice the blank between . and x!  
xgenadmin -auth admin:admin list  # find your project <project-name>  
xgenadmin -auth admin:admin status <project-name>  # check the status  
xgenadmin -auth admin:admin restart <project-name> -clear-trace -trace-mode active  # endable trace
```

In case of trouble kill xpm admin process (xpm will reload latest .ini).

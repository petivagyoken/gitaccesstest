# Prometheus

Used together with Grafana to provide metrics for a test run in a central place.

## Adding metrics

In the meantime several applications and systems provide Prometheus metrics out of the box. 
In that case a simple scraping has to be configured.

Most likely we have to use some metrics during special test cases that are not part of a standard product.
In such a case we have these options:

1. For common availability checks of an application you can use: https://github.com/prometheus/blackbox_exporter
2. For simple duration and success checks you can use https://github.com/adhocteam/script_exporter or https://github.com/ricoberger/script_exporter

If you have to measure more complex metrics(measurement needs more execution time or you want to deliver counters) 
or a scrape target is not always present you have to use an indirection and let asynchronous processes
do the measurement while another process is providing the currently known state.

Here these are the most commonly used approaches for this:

3. Use Node-Exporters textfile-collector (especially for machine related metrics): https://github.com/prometheus/node_exporter#textfile-collector
4. Use Prometheus Pushgateway (for more service related metrics): https://github.com/prometheus/pushgateway

Please also take a look at these recommendations and samples:

* https://prometheus.io/docs/practices/pushing/
* https://prometheus.io/docs/practices/instrumentation/#batch-jobs
* https://www.robustperception.io/monitoring-directory-sizes-with-the-textfile-collector

### Script_Exporter details

* How to create the Prometheus metric (syntax) from inside the shell script: https://github.com/ricoberger/script_exporter/blob/master/examples/showtimeout.sh

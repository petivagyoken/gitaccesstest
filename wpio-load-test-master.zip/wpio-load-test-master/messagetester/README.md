# MQ Message Tester

Simulates a WPIO MQ Client that injects a request based on native IBM Websphere MQ logic:

* No RFH2 header but MQSTR
* MsgType Request (1)
* ReplyToQ set
* ApplIdentityData set
* Msg is not persistent (WPIO Connector will change this based on the WPIO internal classification of the request)

## How to use

The container will be started but does nothing (sleep).

If you want to send a request you have to execute a script inside the container.

Usage: send.sh <appl_id> <input filename>

The input filename will be taken from /testdata.

```bash
docker exec -it wpioloadtest_messagetester_1 bash -C ./send.sh DWP.DEPOSIT 20200408T125803.390-S-C1-100001.audit
```

```bash
docker exec -it wpioloadtest_messagetester_1 bash
java -jar target/mq-message-tester.jar  --spring.config.location=file:///config/ --wpio.testdataApplIdentityData=DWP.ORDER --wpio.messagePersistent=true --wpio.testdataFilename=DZ_DZ_DZ.ORDER_ERF/20200512T110104.576-S-B2-1.audit --wpio.mqRequestQueue=DKB.REQUEST.DWP.LOAD
```
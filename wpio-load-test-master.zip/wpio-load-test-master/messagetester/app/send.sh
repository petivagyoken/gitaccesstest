#/bin/bash

if [ $# -ne 3 ]; then
  echo "Usage: $(basename $0) <appl_id> <persistent (true/false)> <input filename>"
  echo
  exit 1
fi

java -jar target/mq-message-tester.jar \
  --spring.config.location=file:///config/ \
  --wpio.testdataApplIdentityData="$1" \
  --wpio.messagePersistent="$2" \
  --wpio.testdataFilename="$3"

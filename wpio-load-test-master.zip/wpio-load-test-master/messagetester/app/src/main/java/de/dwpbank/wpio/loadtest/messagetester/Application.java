package de.dwpbank.wpio.loadtest.messagetester;

import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@ConfigurationPropertiesScan("de.dwpbank.wpio.loadtest")
@ComponentScan("de.dwpbank.wpio.loadtest")
@EnableJms
@Slf4j
public class Application implements ApplicationRunner {

  public static void main(String[] args) {
    ConfigurableApplicationContext context = SpringApplication.run(Application.class, args);
  }

  @Override
  public void run(ApplicationArguments args) throws Exception {
    log.debug("Application started with command-line arguments: {}",
        Arrays.toString(args.getSourceArgs()));
    log.debug("NonOptionArgs: {}", args.getNonOptionArgs());
    log.debug("OptionNames: {}", args.getOptionNames());

    // HINT: By default SpringApplication will convert any command line option arguments starting with ‘–’
    // (e.g. –server.port=9000) to a property and add it to the Spring Environment so we simply handover
    // applId and filename from the shell script...
  }
}
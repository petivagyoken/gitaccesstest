package de.dwpbank.wpio.loadtest.messagetester;

import com.ibm.mq.constants.MQConstants;
import com.ibm.msg.client.jms.JmsConstants;
import com.ibm.msg.client.wmq.WMQConstants;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Slf4j
@Service
public class DummyClient implements ApplicationRunner {

  private static final SimpleDateFormat wmqDateFormat = new SimpleDateFormat("yyyyMMdd");
  private static final SimpleDateFormat wmqTimeFormat = new SimpleDateFormat("HHmmssSS");
  @Autowired
  JmsTemplate jmsTemplate;
  @Autowired
  private TestMessageProperties testMessageProperties;

  @Override
  public void run(ApplicationArguments args) throws Exception {
    sendTestMessage(args.getOptionValues("wpio.testdataApplIdentityData").get(0),
        args.getOptionValues("wpio.testdataFilename").get(0),
        Boolean.parseBoolean(args.getOptionValues("wpio.messagePersistent").get(0)));
  }

  private void sendTestMessage(String testDataApplIdentityData, String testDataFilename,
      boolean persistent) throws Exception {

    String content = loadMessageFromFile(testMessageProperties.getTestdataFolder(),
        testDataFilename, Charset.forName("UTF-8"));

    log.debug("Try to send request to {}. ApplIdentityData: {}. Persistent: {}. Payload: {}",
        testMessageProperties.getMqRequestQueue(),
        testDataApplIdentityData,
        persistent,
        content);

    String requestQueueUrl = "queue:///"
        + testMessageProperties.getMqRequestQueue()
        + "?targetClient=" + WMQConstants.WMQ_CLIENT_NONJMS_MQ;

    jmsTemplate.send(testMessageProperties.getMqRequestQueue(), messageCreator -> {

      TextMessage message =
          messageCreator.createTextMessage(content);

      //TODO: Strange usage mix of Constants (JmsConstants, WMQConstants, MQConstants)! Check if this can be harmonized.

      message.setIntProperty(WMQConstants.WMQ_MQMD_MESSAGE_CONTEXT,
          WMQConstants.WMQ_MDCTX_SET_ALL_CONTEXT);
      message.setIntProperty(JmsConstants.JMS_IBM_MSGTYPE, MQConstants.MQMT_REQUEST);
      message.setStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ,
          testMessageProperties.getMqReplyQueue());
      message
          .setStringProperty(WMQConstants.JMS_IBM_MQMD_APPLIDENTITYDATA, testDataApplIdentityData);
      message.setStringProperty(WMQConstants.JMS_IBM_MQMD_APPLORIGINDATA, "ORIGINDUMMY");
      if (persistent) {
        message.setIntProperty(WMQConstants.JMS_IBM_MQMD_PERSISTENCE, MQConstants.MQPER_PERSISTENT);
      } else {
        message.setIntProperty(WMQConstants.JMS_IBM_MQMD_PERSISTENCE,
            MQConstants.MQPER_NOT_PERSISTENT);
      }

      Timestamp timestamp = new Timestamp(System.currentTimeMillis());

      message.setStringProperty(WMQConstants.JMS_IBM_MQMD_PUTDATE, wmqDateFormat.format(timestamp));
      message.setStringProperty(WMQConstants.JMS_IBM_MQMD_PUTTIME, wmqTimeFormat.format(timestamp));

      return message;
    });

    log.info("Message has been sent, waiting for answer. Press Ctrl-C for program termination...");
  }

  @JmsListener(destination = "${wpio.mqReplyQueue}")
  public void receiveMessage(final Message receivedMessage, String content) {
    try {
      log.debug("Got message from {}", testMessageProperties.getMqReplyQueue());

      log.debug("Header field format={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_FORMAT));
      log.debug("Header field messageId={}", receivedMessage.getJMSMessageID());
      log.debug("Header field correlId={}", receivedMessage.getJMSCorrelationID());
      log.debug("Header field msgType={}",
          receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE));
      log.debug("Header field putDate={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTDATE));
      log.debug("Header field putTime={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTTIME));
      log.debug("Header field replyToQ={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ));
      log.debug("Header field persistence={}",
          receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_PERSISTENCE));
      log.debug("Header field applName={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_PUTAPPLNAME));
      log.debug("Header field userIdentifier={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_USERIDENTIFIER));
      log.debug("Header field applIdentityData={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_APPLIDENTITYDATA));
      log.debug("Header field applOriginData={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_APPLORIGINDATA));
      log.debug("Header field backoutCount={}",
          receivedMessage.getStringProperty(WMQConstants.JMS_IBM_MQMD_BACKOUTCOUNT));
      log.debug("Header field msgSeqNumber={}",
          receivedMessage.getLongProperty(WMQConstants.JMS_IBM_MQMD_MSGSEQNUMBER));
      log.debug("Header field offset={}",
          receivedMessage.getLongProperty(WMQConstants.JMS_IBM_MQMD_OFFSET));
      log.debug("Header field msgFlags={}",
          receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_MSGFLAGS));
      log.debug("Header field encoding={}",
          receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_ENCODING));
      log.debug("Header field codedCharSetId={}",
          receivedMessage.getIntProperty(WMQConstants.JMS_IBM_MQMD_CODEDCHARSETID));

      log.debug("Content (first 1000 of {} bytes)={}", content.length(),
          content.substring(0, Math.min(content.length(), 1000)));

    } catch (JMSException e) {
      e.printStackTrace();
    }
  }


  private String loadMessageFromFile(String testdataFolder, String filename, Charset encoding)
      throws Exception {

    log.debug("try to load testdata file {} under location {}", filename, testdataFolder);

    if (StringUtils.isEmpty(testdataFolder)) {
      throw new Exception(
          "Please specify correct testdata location in application.properties file!");
    }

    Path testdataPath = Paths.get(testdataFolder);

    if (Files.notExists(testdataPath)) {
      throw new Exception("testdata folder does not exist!");
    }

    Path inputFile = Paths.get(testdataFolder, filename);

    if (Files.notExists(inputFile)) {
      throw new FileNotFoundException("Testdata file does not exist: " + filename);
    }

    String message;
    try {
      message = Files.readString(inputFile, encoding);
      log.debug("loaded testdata message {}.", filename);
    } catch (IOException e) {
      throw new IOException("Error reading testdata file " + filename,
          e);
    }

    return message;
  }

}

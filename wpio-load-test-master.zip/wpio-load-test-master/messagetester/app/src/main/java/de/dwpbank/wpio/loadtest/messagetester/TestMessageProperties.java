package de.dwpbank.wpio.loadtest.messagetester;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Setter
@Getter
@ConfigurationProperties(prefix = "wpio")
public class TestMessageProperties {

  private String testdataFolder;
  private String mqRequestQueue;
  private String mqReplyQueue;

}

# Grafana

We are using Grafana for visualizing Prometheus metrics.

With every new test constellation ist has to be checked if the needed metrics are already there or if something is missing or useless. Additionally the description inside the dashboard has to be checked as well: if we use the grafana results as a test documentation for future component changes the screenshots taken have to be meaningful...

## How to modify the dashboard

The predefined dashboard is stored here: https://git.f-i-ts.de/dwx0151/wpio-load-test/blob/master/grafana/provisioning/dashboards/wpio-load-test.json

Best way for changing it:

1. make a dashboard copy in the running Grafana (you are not allowed to change the existing one)
2. do changes at the dashboard and try them out
3. export "your" dashboard as a json file
4. insert the content of the new json file into the existing wpio-load-test.json file mentioned above

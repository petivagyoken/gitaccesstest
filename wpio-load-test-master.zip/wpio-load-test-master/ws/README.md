# Webservices (SOAP adapter)

Unmodified jcf-ws container instance. Nothing more.
---
name: wpio-xgen-version-synchronisation
description: Upgrades and synchronises wpio-xgen service versions across test environments based on Prod. Accepts input in the format "FOLDER SERVICE" or "FOLDER/SERVICE".
allowed-tools: ["Bash", "Edit", "View", "Glob", "Grep"]
---

# Usage & Examples for Team Members
To invoke this skill, run one of the following commands in Claude Code:

- **Path syntax:**
  `/wpio-xgen-version-synchronisation rr/my-service`

- **Space-separated syntax:**
  `/wpio-xgen-version-synchronisation rr my-service`

- **Natural language prompt:**
  `Run the wpio-xgen-version-synchronisation skill for folder "rr" and service "my-service"`

---

# Parameter Parsing
Parse `$ARGUMENT` to extract the target directory and service name:
- If `$ARGUMENT` contains a slash (e.g., `rr/my-service`), set:
    - `TARGET_FOLDER` = `rr`
    - `TARGET_SERVICE` = `my-service`
- If `$ARGUMENT` contains two space-separated words (e.g., `rr my-service`), set:
    - `TARGET_FOLDER` = first word (`rr`)
    - `TARGET_SERVICE` = second word (`my-service`)

---

# Scope & Environment Setup
- **Target Scope:** Strictly operate within `roles/xgen/{TARGET_FOLDER}/vars/`. Do NOT read or modify files outside this directory.

---

# Steps to Execute

1. **Verify Source Single Match Services:**
    - Read `roles/xgen/{TARGET_FOLDER}/vars/single-match-prod.yaml` using the `View` tool.
    - Extract the exact list of services defined in `single-match-prod.yaml`.

2. **Update Single Match Test Environments:**
    - Target environments: `tud`, `tuf`, `tug`, `tum`, `tuz`.
    - For each environment file `roles/xgen/{TARGET_FOLDER}/vars/single-match-{env}.yaml`:
        - Overwrite the list to match `single-match-prod.yaml` exactly.
        - Delete any extra services present in the test environment that are not in `single-match-prod.yaml`.
        - Maintain original YAML indentation, structure, and formatting. Do not insert extra trailing blank lines.

3. **Verify Source Service Version:**
    - Read `roles/xgen/{TARGET_FOLDER}/vars/versions-prod.yaml` using the `View` tool.
    - Extract the exact version string for `{TARGET_SERVICE}`.

4. **Update Version Test Environments:**
    - Target environments: `tud`, `tuf`, `tug`, `tum`, `tuq`, `tuv`, `tuz`.
    - For each environment file `roles/xgen/{TARGET_FOLDER}/vars/versions-{env}.yaml`:

        - **Safety Exclusion:** Skip any file containing the word `canary` in its filename or contents. Log: `[SKIP] {env}: File contains 'canary'.`

        - **Version Comparison & Update:**
            - Find the `{TARGET_SERVICE}` entry.
            - **Greater Test Version Check:** If the version in `{env}` is higher than Prod (e.g., Prod is `v4.13.000-4.13-1.14-DWP-p017-2025@EE` and test is `v4.13.111-4.13-1.14-DWP-p017-2025@EE`), **do NOT update it**. Log: `[SKIP] {env}: Test version ({test_ver}) is newer than Prod ({prod_ver}).`
            - **Standard Update:** Otherwise, replace the `{TARGET_SERVICE}` version with the version from `versions-prod.yaml`.

        - **Formatting Rules:** Preserve surrounding keys, indentation, comments, and structure. Do not add trailing blank lines at the end of the file.

5. **Validation & Verification:**
    - Run `git diff roles/xgen/{TARGET_FOLDER}/vars/` via `Bash` to inspect all modifications.
    - Verify that non-target properties and canary files remain completely untouched.
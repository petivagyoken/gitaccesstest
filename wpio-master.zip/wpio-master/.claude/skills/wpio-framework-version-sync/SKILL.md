---
name: wpio-framework-version-synchronisation
description: Upgrades and synchronises wpio-framework service versions across all test environments based on the Prod version for specific services or domain groups.
allowed-tools: ["Bash", "Edit", "View", "Glob", "Grep"]
---

# Usage & Examples for Team Members
To invoke this skill, run one of the following commands in Claude Code:

- **Natural language prompt:**
  `Update the framework versions for rr to match prod"`

---

# Scope & Environment Setup
- **Target Scope:** Strictly operate within `roles/jcf/` subdirectories. Do NOT read or modify files outside `roles/jcf/`.
- **Target Argument:** `$ARGUMENT`

# Domain Mapping Rules
Evaluate `$ARGUMENT` against the following rules to determine the list of target services (`SERVICE_LIST`):

- **If `$ARGUMENT` is `fp`:**
  Set `SERVICE_LIST` = `["fp", "sys-cert"]`
- **If `$ARGUMENT` is `rr`:**
  Set `SERVICE_LIST` = `["rp", "http", "ws", "sys", "rp-kafka", "rp-audit-move"]`
- **If `$ARGUMENT` is `ad`:**
  Set `SERVICE_LIST` = `["ad-dwp-fwdispo", "ad-dwp-routstat", "ad-dwp-wii", "ad-dwp-order"]`
- **If `$ARGUMENT` is `audit`:**
  Set `SERVICE_LIST` = `["audit", "audit-idx", "audit-sla", "audit-qry"]`
- **Otherwise (Direct Service Name):**
  Set `SERVICE_LIST` = `["$ARGUMENT"]`

---

# Steps to Execute

For **EACH** service in `SERVICE_LIST`:

1. **Verify Source Production Values:**
   - Read `roles/jcf/{service}/vars/service-prod.yaml` using the `View` tool.
   - Extract the exact `version` and `image` defined for Production.

2. **Update Test Environments:**
    - Target environments: `tud`, `tuf`, `tug`, `tuh`, `tum`, `tuz`.
    - For each environment file `roles/jcf/{service}/vars/service-{env}.yaml`:

        - **Version Comparison Checks:**
            - **Greater Test Version:** If the version in the test environment is higher than Prod (e.g., Prod is `v1.0.0` and test is `v1.0.1`), **do NOT update it**. Log a report message: `[SKIP] {env}: Test version ({test_ver}) is newer than Prod ({prod_ver}).`
            - **Feature Branch Version:** If the test version is a feature branch (e.g., contains a branch name, `feature/`, `bugfix/`, or non-semver tag), **do NOT update automatically**. Ask the user in the terminal: *"Environment {env} has feature branch version '{test_ver}'. Do you want to overwrite it with Prod version '{prod_ver}' or skip it?"* Wait for explicit user confirmation before touching this file.

        - **Key Inspection Checks:**
            - **Missing Keys:** Scan all keys under the service definition in `service-prod.yaml`. If any key is missing in `service-{env}.yaml`, **do NOT update automatically**. Present the missing keys to the user and ask: *"Environment {env} is missing key(s) '{missing_keys}'. Should I copy the value from Prod, or would you like to specify custom values?"* Wait for explicit user input before adding them.

        - **Standard Auto-Updates (When no exceptions apply):**
            - Update `version` to match `service-prod.yaml`.
            - Update `image` to match `service-prod.yaml`.

        - **Preserve Existing Values & Formatting:**
            - Do NOT overwrite or alter existing keys/values (e.g., environment-specific settings like `spring_profiles_active` or client ID wildcards must remain unchanged).
            - Maintain original YAML indentation, structure, and spacing. Do not add trailing blank lines at the end of the file.

3. **Validation & Verification:**
   - Run `git diff roles/jcf/` via `Bash` to inspect all modifications.
   - Confirm that non-version/image properties in the test YAML files remain completely untouched.
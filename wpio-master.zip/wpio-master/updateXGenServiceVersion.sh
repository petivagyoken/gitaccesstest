#!/bin/env bash

#set -euo pipefail

#set -x

showHelp() {
  echo "${1:-}"
  echo "Usage: $(basename "$0") <env in lowercase>"
  echo
  echo 'Update service version in file roles/xgen/*/vars/versions-<env>.yaml.'
  echo
  echo ' Options:'
  echo ' -b : limit to list of valid CI_BUILD_IDs separated by ,' 
  echo ' -i : service image that has to be modified (default: all). Example: xgen-dwp-order' 
  echo ' -n : use no CI_BUILD_IDs. Not in conjunction with -b.' 
  echo ' -s : simulate all operations' 
  echo ' -v : service version that has to be used (default: preserve existing one). Only valid in conjunction with -i.' 
  echo
  exit 1
}

validBuildIds="[0-9]+"
serviceImage=''
serviceImagePattern=''
serviceVersion=''
simulate=false
preserveVersion=true
useBuildId=true

OPTIND=1
while getopts "b:i:nsv:" Option
do
  case $Option in
    b ) validBuildIds="(${OPTARG//,/|})";;
    i ) serviceImage="${OPTARG}"
        serviceImagePattern="${OPTARG//-/\-}\""
        ;;
    n ) useBuildId=false;;
    s ) simulate=true;;
    v ) serviceVersion="${OPTARG//-/\-}"
        preserveVersion=false
        ;;
    * ) showHelp 'Invalid option!';;
  esac
done
shift $((OPTIND - 1))

if [ $# -ne 1 ]; then
  showHelp 'Invalid number of arguments!'
fi

env=$1

if [ ! -e "roles/xgen/rr/vars/versions-${env}.yaml" ]; then
  showHelp "Requested environment ${env} not configured yet!"
  exit 1
fi

if [ -n "${serviceVersion}" ] && [ -z "${serviceImage}" ]; then
  showHelp "Version can only be specified together with a concrete service image!"
  exit 1
fi

counter=0
overallRc=0

if [ $simulate == 'true' ]; then
  echo 'Simulation mode, no changes will happen...'
fi

while read -r imageName; do

  echo -n "Analysing $imageName: "

  (( counter+=1 ))
  serviceNameAnsible=${imageName//-/_}

  # determine current service version
  currentVersion=$(grep "$serviceNameAnsible: \"" roles/xgen/*/vars/versions-"${env}".yaml | cut -d'"' -f2)
  currentBaseVersion=$(echo "${currentVersion}" | sed -r 's#^(.+)-[0-9]+#\1#')

  if [ -z "$currentBaseVersion" ] && [ -z "$serviceVersion" ]; then
    echo "No version variable found in vars/versions-${env}.yaml!"
    overallRc=1
    continue
  fi

  echo -n "$currentVersion -> "

  if [ $preserveVersion == 'true' ]; then
    serviceVersion=${currentBaseVersion//-/\-}
  fi
  if [ $useBuildId == 'true' ]; then
    searchPattern="${serviceVersion}\-${validBuildIds}\""
  else
    searchPattern="${serviceVersion}\""
  fi

  newestTag=$(curl -Ssk https://registry.dwp/v2/wpio/"$imageName"/tags/list | tr ',[]:' '\n' | sort | grep -E "${searchPattern}" | tail -1 | cut -d'"' -f2)

  if [ "${newestTag:-}" == '' ]; then
    echo "no valid target tag found!"
    overallRc=1
    continue
  fi 

  echo "$newestTag"

  if [ $simulate == 'false' ]; then
    sed -i "s/$serviceNameAnsible: \".*\"/$serviceNameAnsible: \"$newestTag\"/" roles/xgen/*/vars/versions-"${env}".yaml
  fi

done < <(grep "image: \"registry.dwp/wpio/$serviceImagePattern" roles/xgen/*/vars/services.yaml | cut -d'"' -f2 | cut -d/ -f3)

if [ -n "${serviceImage}" ] && [ $counter -eq 0 ]; then
  echo "Service image configuration for ${serviceImage} not found!"  
  exit 1
fi

exit $overallRc


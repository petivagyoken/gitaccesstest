#!/bin/bash

# VARIABLES
DEBUG=false

[ "$DEBUG" = "true" ] && set -x

WAITTIME=10
THROTTLE=10
BLACK_LIST="routingdata idf start stop"
SEQUENCE="dwp-gen-audit dwp-wpio-jcf-audit dwp-wpio-jcf-routingdb dwp-wpio-jcf dwp-wpio-esb-routingdb dwp-wpio-esb dwp-wpio-xgen-rr"

# Check, if we're root
SUDO=""
if [ "_$USER" != "_root" ]; then
   SUDO=sudo
fi

# FUNCTIONS

# TODO - create function to identify and suspend appropriate QMgrs

start(){
   local LIST_OF_SERVICES="$1"
   local i=0
   for s in $LIST_OF_SERVICES; do
       echo $s
       $SUDO systemctl status $s | grep "Active: active (running)" > /dev/null && continue
       $SUDO systemctl start $s
       i=$((i+1))
       if [ $i -eq $THROTTLE ]; then
          i=0
          sleep $WAITTIME
       fi
       [ "$DEBUG" = "true" ] && $SUDO systemctl status $s
   done
}

stop(){
   local LIST_OF_SERVICES="$1"
   local i=0
   for s in $LIST_OF_SERVICES; do
       echo $s
       $SUDO systemctl stop $s &
       i=$((i+1))
       if [ $i -eq $THROTTLE ]; then
          i=0
          sleep $WAITTIME
       fi
       [ "$DEBUG" = "true" ] && $SUDO systemctl status $s
   done
}


disable(){
   # shellcheck disable=2048
   $SUDO systemctl disable $*
}

enable(){
   # shellcheck disable=2048
   $SUDO systemctl enable $*
}

### MAIN
#SEQUENCE="dwp-wpio-jcf-routingdb"

case $1 in 
   start)
      for SEQ in $SEQUENCE; do 
         # shellcheck disable=SC2010
         LIST_OF_SERVICES="$(ls /etc/systemd/system | grep $SEQ | grep -E -v ${BLACK_LIST// /|})"
         echo "$LIST_OF_SERVICES"
         start "$LIST_OF_SERVICES"
         enable "$LIST_OF_SERVICES"
      done
   ;;
   stop)
      for SEQ in $SEQUENCE; do
         # shellcheck disable=SC2010
         LIST_OF_SERVICES="$(ls /etc/systemd/system | grep $SEQ | grep -E -v ${BLACK_LIST// /|})"
         stop "$LIST_OF_SERVICES"
         disable "$LIST_OF_SERVICES"
      done
   ;;
   *)
      exit 0
   ;;
esac

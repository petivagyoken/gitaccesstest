#!/bin/bash
set -xv
[[ -d /tmp/ansible ]] || mkdir -p /tmp/ansible
cd /etc/systemd/system

hostname -s|grep -q dwptu && Env=$(hostname -s|cut -b6|tr 'a-z' 'A-Z')
case ${Env} in
 A|E|S)
  /usr/bin/systemctl stop dwp-wpio-jcf-ws-node5.service
  /usr/bin/systemctl disable dwp-wpio-jcf-ws-node1.service
  /usr/bin/systemctl disable dwp-wpio-jcf-ws-node5.service
  sudo -u mqm /appdata/mqm/admin/bin/betrieb/MQClusterCmd.sh suspend WPIBE${ENV}5
  ;;
 D|F|G|H|K|M|Q|V|Z)
  /usr/bin/systemctl stop dwp-wpio-jcf-ws-node5.service
  /usr/bin/systemctl disable dwp-wpio-jcf-ws-node1.service
  /usr/bin/systemctl disable dwp-wpio-jcf-ws-node5.service
  sudo -u mqm /appdata/mqm/admin/bin/betrieb/MQClusterCmd.sh suspend WPIBT${ENV}5
  ;;
 *) echo "The service running on $(hostname -s) now" ;;
esac 

hostname -s|grep -q dwpwpio && { ENV=$(hostname -s|cut -b11 |tr 'a-z' 'A-Z'); N=$(hostname -s|cut -b12-13|bc); }
case $ENV in
 A|P)
  /usr/bin/systemctl stop dwp-wpio-jcf-ws-node${N}.service
  /usr/bin/systemctl disable dwp-wpio-jcf-ws-node${N}.service
  docker ps -a | egrep --color=auto dwp-wpio-xgen | egrep --color=auto Up | awk '{print $NF}' > /tmp/ansible/xgenu-vorstop.txt
  ;;
esac
sleep 10
/usr/bin/systemctl stop $(ls dwp-wpio* |grep -Ev "node_exporter|filebeat|journalbeat|cadvisor|start|stop|idf|routingdata")

#!/bin/bash
set -xv
cd /etc/systemd/system

hostname -s|grep -q dwptu && Env=$(hostname -s|cut -b6 |tr 'a-z' 'A-Z')
case ${Env} in
 A|E|S)
  /usr/bin/systemctl stop dwp-wpio-jcf-ws-node5.service
  sudo -u mqm /appdata/mqm/admin/bin/betrieb/MQClusterCmd.sh suspend WPIBE${Env}5
  ;;
 D|F|G|H|K|M|Q|V|Z)
  /usr/bin/systemctl stop dwp-wpio-jcf-ws-node5.service
  sudo -u mqm /appdata/mqm/admin/bin/betrieb/MQClusterCmd.sh suspend WPIBT${Env}5
  ;;
 *) echo "The service running on $(hostname -s) now" ;;
esac

cd /etc/systemd/system
/usr/bin/systemctl stop $(ls dwp-wpio-jcf* |grep -Ev "start|stop|idf|routingdata|ws")

cd /etc/systemd/system
/usr/bin/systemctl stop $(ls dwp-wpio-esb* |grep -Ev "start|stop|idf|routingdata")

for i in $(ls dwp-wpio-xgen* |grep fi-sparplan-c); do
 /usr/bin/systemctl stop ${i}
 /usr/bin/systemctl disable ${i}
 /usr/bin/docker rm --force --volumes ${i}
done

for i in $(ls dwp-wpio-xgen* |grep -Ev "start|stop|idf|routingdata|fi-sparplan-c")
 do /usr/bin/systemctl start $i
 sleep 1
done

sleep 100

a=0
while [[ $a -le 600 ]]; do
 x=$(docker ps -a --format="table {{.Names}}\t{{.Image}}\t{{.Status}}" | egrep --color=auto -i xgen|egrep Removal)
 y=$(docker ps -a --format="table {{.Names}}\t{{.Image}}\t{{.Status}}" | egrep --color=auto -i xgen|egrep Exit)
 z=$(docker ps -a --format="table {{.Names}}\t{{.Image}}\t{{.Status}}" | egrep --color=auto -i xgen|egrep Create)
 [[ ! $x ]] && [[ ! $y ]] && [[ ! $z ]] && break
 sleep 60
 ((a=$a+60))
done
 
[[ $x ]] || [[ $y ]] || [[ $z ]] &&\
  { 
    echo "xgen services still not restarted on $(hostname -s)" 
    echo "start process will stop now, please go-ahead with manull intervention"
    exit 128
}

cd /etc/systemd/system
for i in $(ls dwp-wpio-jcf* |grep -Ev "start|stop|idf|routingdata|ws")
 do /usr/bin/systemctl start $i
 sleep 30
done

cd /etc/systemd/system
for i in $(ls dwp-wpio-esb* |grep -Ev "start|stop|idf|routingdata")
 do /usr/bin/systemctl start $i
 sleep 30
done

case ${Env} in
 A|E|S)
  sudo -u mqm /appdata/mqm/admin/bin/betrieb/MQClusterCmd.sh resume WPIBE${Env}5
  /usr/bin/systemctl start dwp-wpio-jcf-ws-node5.service
  ;;
 D|F|G|H|K|M|Q|V|Z)
  sudo -u mqm /appdata/mqm/admin/bin/betrieb/MQClusterCmd.sh resume WPIBT${Env}5
  /usr/bin/systemctl start dwp-wpio-jcf-ws-node5.service
  ;;
 *) echo "The service was running on $(hostname -s)" ;;
esac

cd /etc/systemd/system
for i in dwp-cadvisor.service dwp-mxrc.service dwp-node_exporter.service
 do /usr/bin/systemctl start $i
done


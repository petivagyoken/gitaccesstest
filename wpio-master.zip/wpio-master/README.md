= WPIO Deployment
:toc:
:toclevels: 4
:sectnums:


== Introduction

Deployment configuration for all WPIO related components.

HINT: this does NOT include the ESB related components, these are maintained via https://git.f-i-ts.de/dwp/deployment/wpio-esb. 

WPIO is a clustered application with two main node types: RR (Request Response) and AD-FP (ActiveDelivery and FileProcessing).
There will only be one node configured as an AD-FP node but 2 or more nodes with RR functionality.

== Removing XGen services
- In files roles/xgen/(rr|ad|fp)/vars/services-to-remove-(tu[x]|prod).yaml, enlist all services to be removed from FI-TS runtime environments. +
  The service name must contains also the channel! + 
  Sample from file "roles/xgen/rr/vars/services-to-remove-tua.yaml":
  
  xgen_services_rr_to_remove_tua:
  - "wp2-mt596-a-onl-a"
  - "wp2-mt515-e-onl-a"
  - "gad-cashmgmnt-apo-a"
  
- In files "roles/xgen/(rr|ad|fp)/vars/versions-(tu[x]|prod).yaml"  set the version of removing services to "0.0.0" +  
  Sample from file "roles/xgen/rr/vars/versions-tua.yaml":

  xgen_wp2_mt596_a_onl: "0.0.0"
  xgen_wp2_mt515_e_onl: "0.0.0"
  xgen_gad_cashmgmnt_apo: "0.0.0"

- Merge master branch  to  test/prod baranch and from created pipeline run/order job "xgen-(rr|ad|fp)-remove-single"
- After the job is completed check if the services are no longer present in the runtime environment.
- After the services are removed from all test and prod runtime environments, delete services entry from those files:

   roles/xgen/(rr|ad|fp)/vars/services.yaml
   roles/xgen/(rr|ad|fp)/vars/versions-(tu[x]|prod).yaml
   
- After the job "xgen-(rr|ad|fp)-remove-single" run successfully and the service was removed, create an Auftrag to request the docker image removal.
  The service full name and the version shall be provided. For example:
  
  dwp-wpio-xgen-rr-wp2-mt596-a-onl-a-node5.service 1.0.2-860891

 
  




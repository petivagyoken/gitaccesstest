#!/usr/bin/env python
import unittest
from filters import service_match, skip_no_version, get_no_version

class FilterTest(unittest.TestCase):

    def test_service_match(self):
        services = dict(aservice="A", bservice="B", cservice="C")
        result = service_match(services, ['b'])
        self.assertEqual(len(result), 1)
        self.assertDictEqual(dict(bservice="B"), result)

        result = service_match(services, ['b', 'a'])
        self.assertEqual(len(result), 2)
        self.assertDictEqual(dict(bservice="B", aservice="A"), result)

        result = service_match(services, ['*'])
        self.assertEqual(len(result), 3)
        self.assertDictEqual(dict(aservice="A", bservice="B", cservice="C"), result)

        result = service_match(services, ['c', '*'])
        self.assertEqual(len(result), 3)
        self.assertDictEqual(dict(aservice="A", bservice="B", cservice="C"), result)

        result = service_match(services, ['z'])
        self.assertEqual(len(result), 0)

    def test_skip_no_version(self):
        services = dict(
            aservice=dict(image="A", version="1.0"),
            bservice=dict(image="B", version="0.0.0"),
            cservice=dict(image="C"),
            dservice=dict(image="D", version="2.1"),
            eservice=dict(image="E", version="")
        )
        result = skip_no_version(services)
        self.assertEqual(len(result), 2)
        self.assertDictEqual(dict(
            aservice=dict(image="A", version="1.0"),
            dservice=dict(image="D", version="2.1")), result)

    def test_get_no_version(self):
        services = dict(
            aservice=dict(image="A", version="1.0"),
            bservice=dict(image="B", version="0.0.0"),
            cservice=dict(image="C"),
            dservice=dict(image="D", version="2.1"),
            eservice=dict(image="E", version="")
        )
        result = get_no_version(services)
        self.assertEqual(len(result), 3)
        self.assertDictEqual(dict(
            bservice=dict(image="B", version="0.0.0"),
            cservice=dict(image="C"),
            eservice=dict(image="E", version="")), result)


if __name__ == '__main__':
    unittest.main()

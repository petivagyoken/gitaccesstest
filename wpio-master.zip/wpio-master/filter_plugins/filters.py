#!/usr/bin/env python
"""
A filter which can be used in a jinja expression.
It reduces a given list of services by a list of pattern of the service name.
Only these services are return which are matching the match_list in the service name.

All services which version are set to DUMMY_VERSION are ignored and therfore ommited.
"""

from __future__ import (absolute_import)
from ansible.utils.display import Display
display = Display()

__metaclass__ = type

DUMMY_VERSION = "0.0.0"

def service_match(services, match_list):
    """Reduce service by match_list on the service name"""
    result = dict()
    for key, value in services.items():
        for match in match_list:
            if match == "*" or match in key:
                result[key] = value
    return result

def skip_no_version(services):
    """If service have special version defined, skipt it."""
    result = dict()
    for service_name, service in services.items():
        # ommit all services thich have no version or a special version specified.
        if __has_no_version(service):
            display.display("skip service: %s because version not set." % service)
            continue
        result[service_name] = service
    return result

def get_no_version(services):
    """Return a dict containing only services with no version specified"""
    result = dict()
    for service_name, service in services.items():
        # ommit all services thich have no version or a special version specified.
        if __has_no_version(service):
            result[service_name] = service
    return result

def services_remove(all_services, services_to_remove):
    """
    reduce a dict of services to them
    listed in services_to_remove and
    if they have no version set.
    """
    result = dict()
    for service_name, service in all_services.items():
        for service_to_remove in services_to_remove:
            if service_to_remove in service_name \
                and __has_no_version(service):
                result[service_name] = service
    return result

def __has_no_version(service):
    """Return true if version is not specified"""
    if not "version" in service \
        or service["version"] is None \
        or service["version"] == "" \
        or service["version"] == DUMMY_VERSION:
        return True
    return False

class FilterModule(object):
    """Custom service match filter"""

    def filters(self):
        """define a list of filters"""
        return {
            'service_match': service_match,
            'skip_no_version': skip_no_version,
            'get_no_version': get_no_version,
            'services_remove': services_remove,
            'makedict': lambda _val, _list: { k: _val for k in _list }
        }

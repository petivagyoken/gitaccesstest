#!/bin/env bash

for imageName in $(grep 'image:' roles/jcf/*/vars/main.yaml | cut -d'"' -f2 | cut -d/ -f3); do
  echo "Analysing $imageName ..."
  curl -Ssk https://registry.dwp/v2/wpio/$imageName/tags/list | tr ',' '\n' 
done


var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "950400",
        "ok": "950400",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 950400,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "460.688",
        "ok": "460.688",
        "ko": "-"
    }
},
contents: {
"req_order-insert----a6f8e": {
        type: "REQUEST",
        name: "Order Insert - Degussa",
path: "Order Insert - Degussa",
pathFormatted: "req_order-insert----a6f8e",
stats: {
    "name": "Order Insert - Degussa",
    "numberOfRequests": {
        "total": "108000",
        "ok": "108000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 108000,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.351",
        "ok": "52.351",
        "ko": "-"
    }
}
    },"req_order-ad---dkb-31f59": {
        type: "REQUEST",
        name: "Order AD - DKB",
path: "Order AD - DKB",
pathFormatted: "req_order-ad---dkb-31f59",
stats: {
    "name": "Order AD - DKB",
    "numberOfRequests": {
        "total": "194400",
        "ok": "194400",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 194400,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "94.232",
        "ok": "94.232",
        "ko": "-"
    }
}
    },"req_orderbook---dkb-6bfe8": {
        type: "REQUEST",
        name: "Orderbook - DKB",
path: "Orderbook - DKB",
pathFormatted: "req_orderbook---dkb-6bfe8",
stats: {
    "name": "Orderbook - DKB",
    "numberOfRequests": {
        "total": "108000",
        "ok": "108000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 108000,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.351",
        "ok": "52.351",
        "ko": "-"
    }
}
    },"req_cstmrmstr-qry---72664": {
        type: "REQUEST",
        name: "Cstmrmstr Qry - DZ",
path: "Cstmrmstr Qry - DZ",
pathFormatted: "req_cstmrmstr-qry---72664",
stats: {
    "name": "Cstmrmstr Qry - DZ",
    "numberOfRequests": {
        "total": "108000",
        "ok": "108000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 108000,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.351",
        "ok": "52.351",
        "ko": "-"
    }
}
    },"req_deposit---dkb-89ad3": {
        type: "REQUEST",
        name: "Deposit - DKB",
path: "Deposit - DKB",
pathFormatted: "req_deposit---dkb-89ad3",
stats: {
    "name": "Deposit - DKB",
    "numberOfRequests": {
        "total": "108000",
        "ok": "108000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 108000,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.351",
        "ok": "52.351",
        "ko": "-"
    }
}
    },"req_orderbook---deg-2af47": {
        type: "REQUEST",
        name: "Orderbook - Degussa",
path: "Orderbook - Degussa",
pathFormatted: "req_orderbook---deg-2af47",
stats: {
    "name": "Orderbook - Degussa",
    "numberOfRequests": {
        "total": "108000",
        "ok": "108000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 108000,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.351",
        "ok": "52.351",
        "ko": "-"
    }
}
    },"req_deposit---degus-e1e5f": {
        type: "REQUEST",
        name: "Deposit - Degussa",
path: "Deposit - Degussa",
pathFormatted: "req_deposit---degus-e1e5f",
stats: {
    "name": "Deposit - Degussa",
    "numberOfRequests": {
        "total": "108000",
        "ok": "108000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 108000,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.351",
        "ok": "52.351",
        "ko": "-"
    }
}
    },"req_order-insert----d3075": {
        type: "REQUEST",
        name: "Order Insert - DKB",
path: "Order Insert - DKB",
pathFormatted: "req_order-insert----d3075",
stats: {
    "name": "Order Insert - DKB",
    "numberOfRequests": {
        "total": "108000",
        "ok": "108000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
    "name": "t < 250 ms",
    "count": 108000,
    "percentage": 100
},
    "group2": {
    "name": "250 ms < t < 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 30000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.351",
        "ok": "52.351",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
